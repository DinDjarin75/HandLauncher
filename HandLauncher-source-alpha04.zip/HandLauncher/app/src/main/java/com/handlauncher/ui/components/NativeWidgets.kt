package com.handlauncher.ui.components

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.handlauncher.data.BatteryState
import com.handlauncher.data.WeatherState
import com.handlauncher.domain.*
import kotlinx.coroutines.delay
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import kotlin.math.abs

@Composable
private fun WidgetSurface(
    modifier: Modifier = Modifier,
    compactPadding: Boolean = false,
    content: @Composable ColumnScope.() -> Unit,
) {
    HandGlassSurface(
        modifier = modifier.fillMaxWidth(),
        contentPadding = PaddingValues(if (compactPadding) 12.dp else 18.dp),
    ) {
        Column(content = content)
    }
}

@Composable
fun ClockWidget(
    modifier: Modifier = Modifier,
    variant: String = "standard",
    showSeconds: Boolean = false,
    showDate: Boolean = true,
) {
    var now by remember { mutableStateOf(LocalTime.now()) }
    LaunchedEffect(showSeconds) {
        while (true) {
            now = LocalTime.now()
            delay(if (showSeconds) 1000 else 15_000)
        }
    }
    WidgetSurface(modifier, compactPadding = variant == "minimal") {
        if (variant != "minimal") {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Rounded.Schedule, null)
                Text("CLOCK", style = MaterialTheme.typography.labelMedium)
            }
            Spacer(Modifier.height(6.dp))
        }
        Text(
            now.format(DateTimeFormatter.ofPattern(if (showSeconds) "HH:mm:ss" else "HH:mm")),
            style = if (variant == "minimal") MaterialTheme.typography.displaySmall else MaterialTheme.typography.displayMedium,
            fontWeight = FontWeight.Light,
        )
        if (showDate) Text(LocalDate.now().format(DateTimeFormatter.ofPattern(if (variant == "detailed") "EEEE, d MMMM yyyy" else "EEEE, d MMMM")))
    }
}

@Composable
fun CalendarWidget(
    modifier: Modifier = Modifier,
    variant: String = "standard",
    nextEventInMinutes: Int? = null,
    nextEventTitle: String? = null,
    nextEventStartMillis: Long? = null,
) {
    val today = LocalDate.now()
    WidgetSurface(modifier, compactPadding = variant == "minimal") {
        if (variant != "minimal") {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Rounded.CalendarMonth, null)
                Text("CALENDAR", style = MaterialTheme.typography.labelMedium)
            }
            Spacer(Modifier.height(8.dp))
        }
        Text(today.dayOfMonth.toString(), style = MaterialTheme.typography.displaySmall)
        Text(today.format(DateTimeFormatter.ofPattern("EEEE · MMMM yyyy")))
        if (nextEventInMinutes != null) {
            Spacer(Modifier.height(4.dp))
            val timing = humanEventTime(nextEventStartMillis, nextEventInMinutes)
            Text(
                nextEventTitle.orEmpty().ifBlank { "Next event" },
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.primary,
                maxLines = if (variant == "detailed") 2 else 1,
            )
            timing?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = LocalContentColor.current.copy(alpha = 0.78f)) }
        } else if (variant == "detailed") {
            Text("Grant Calendar access for event-aware automation.", style = MaterialTheme.typography.bodySmall, color = LocalContentColor.current.copy(alpha = 0.76f))
        }
    }
}

@Composable
fun WeatherWidget(weather: WeatherState, modifier: Modifier = Modifier, variant: String = "standard") {
    WidgetSurface(modifier, compactPadding = variant == "minimal") {
        if (variant != "minimal") {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Rounded.Cloud, null)
                Text(weather.location.label.uppercase(), style = MaterialTheme.typography.labelMedium)
            }
            Spacer(Modifier.height(8.dp))
        }
        Text(weather.temperatureC?.let { "${kotlin.math.round(it).toInt()}°" } ?: "—°", style = MaterialTheme.typography.displaySmall)
        Text(weather.condition)
        if (variant == "detailed" && weather.rainExpectedInMinutes != null) {
            Text("Rain probability reaches 50% in ~${weather.rainExpectedInMinutes} min", style = MaterialTheme.typography.bodySmall, color = LocalContentColor.current.copy(alpha = 0.76f))
        }
    }
}

@Composable
fun BatteryWidget(
    battery: BatteryState,
    modifier: Modifier = Modifier,
    variant: String = "standard",
    connectedDeviceNames: Set<String> = emptySet(),
    showDevices: Boolean = true,
) {
    WidgetSurface(modifier, compactPadding = variant == "minimal") {
        if (variant != "minimal") {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Rounded.BatteryFull, null)
                Text("BATTERY", style = MaterialTheme.typography.labelMedium)
            }
            Spacer(Modifier.height(8.dp))
        }
        Text("${battery.percent}%", style = MaterialTheme.typography.displaySmall)
        Text(if (battery.charging) "Phone · charging" else "Phone")
        if (showDevices && connectedDeviceNames.isNotEmpty()) {
            connectedDeviceNames.take(if (variant == "detailed") 4 else 2).forEach { name ->
                Text("Connected · $name", style = MaterialTheme.typography.bodySmall, color = LocalContentColor.current.copy(alpha = 0.76f))
            }
        } else if (variant == "detailed") {
            Text("Accessory battery percentages appear when a device/provider exposes them to Android.", style = MaterialTheme.typography.bodySmall, color = LocalContentColor.current.copy(alpha = 0.76f))
        }
    }
}

@Composable
fun SmartWidgetStack(
    battery: BatteryState,
    contextDecision: ContextDecision,
    modifier: Modifier = Modifier,
    definition: SmartStackDefinition? = null,
    connectedDeviceNames: Set<String> = emptySet(),
    nextEventInMinutes: Int? = null,
    nextEventTitle: String? = null,
    nextEventStartMillis: Long? = null,
    weather: WeatherState = WeatherState(),
) {
    val fallback = remember {
        listOf(
            StackItem(NativeWidgetKind.CLOCK),
            StackItem(NativeWidgetKind.CALENDAR),
            StackItem(NativeWidgetKind.WEATHER),
            StackItem(NativeWidgetKind.BATTERY),
        )
    }
    val items = definition?.items?.ifEmpty { fallback } ?: fallback
    val widgets = items.map { it.widgetKind }
    val promotedCandidate = contextDecision.effects
        .filterIsInstance<ContextEffect.PromoteWidget>()
        .firstOrNull()
        ?.kind
    val promoted = if (
        definition?.smartRotationEnabled != false &&
        items.any { it.widgetKind == promotedCandidate && it.allowAutomaticPromotion }
    ) promotedCandidate else null

    var manualIndex by remember(widgets) { mutableIntStateOf(0) }
    var direction by remember { mutableIntStateOf(1) }
    val safeIndex = manualIndex.coerceIn(0, widgets.lastIndex.coerceAtLeast(0))
    val activeKind = promoted ?: widgets.getOrElse(safeIndex) { NativeWidgetKind.CLOCK }
    var drag by remember { mutableFloatStateOf(0f) }
    val swipeThreshold = with(LocalDensity.current) { 52.dp.toPx() }
    val autoLoopEnabled = definition?.autoLoopEnabled ?: true

    // Auto-loop is deliberately independent from contextual promotion. If a rule
    // temporarily promotes a widget, the user's saved/manual position is preserved
    // and automatic looping resumes from it when the promotion ends.
    LaunchedEffect(autoLoopEnabled, widgets, manualIndex, promoted) {
        if (!autoLoopEnabled || widgets.size < 2 || promoted != null) return@LaunchedEffect
        delay(8_000)
        direction = 1
        manualIndex = (safeIndex + 1) % widgets.size
    }

    Box(
        modifier = modifier.pointerInput(widgets, promoted, swipeThreshold) {
            detectHorizontalDragGestures(
                onHorizontalDrag = { _, amount -> drag += amount },
                onDragEnd = {
                    if (widgets.size > 1 && abs(drag) > swipeThreshold) {
                        // Natural carousel semantics: swipe left for next, right for previous.
                        direction = if (drag < 0f) 1 else -1
                        manualIndex = if (direction > 0) {
                            (safeIndex + 1) % widgets.size
                        } else {
                            (safeIndex - 1 + widgets.size) % widgets.size
                        }
                    }
                    drag = 0f
                },
                onDragCancel = { drag = 0f },
            )
        }
    ) {
        AnimatedContent(
            targetState = activeKind,
            transitionSpec = {
                val slideIn = slideInHorizontally { width -> if (direction > 0) width / 3 else -width / 3 } + fadeIn()
                val slideOut = slideOutHorizontally { width -> if (direction > 0) -width / 3 else width / 3 } + fadeOut()
                slideIn togetherWith slideOut
            },
            label = "smart-stack-horizontal",
        ) { kind ->
            when (kind) {
                NativeWidgetKind.CLOCK -> ClockWidget()
                NativeWidgetKind.CALENDAR -> CalendarWidget(
                    nextEventInMinutes = nextEventInMinutes,
                    nextEventTitle = nextEventTitle,
                    nextEventStartMillis = nextEventStartMillis,
                )
                NativeWidgetKind.WEATHER -> WeatherWidget(weather)
                NativeWidgetKind.BATTERY -> BatteryWidget(battery, connectedDeviceNames = connectedDeviceNames)
                NativeWidgetKind.CONTEXT -> ClockWidget()
                NativeWidgetKind.NEWS -> ClockWidget()
            }
        }
        Row(
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(5.dp),
        ) {
            widgets.forEach { kind ->
                Box(
                    Modifier
                        .size(if (kind == activeKind) 14.dp else 6.dp, 4.dp)
                        .background(
                            MaterialTheme.colorScheme.onSurface.copy(alpha = if (kind == activeKind) 0.85f else 0.28f),
                            RoundedCornerShape(8.dp),
                        )
                )
            }
        }
    }
}
