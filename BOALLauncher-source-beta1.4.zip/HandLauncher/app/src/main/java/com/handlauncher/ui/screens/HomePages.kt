package com.handlauncher.ui.screens

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.handlauncher.data.BatteryState
import com.handlauncher.data.MediaPlaybackState
import com.handlauncher.data.ConnectivityState
import com.handlauncher.data.NewsHeadline
import com.handlauncher.data.NewsState
import com.handlauncher.data.LauncherNotification
import com.handlauncher.data.WeatherState
import com.handlauncher.domain.*
import com.handlauncher.platform.AndroidWidgetHostController
import com.handlauncher.ui.components.AppIcon
import com.handlauncher.ui.components.HandGlassSurface
import com.handlauncher.ui.components.RemoteArticleImage
import com.handlauncher.ui.components.humanEventTime
import com.handlauncher.ui.components.DeclarativeLayoutCanvas
import com.handlauncher.ui.components.SmartWidgetStack
import com.handlauncher.ui.components.WeatherGraphic
import com.handlauncher.ui.components.ThemedPackageIcon
import com.handlauncher.ui.theme.LocalHandAccentPalette
import kotlin.math.abs
import java.time.LocalTime

@Composable
fun FeedPage(
    battery: BatteryState,
    weather: WeatherState,
    news: NewsState,
    contextDecision: ContextDecision,
    nextEventTitle: String?,
    nextEventInMinutes: Int?,
    nextEventStartMillis: Long?,
    calendarPermissionGranted: Boolean,
    onRequestCalendarPermission: () -> Unit,
    onOpenHeadline: (String) -> Unit,
    onRefreshBrief: () -> Unit,
    onOpenWeather: () -> Unit,
    onOpenBattery: () -> Unit,
    onOpenCalendar: () -> Unit,
    onRunCommand: (String) -> Unit,
    onOpenGoogle: () -> Unit = {},
    modifier: Modifier = Modifier,
) {
    val nowHour = remember { LocalTime.now().hour }
    val greeting = when (nowHour) {
        in 5..11 -> "Good morning"
        in 12..17 -> "Good afternoon"
        else -> "Good evening"
    }
    val wallpaperPrimary = Color.White
    val wallpaperSecondary = Color.White.copy(alpha = 0.78f)
    val eventTiming = humanEventTime(nextEventStartMillis, nextEventInMinutes)

    LazyColumn(
        modifier = modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding(),
        contentPadding = PaddingValues(horizontal = 18.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(greeting, style = MaterialTheme.typography.headlineMedium, color = wallpaperPrimary)
                    Text("Your brief", color = wallpaperSecondary)
                }
                IconButton(onClick = onRefreshBrief) { Icon(Icons.Rounded.Refresh, "Refresh brief", tint = wallpaperPrimary) }
                IconButton(onClick = onOpenGoogle) { Icon(Icons.Rounded.Explore, "Google", tint = wallpaperPrimary) }
            }
        }

        item {
            HandGlassSurface(modifier = Modifier.fillMaxWidth(), cornerRadiusDp = 28) {
                Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        Row(
                            modifier = Modifier.weight(1f).clickable(onClick = onOpenWeather),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                        ) {
                            WeatherGraphic(weather.condition, Modifier.size(62.dp))
                            Column {
                                Text(weather.location.label.ifBlank { "Weather" }, style = MaterialTheme.typography.labelLarge)
                                Text(weather.temperatureC?.let { "${kotlin.math.round(it).toInt()}°" } ?: "—°", style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Light)
                                Text(weather.condition, color = LocalContentColor.current.copy(alpha = 0.78f))
                            }
                        }
                        Column(Modifier.clickable(onClick = onOpenBattery), horizontalAlignment = Alignment.End) {
                            Icon(Icons.Rounded.BatteryFull, null)
                            Text("${battery.percent}%", style = MaterialTheme.typography.titleLarge)
                            Text(if (battery.charging) "Charging" else "Phone", color = LocalContentColor.current.copy(alpha = 0.78f))
                        }
                    }
                    if (weather.dailyForecast.isNotEmpty()) {
                        HorizontalDivider(color = LocalContentColor.current.copy(alpha = 0.20f))
                        Row(Modifier.fillMaxWidth().clickable(onClick = onOpenWeather), horizontalArrangement = Arrangement.SpaceBetween) {
                            weather.dailyForecast.take(5).forEach { day ->
                                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                                    Text(day.dayLabel, style = MaterialTheme.typography.labelMedium)
                                    WeatherGraphic(day.condition, Modifier.size(28.dp))
                                    Text(listOfNotNull(day.highC?.let { "${kotlin.math.round(it).toInt()}°" }, day.lowC?.let { "${kotlin.math.round(it).toInt()}°" }).joinToString(" / ").ifBlank { "—" }, style = MaterialTheme.typography.bodyMedium)
                                    day.precipitationChancePercent?.takeIf { it > 0 }?.let { chance -> Text("$chance% rain", style = MaterialTheme.typography.labelSmall, color = LocalContentColor.current.copy(alpha = 0.72f)) }
                                }
                            }
                        }
                    }
                }
            }
        }

        item {
            HandGlassSurface(
                modifier = Modifier.fillMaxWidth().clickable { if (calendarPermissionGranted) onOpenCalendar() else onRequestCalendarPermission() },
                cornerRadiusDp = 24,
            ) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Icon(Icons.Rounded.Event, null)
                    Column(Modifier.weight(1f)) {
                        Text("Calendar", style = MaterialTheme.typography.labelLarge)
                        when {
                            nextEventTitle != null -> {
                                Text(nextEventTitle, style = MaterialTheme.typography.titleMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                eventTiming?.let { Text(it, color = LocalContentColor.current.copy(alpha = 0.78f)) }
                            }
                            calendarPermissionGranted -> Text("Nothing upcoming", color = LocalContentColor.current.copy(alpha = 0.78f))
                            else -> Text("Tap to enable calendar", color = LocalContentColor.current.copy(alpha = 0.78f))
                        }
                    }
                }
            }
        }

        contextDecision.effects.filterIsInstance<ContextEffect.SuggestCommand>().take(2).forEach { suggestion ->
            item(key = "context_${suggestion.title}") {
                HandGlassSurface(modifier = Modifier.fillMaxWidth().clickable { onRunCommand(suggestion.command) }, cornerRadiusDp = 24) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.AutoAwesome, null)
                        Spacer(Modifier.width(12.dp))
                        Text(suggestion.title, style = MaterialTheme.typography.titleSmall)
                    }
                }
            }
        }

        item { NewsSection("Headlines", news.headlines, news.message, onOpenHeadline, wallpaperPrimary, wallpaperSecondary) }
        item { NewsSection("Entertainment", news.entertainment, null, onOpenHeadline, wallpaperPrimary, wallpaperSecondary) }
        item { NewsSection("Tech", news.tech, null, onOpenHeadline, wallpaperPrimary, wallpaperSecondary) }
        item { NewsSection("LEGO", news.lego, null, onOpenHeadline, wallpaperPrimary, wallpaperSecondary) }
        item { Spacer(Modifier.height(8.dp)) }
    }
}

@Composable
private fun NewsSection(
    title: String,
    stories: List<NewsHeadline>,
    emptyMessage: String?,
    onOpenHeadline: (String) -> Unit,
    wallpaperPrimary: Color,
    wallpaperSecondary: Color,
) {
    var expanded by remember { mutableStateOf(true) }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth().clickable { expanded = !expanded }.padding(vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(title, style = MaterialTheme.typography.titleLarge, color = wallpaperPrimary, modifier = Modifier.weight(1f))
            Icon(if (expanded) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore, if (expanded) "Collapse" else "Expand", tint = wallpaperSecondary)
        }
        if (expanded) {
            if (stories.isEmpty()) {
                HandGlassSurface(modifier = Modifier.fillMaxWidth(), cornerRadiusDp = 22) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Newspaper, null)
                        Spacer(Modifier.width(12.dp))
                        Text(emptyMessage ?: "No stories right now", color = LocalContentColor.current.copy(alpha = 0.78f))
                    }
                }
            } else {
                stories.take(5).forEach { headline ->
                    val cleanTitle = remember(headline.title, headline.source) {
                        if (headline.source.isBlank()) headline.title else headline.title.removeSuffix(" - ${headline.source}").removeSuffix(" – ${headline.source}").trim()
                    }
                    HandGlassSurface(
                        modifier = Modifier.fillMaxWidth().clickable { onOpenHeadline(headline.url) },
                        cornerRadiusDp = 22,
                        contentPadding = PaddingValues(0.dp),
                    ) {
                        Row(Modifier.fillMaxWidth().height(112.dp)) {
                            RemoteArticleImage(
                                imageUrl = headline.imageUrl,
                                contentDescription = cleanTitle,
                                articleUrl = headline.url,
                                modifier = Modifier.weight(0.20f).fillMaxHeight(),
                            )
                            Column(
                                modifier = Modifier.weight(0.80f).fillMaxHeight().padding(horizontal = 14.dp, vertical = 12.dp),
                                verticalArrangement = Arrangement.Center,
                            ) {
                                Text(cleanTitle, style = MaterialTheme.typography.titleSmall, maxLines = 3, overflow = TextOverflow.Ellipsis)
                                if (headline.source.isNotBlank()) {
                                    Spacer(Modifier.height(5.dp))
                                    Text(headline.source, style = MaterialTheme.typography.labelMedium, color = LocalContentColor.current.copy(alpha = 0.72f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun NotificationCapsule(
    notifications: List<LauncherNotification>,
    onOpenNotification: (String) -> Unit,
    onDismissNotification: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    if (notifications.isEmpty()) return

    val accent = LocalHandAccentPalette.current
    val scrollState = rememberScrollState()
    HandGlassSurface(
        modifier = modifier,
        cornerRadiusDp = 28,
        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 144.dp)
                .verticalScroll(scrollState),
        ) {
            notifications.forEachIndexed { index, notification ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(68.dp)
                        .clickable { onOpenNotification(notification.key) }
                        .padding(horizontal = 2.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(11.dp),
                ) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(accent.accentFaint)
                            .border(0.8.dp, accent.outline, RoundedCornerShape(14.dp)),
                        contentAlignment = Alignment.Center,
                    ) {
                        ThemedPackageIcon(
                            packageName = notification.packageName,
                            contentDescription = null,
                            modifier = Modifier.size(34.dp),
                            sizePx = 96,
                        )
                    }
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
                        if (notification.title.isNotBlank()) {
                            Text(
                                notification.title,
                                style = MaterialTheme.typography.titleSmall,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                        if (notification.text.isNotBlank()) {
                            Text(
                                notification.text,
                                style = MaterialTheme.typography.bodyMedium,
                                color = LocalContentColor.current.copy(alpha = 0.72f),
                                maxLines = if (notification.title.isBlank()) 2 else 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                    }
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(accent.accentFaint)
                            .border(0.8.dp, accent.outline, CircleShape),
                        contentAlignment = Alignment.Center,
                    ) {
                        IconButton(
                            onClick = { onDismissNotification(notification.key) },
                            modifier = Modifier.fillMaxSize(),
                        ) {
                            Icon(Icons.Rounded.Close, contentDescription = "Dismiss notification", modifier = Modifier.size(20.dp))
                        }
                    }
                }
                if (index != notifications.lastIndex) {
                    HorizontalDivider(Modifier.padding(start = 58.dp), color = accent.accentSoft.copy(alpha = 0.30f))
                }
            }
        }
    }
}

@Composable
private fun HomeControlButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    contentDescription: String,
    onClick: () -> Unit,
) {
    val accent = LocalHandAccentPalette.current
    Box(
        modifier = Modifier
            .size(46.dp)
            .clip(CircleShape)
            .background(accent.accentFaint)
            .border(0.8.dp, accent.outline, CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        IconButton(onClick = onClick, modifier = Modifier.fillMaxSize()) {
            Icon(icon, contentDescription = contentDescription, tint = accent.accentStrong, modifier = Modifier.size(23.dp))
        }
    }
}

@Composable
private fun HomeControlCapsule(
    onAutomations: () -> Unit,
    onSettings: () -> Unit,
    onEnterEditMode: () -> Unit,
    onAiDesign: () -> Unit,
    modifier: Modifier = Modifier,
) {
    HandGlassSurface(
        modifier = modifier,
        cornerRadiusDp = 30,
        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 5.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            HomeControlButton(Icons.Rounded.Bolt, "Automations", onAutomations)
            HomeControlButton(Icons.Rounded.Settings, "Settings", onSettings)
            HomeControlButton(Icons.Rounded.Edit, "Edit Home", onEnterEditMode)
            HomeControlButton(Icons.Rounded.AutoAwesome, "AI Design", onAiDesign)
        }
    }
}

@Composable
private fun HomeEditControls(
    activeLayout: LauncherLayout?,
    onAddObject: () -> Unit,
    onToggleFinePositioning: () -> Unit,
    onToggleLock: () -> Unit,
    onExitEditMode: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(modifier, verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.End) {
        FilledTonalIconButton(onClick = onAddObject) { Icon(Icons.Rounded.Add, "Add object") }
        FilledTonalIconButton(onClick = onToggleFinePositioning) { Icon(if (activeLayout?.finePositioning == true) Icons.Rounded.OpenWith else Icons.Rounded.Grid4x4, "Positioning") }
        FilledTonalIconButton(onClick = onToggleLock) { Icon(Icons.Rounded.Lock, "Lock") }
        Button(onClick = onExitEditMode) { Text("Done") }
    }
}

@Composable
fun PhoneHomePage(
    apps: List<AppEntry>,
    smartObjectOverrides: Map<String, SmartObject>,
    smartStacks: Map<String, SmartStackDefinition>,
    battery: BatteryState,
    weather: WeatherState,
    media: MediaPlaybackState,
    connectivity: ConnectivityState,
    notifications: List<LauncherNotification>,
    contextDecision: ContextDecision,
    connectedDeviceNames: Set<String>,
    nextEventInMinutes: Int?,
    nextEventTitle: String?,
    nextEventStartMillis: Long?,
    loadStackPosition: (String) -> Int,
    onStackPositionChanged: (String, Int) -> Unit,
    homePageVisible: Boolean,
    profile: LayoutProfile,
    activeLayout: LauncherLayout?,
    editMode: Boolean,
    isHomeRoleHeld: Boolean,
    requestHomeRole: () -> Unit,
    onLaunch: (AppEntry) -> Unit,
    onEditSmartObject: (AppEntry) -> Unit,
    onSearch: () -> Unit,
    onLibrary: () -> Unit,
    onAiDesign: () -> Unit,
    onAutomations: () -> Unit,
    onSettings: () -> Unit,
    onOpenClock: () -> Unit,
    onOpenCalendar: () -> Unit,
    onOpenCalendarApp: () -> Unit,
    onOpenWeather: () -> Unit,
    onOpenBattery: () -> Unit,
    onOpenMedia: () -> Unit,
    onMediaPlayPause: () -> Unit,
    onMediaPrevious: () -> Unit,
    onMediaNext: () -> Unit,
    onMediaSeek: (Long) -> Unit,
    onOpenNotification: (String) -> Unit,
    onDismissNotification: (String) -> Unit,
    onRunCommand: (String) -> Unit,
    onAddObject: () -> Unit,
    onEnterEditMode: () -> Unit,
    onExitEditMode: () -> Unit,
    onToggleLock: () -> Unit,
    onToggleFinePositioning: () -> Unit,
    onObjectGesture: (SmartObject, GestureSlot) -> Unit,
    onObjectRectChange: (String, GridRect, Boolean) -> Unit,
    onRemoveObject: (SmartObject) -> Unit,
    onEditObject: (SmartObject) -> Unit,
    widgetHostController: AndroidWidgetHostController,
    modifier: Modifier = Modifier,
) {
    var verticalDrag by remember { mutableFloatStateOf(0f) }
    val density = LocalDensity.current
    val view = LocalView.current
    val cutoutAwarePhoneProfile = profile == LayoutProfile.COVER || profile == LayoutProfile.PHONE_PORTRAIT
    var physicalCutoutBottomPx by remember(view, profile) { mutableIntStateOf(0) }
    DisposableEffect(view, profile) {
        fun refreshCutoutBounds() {
            physicalCutoutBottomPx = if (cutoutAwarePhoneProfile) {
                view.rootWindowInsets?.displayCutout?.boundingRects
                    ?.filter { it.top <= view.height / 3 }
                    ?.maxOfOrNull { it.bottom }
                    ?: 0
            } else {
                0
            }
        }
        val listener = android.view.ViewTreeObserver.OnGlobalLayoutListener { refreshCutoutBounds() }
        view.viewTreeObserver.addOnGlobalLayoutListener(listener)
        refreshCutoutBounds()
        onDispose {
            if (view.viewTreeObserver.isAlive) {
                view.viewTreeObserver.removeOnGlobalLayoutListener(listener)
            }
        }
    }
    val coverCutoutTopPadding = if (cutoutAwarePhoneProfile && physicalCutoutBottomPx > 0) {
        with(density) { (physicalCutoutBottomPx.toFloat() + 0.5f).toDp() }
    } else {
        6.dp
    }
    val gestureThresholdPx = with(density) { 96.dp.toPx() }
    val maxGestureTravelPx = with(density) { 24.dp.toPx() }
    val gestureTranslation by animateFloatAsState(
        targetValue = (verticalDrag * 0.14f).coerceIn(-maxGestureTravelPx, maxGestureTravelPx),
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "homeGestureTranslation",
    )

    Box(
        modifier = modifier.fillMaxSize().then(
            if (!editMode && activeLayout == null) Modifier.pointerInput(Unit) {
                detectVerticalDragGestures(
                    onDragStart = { verticalDrag = 0f },
                    onVerticalDrag = { change, amount ->
                        verticalDrag += amount
                        change.consume()
                    },
                    onDragEnd = {
                        if (abs(verticalDrag) > gestureThresholdPx) {
                            if (verticalDrag > 0) onSearch() else onLibrary()
                        }
                        verticalDrag = 0f
                    },
                    onDragCancel = { verticalDrag = 0f },
                )
            } else Modifier
        )
    ) {
        Column(
            modifier = Modifier.fillMaxSize()
                .graphicsLayer { translationY = gestureTranslation }
                .navigationBarsPadding()
                .padding(start = 14.dp, end = 14.dp, top = coverCutoutTopPadding),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            if (activeLayout == null) {
                val homeStack = smartStacks["default_home_stack"] ?: smartStacks.values.firstOrNull()
                val homeStackId = homeStack?.id ?: "default_home_stack"
                SmartWidgetStack(
                    battery = battery,
                    contextDecision = contextDecision,
                    modifier = Modifier.fillMaxWidth().height(if (profile == LayoutProfile.INNER_FOLD) 222.dp else 214.dp),
                    definition = homeStack,
                    connectedDeviceNames = connectedDeviceNames,
                    connectivity = connectivity,
                    nextEventInMinutes = nextEventInMinutes,
                    nextEventTitle = nextEventTitle,
                    nextEventStartMillis = nextEventStartMillis,
                    weather = weather,
                    media = media,
                    initialPermanentIndex = loadStackPosition(homeStackId),
                    onPermanentIndexChanged = { onStackPositionChanged(homeStackId, it) },
                    autoAdvanceAllowed = homePageVisible,
                    onOpenClock = onOpenClock,
                    onOpenCalendar = onOpenCalendarApp,
                    onOpenCalendarEvent = onOpenCalendar,
                    onOpenWeather = onOpenWeather,
                    onOpenBattery = onOpenBattery,
                    onOpenMedia = onOpenMedia,
                    onMediaPlayPause = onMediaPlayPause,
                    onMediaPrevious = onMediaPrevious,
                    onMediaNext = onMediaNext,
                    onMediaSeek = onMediaSeek,
                )

                if (editMode) {
                    HomeEditControls(
                        activeLayout = activeLayout,
                        onAddObject = onAddObject,
                        onToggleFinePositioning = onToggleFinePositioning,
                        onToggleLock = onToggleLock,
                        onExitEditMode = onExitEditMode,
                        modifier = Modifier.fillMaxWidth(),
                    )
                } else {
                    HomeControlCapsule(
                        onAutomations = onAutomations,
                        onSettings = onSettings,
                        onEnterEditMode = onEnterEditMode,
                        onAiDesign = onAiDesign,
                        modifier = Modifier.align(Alignment.End),
                    )
                    NotificationCapsule(
                        notifications = notifications,
                        onOpenNotification = onOpenNotification,
                        onDismissNotification = onDismissNotification,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }

                if (!isHomeRoleHeld && !editMode) {
                    ElevatedCard(shape = RoundedCornerShape(24.dp)) {
                        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Icon(Icons.Rounded.Home, null)
                            Text("Make this your default Home", fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                            Button(onClick = requestHomeRole) { Text("Choose") }
                        }
                    }
                }

                if (!editMode) {
                    contextDecision.effects.filterIsInstance<ContextEffect.SuggestCommand>().firstOrNull()?.let { suggestion ->
                        ElevatedCard(onClick = { onRunCommand(suggestion.command) }, shape = RoundedCornerShape(22.dp)) {
                            Row(
                                Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                            ) {
                                Icon(Icons.Rounded.AutoAwesome, null)
                                Text(suggestion.title, style = MaterialTheme.typography.labelLarge, modifier = Modifier.weight(1f))
                                Icon(Icons.Rounded.ChevronRight, null)
                            }
                        }
                    }
                }
                Spacer(Modifier.weight(1f))
            } else {
                DeclarativeLayoutCanvas(
                    layout = activeLayout,
                    apps = apps,
                    battery = battery,
                    weather = weather,
                    media = media,
                    connectivity = connectivity,
                    contextDecision = contextDecision,
                    connectedDeviceNames = connectedDeviceNames,
                    nextEventInMinutes = nextEventInMinutes,
                    nextEventTitle = nextEventTitle,
                    nextEventStartMillis = nextEventStartMillis,
                    smartStacks = smartStacks,
                    editMode = editMode,
                    onGesture = onObjectGesture,
                    onRectChange = onObjectRectChange,
                    onRemoveObject = onRemoveObject,
                    onEditObject = onEditObject,
                    loadStackPosition = loadStackPosition,
                    onStackPositionChanged = onStackPositionChanged,
                    stackAutoAdvanceAllowed = homePageVisible,
                    onOpenClock = onOpenClock,
                    onOpenCalendar = onOpenCalendarApp,
                    onOpenCalendarEvent = onOpenCalendar,
                    onOpenWeather = onOpenWeather,
                    onOpenBattery = onOpenBattery,
                    onOpenMedia = onOpenMedia,
                    onMediaPlayPause = onMediaPlayPause,
                    onMediaPrevious = onMediaPrevious,
                    onMediaNext = onMediaNext,
                    onMediaSeek = onMediaSeek,
                    onBackgroundSwipeDown = onSearch,
                    onBackgroundSwipeUp = onLibrary,
                    widgetHostController = widgetHostController,
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                )

                if (editMode) {
                    HomeEditControls(
                        activeLayout = activeLayout,
                        onAddObject = onAddObject,
                        onToggleFinePositioning = onToggleFinePositioning,
                        onToggleLock = onToggleLock,
                        onExitEditMode = onExitEditMode,
                        modifier = Modifier.fillMaxWidth(),
                    )
                } else {
                    HomeControlCapsule(
                        onAutomations = onAutomations,
                        onSettings = onSettings,
                        onEnterEditMode = onEnterEditMode,
                        onAiDesign = onAiDesign,
                        modifier = Modifier.align(Alignment.End),
                    )
                }
            }

            if (editMode) {
                Text(
                    if (activeLayout?.finePositioning == true) "Fine positioning" else "Grid snapping",
                    modifier = Modifier.align(Alignment.CenterHorizontally),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                )
            }
        }
    }
}

@Composable
fun ExtraHomePage(
    contextDecision: ContextDecision,
    battery: BatteryState,
    weather: WeatherState,
    onAiDesign: () -> Unit,
    onAutomations: () -> Unit,
    onSettings: () -> Unit,
    profile: LayoutProfile,
) {
    Column(
        Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Text("Workspace", style = MaterialTheme.typography.headlineMedium)
        HandGlassSurface(Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("At a glance", style = MaterialTheme.typography.titleMedium)
                Text("Battery · ${battery.percent}%${if (battery.charging) " · charging" else ""}")
                Text("${weather.location.label} · ${weather.temperatureC?.let { "${kotlin.math.round(it).toInt()}°" } ?: "—°"} · ${weather.condition}")
                contextDecision.effects.filterIsInstance<ContextEffect.SuggestCommand>().take(2).forEach { Text(it.title) }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = onAiDesign) { Icon(Icons.Rounded.AutoAwesome, null); Spacer(Modifier.width(6.dp)); Text("AI Design") }
            OutlinedButton(onClick = onAutomations) { Icon(Icons.Rounded.Bolt, null); Spacer(Modifier.width(6.dp)); Text("Automations") }
        }
        OutlinedButton(onClick = onSettings) { Icon(Icons.Rounded.Settings, null); Spacer(Modifier.width(6.dp)); Text("Settings") }
    }
}

@Composable
fun DesktopHomePage(
    apps: List<AppEntry>,
    smartObjectOverrides: Map<String, SmartObject>,
    smartStacks: Map<String, SmartStackDefinition>,
    battery: BatteryState,
    weather: WeatherState,
    media: MediaPlaybackState,
    connectivity: ConnectivityState,
    contextDecision: ContextDecision,
    connectedDeviceNames: Set<String>,
    nextEventInMinutes: Int?,
    nextEventTitle: String?,
    nextEventStartMillis: Long?,
    loadStackPosition: (String) -> Int,
    onStackPositionChanged: (String, Int) -> Unit,
    activeLayout: LauncherLayout?,
    editMode: Boolean,
    onLaunch: (AppEntry) -> Unit,
    onEditSmartObject: (AppEntry) -> Unit,
    onSearch: () -> Unit,
    onAiDesign: () -> Unit,
    onAutomations: () -> Unit,
    onSettings: () -> Unit,
    onOpenClock: () -> Unit,
    onOpenCalendar: () -> Unit,
    onOpenCalendarApp: () -> Unit,
    onOpenWeather: () -> Unit,
    onOpenBattery: () -> Unit,
    onOpenMedia: () -> Unit,
    onMediaPlayPause: () -> Unit,
    onMediaPrevious: () -> Unit,
    onMediaNext: () -> Unit,
    onMediaSeek: (Long) -> Unit,
    onAddObject: () -> Unit,
    onEnterEditMode: () -> Unit,
    onExitEditMode: () -> Unit,
    onToggleLock: () -> Unit,
    onToggleFinePositioning: () -> Unit,
    onObjectGesture: (SmartObject, GestureSlot) -> Unit,
    onObjectRectChange: (String, GridRect, Boolean) -> Unit,
    onRemoveObject: (SmartObject) -> Unit,
    onEditObject: (SmartObject) -> Unit,
    widgetHostController: AndroidWidgetHostController,
) {
    Row(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(14.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        Surface(modifier = Modifier.width(250.dp).fillMaxHeight(), shape = RoundedCornerShape(28.dp), tonalElevation = 3.dp) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Workspace", style = MaterialTheme.typography.titleLarge)
                NavigationDrawerItem(label = { Text("Search") }, selected = false, icon = { Icon(Icons.Rounded.Search, null) }, onClick = onSearch)
                NavigationDrawerItem(label = { Text("AI Design") }, selected = false, icon = { Icon(Icons.Rounded.AutoAwesome, null) }, onClick = onAiDesign)
                NavigationDrawerItem(label = { Text("Automations") }, selected = false, icon = { Icon(Icons.Rounded.Bolt, null) }, onClick = onAutomations)
                NavigationDrawerItem(label = { Text("Settings") }, selected = false, icon = { Icon(Icons.Rounded.Settings, null) }, onClick = onSettings)
                HorizontalDivider()
                if (editMode) {
                    Button(onClick = onAddObject, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Rounded.Add, null); Spacer(Modifier.width(6.dp)); Text("Add object") }
                    Button(onClick = onExitEditMode, modifier = Modifier.fillMaxWidth()) { Text("Done editing") }
                    FilledTonalButton(onClick = onToggleFinePositioning, modifier = Modifier.fillMaxWidth()) { Text(if (activeLayout?.finePositioning == true) "Fine positioning" else "Grid snapping") }
                    FilledTonalButton(onClick = onToggleLock, modifier = Modifier.fillMaxWidth()) { Text("Lock layout") }
                } else {
                    Button(onClick = onEnterEditMode, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Rounded.Edit, null); Spacer(Modifier.width(8.dp)); Text("Edit layout") }
                    if (activeLayout?.locked == true) TextButton(onClick = onToggleLock, modifier = Modifier.fillMaxWidth()) { Text("Unlock layout") }
                }
                Spacer(Modifier.weight(1f))
                Text("Battery ${battery.percent}%", style = MaterialTheme.typography.labelMedium)
            }
        }

        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            if (activeLayout != null) {
                DeclarativeLayoutCanvas(
                    layout = activeLayout,
                    apps = apps,
                    battery = battery,
                    weather = weather,
                    media = media,
                    connectivity = connectivity,
                    contextDecision = contextDecision,
                    connectedDeviceNames = connectedDeviceNames,
                    nextEventInMinutes = nextEventInMinutes,
                    nextEventTitle = nextEventTitle,
                    nextEventStartMillis = nextEventStartMillis,
                    smartStacks = smartStacks,
                    editMode = editMode,
                    onGesture = onObjectGesture,
                    onRectChange = onObjectRectChange,
                    onRemoveObject = onRemoveObject,
                    onEditObject = onEditObject,
                    loadStackPosition = loadStackPosition,
                    onStackPositionChanged = onStackPositionChanged,
                    onOpenClock = onOpenClock,
                    onOpenCalendar = onOpenCalendarApp,
                    onOpenCalendarEvent = onOpenCalendar,
                    onOpenWeather = onOpenWeather,
                    onOpenBattery = onOpenBattery,
                    onOpenMedia = onOpenMedia,
                    onMediaPlayPause = onMediaPlayPause,
                    onMediaPrevious = onMediaPrevious,
                    onMediaNext = onMediaNext,
                    onMediaSeek = onMediaSeek,
                    widgetHostController = widgetHostController,
                    modifier = Modifier.fillMaxSize(),
                )
            } else {
                val homeStack = smartStacks["default_home_stack"] ?: smartStacks.values.firstOrNull()
                val homeStackId = homeStack?.id ?: "default_home_stack"
                SmartWidgetStack(
                    battery = battery,
                    contextDecision = contextDecision,
                    modifier = Modifier.height(220.dp),
                    definition = homeStack,
                    connectedDeviceNames = connectedDeviceNames,
                    connectivity = connectivity,
                    nextEventInMinutes = nextEventInMinutes,
                    nextEventTitle = nextEventTitle,
                    nextEventStartMillis = nextEventStartMillis,
                    weather = weather,
                    media = media,
                    initialPermanentIndex = loadStackPosition(homeStackId),
                    onPermanentIndexChanged = { onStackPositionChanged(homeStackId, it) },
                    onOpenClock = onOpenClock,
                    onOpenCalendar = onOpenCalendarApp,
                    onOpenCalendarEvent = onOpenCalendar,
                    onOpenWeather = onOpenWeather,
                    onOpenBattery = onOpenBattery,
                    onOpenMedia = onOpenMedia,
                    onMediaPlayPause = onMediaPlayPause,
                    onMediaPrevious = onMediaPrevious,
                    onMediaNext = onMediaNext,
                    onMediaSeek = onMediaSeek,
                )
                Text("Apps", style = MaterialTheme.typography.titleLarge)
                LazyVerticalGrid(columns = GridCells.Adaptive(100.dp), modifier = Modifier.fillMaxSize()) {
                    items(apps, key = { it.stableId }) { app ->
                        AppIcon(app, { onLaunch(app) }, displayLabel = smartObjectOverrides[app.stableId]?.title ?: app.label, onLongClick = { onEditSmartObject(app) })
                    }
                }
            }
        }
    }
}
