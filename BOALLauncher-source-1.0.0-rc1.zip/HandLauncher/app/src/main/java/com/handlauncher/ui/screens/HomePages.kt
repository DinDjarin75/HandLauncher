package com.handlauncher.ui.screens

import android.content.res.Configuration
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.handlauncher.data.BatteryState
import com.handlauncher.data.MediaPlaybackState
import com.handlauncher.data.ConnectivityState
import com.handlauncher.data.NewsHeadline
import com.handlauncher.data.NewsState
import com.handlauncher.data.LauncherNotification
import com.handlauncher.data.WeatherState
import com.handlauncher.data.WorkspaceChatMessage
import com.handlauncher.data.WorkspaceChatRole
import com.handlauncher.data.WorkspaceSystemState
import com.handlauncher.data.EnergyGridState
import com.handlauncher.domain.*
import com.handlauncher.platform.AndroidWidgetHostController
import com.handlauncher.ui.components.AppIcon
import com.handlauncher.ui.components.HandGlassSurface
import com.handlauncher.ui.components.AndroidHostedWidget
import com.handlauncher.ui.components.RemoteArticleImage
import com.handlauncher.ui.components.humanEventTime
import com.handlauncher.ui.components.DeclarativeLayoutCanvas
import com.handlauncher.ui.components.SmartWidgetStack
import com.handlauncher.ui.components.ClockWidget
import com.handlauncher.ui.components.CalendarWidget
import com.handlauncher.ui.components.BatteryWidget
import com.handlauncher.ui.components.WeatherGraphic
import com.handlauncher.ui.components.ThemedPackageIcon
import com.handlauncher.ui.theme.LocalHandAccentPalette
import kotlin.math.abs
import java.time.LocalTime

@Composable
fun FeedPage(
    battery: BatteryState,
    weather: WeatherState,
    news: NewsState,
    contextDecision: ContextDecision,
    nextEventTitle: String?,
    nextEventInMinutes: Int?,
    nextEventStartMillis: Long?,
    calendarPermissionGranted: Boolean,
    onRequestCalendarPermission: () -> Unit,
    onOpenHeadline: (String) -> Unit,
    onRefreshBrief: () -> Unit,
    onOpenWeather: () -> Unit,
    onOpenBattery: () -> Unit,
    onOpenCalendar: () -> Unit,
    onRunCommand: (String) -> Unit,
    onOpenGoogle: () -> Unit = {},
    profile: LayoutProfile = LayoutProfile.PHONE_PORTRAIT,
    modifier: Modifier = Modifier,
) {
    val nowHour = remember { LocalTime.now().hour }
    val greeting = when (nowHour) {
        in 5..11 -> "Good morning"
        in 12..17 -> "Good afternoon"
        else -> "Good evening"
    }
    val wallpaperPrimary = Color.White
    val wallpaperSecondary = Color.White.copy(alpha = 0.78f)
    val eventTiming = humanEventTime(nextEventStartMillis, nextEventInMinutes)
    val innerHorizontal = profile == LayoutProfile.INNER_FOLD && LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE

    if (innerHorizontal) {
        InnerLandscapeBrief(
            weather = weather,
            news = news,
            nextEventTitle = nextEventTitle,
            nextEventInMinutes = nextEventInMinutes,
            nextEventStartMillis = nextEventStartMillis,
            calendarPermissionGranted = calendarPermissionGranted,
            onRequestCalendarPermission = onRequestCalendarPermission,
            onOpenHeadline = onOpenHeadline,
            onOpenWeather = onOpenWeather,
            onOpenCalendar = onOpenCalendar,
            modifier = modifier,
        )
        return
    }

    LazyColumn(
        modifier = modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding(),
        contentPadding = PaddingValues(horizontal = 18.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(greeting, style = MaterialTheme.typography.headlineMedium, color = wallpaperPrimary)
                    Text("Your brief", color = wallpaperSecondary)
                }
                IconButton(onClick = onRefreshBrief) { Icon(Icons.Rounded.Refresh, "Refresh brief", tint = wallpaperPrimary) }
                IconButton(onClick = onOpenGoogle) { Icon(Icons.Rounded.Explore, "Google", tint = wallpaperPrimary) }
            }
        }

        item {
            HandGlassSurface(modifier = Modifier.fillMaxWidth(), cornerRadiusDp = 28) {
                Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        Row(
                            modifier = Modifier.weight(1f).clickable(onClick = onOpenWeather),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                        ) {
                            WeatherGraphic(weather.condition, Modifier.size(62.dp))
                            Column {
                                Text(weather.location.label.ifBlank { "Weather" }, style = MaterialTheme.typography.labelLarge)
                                Text(weather.temperatureC?.let { "${kotlin.math.round(it).toInt()}°" } ?: "—°", style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Light)
                                Text(weather.condition, color = LocalContentColor.current.copy(alpha = 0.78f))
                            }
                        }
                        Column(Modifier.clickable(onClick = onOpenBattery), horizontalAlignment = Alignment.End) {
                            Icon(Icons.Rounded.BatteryFull, null)
                            Text("${battery.percent}%", style = MaterialTheme.typography.titleLarge)
                            Text(if (battery.charging) "Charging" else "Phone", color = LocalContentColor.current.copy(alpha = 0.78f))
                        }
                    }
                    if (weather.dailyForecast.isNotEmpty()) {
                        HorizontalDivider(color = LocalContentColor.current.copy(alpha = 0.20f))
                        Row(Modifier.fillMaxWidth().clickable(onClick = onOpenWeather), horizontalArrangement = Arrangement.SpaceBetween) {
                            weather.dailyForecast.take(5).forEach { day ->
                                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                                    Text(day.dayLabel, style = MaterialTheme.typography.labelMedium)
                                    WeatherGraphic(day.condition, Modifier.size(28.dp))
                                    Text(listOfNotNull(day.highC?.let { "${kotlin.math.round(it).toInt()}°" }, day.lowC?.let { "${kotlin.math.round(it).toInt()}°" }).joinToString(" / ").ifBlank { "—" }, style = MaterialTheme.typography.bodyMedium)
                                    day.precipitationChancePercent?.takeIf { it > 0 }?.let { chance -> Text("$chance% rain", style = MaterialTheme.typography.labelSmall, color = LocalContentColor.current.copy(alpha = 0.72f)) }
                                }
                            }
                        }
                    }
                }
            }
        }

        item {
            HandGlassSurface(
                modifier = Modifier.fillMaxWidth().clickable { if (calendarPermissionGranted) onOpenCalendar() else onRequestCalendarPermission() },
                cornerRadiusDp = 24,
            ) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Icon(Icons.Rounded.Event, null)
                    Column(Modifier.weight(1f)) {
                        Text("Calendar", style = MaterialTheme.typography.labelLarge)
                        when {
                            nextEventTitle != null -> {
                                Text(nextEventTitle, style = MaterialTheme.typography.titleMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                eventTiming?.let { Text(it, color = LocalContentColor.current.copy(alpha = 0.78f)) }
                            }
                            calendarPermissionGranted -> Text("Nothing upcoming", color = LocalContentColor.current.copy(alpha = 0.78f))
                            else -> Text("Tap to enable calendar", color = LocalContentColor.current.copy(alpha = 0.78f))
                        }
                    }
                }
            }
        }

        contextDecision.effects.filterIsInstance<ContextEffect.SuggestCommand>().take(2).forEach { suggestion ->
            item(key = "context_${suggestion.title}") {
                HandGlassSurface(modifier = Modifier.fillMaxWidth().clickable { onRunCommand(suggestion.command) }, cornerRadiusDp = 24) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.AutoAwesome, null)
                        Spacer(Modifier.width(12.dp))
                        Text(suggestion.title, style = MaterialTheme.typography.titleSmall)
                    }
                }
            }
        }

        item { NewsSection("Headlines", news.headlines, news.message, onOpenHeadline, wallpaperPrimary, wallpaperSecondary) }
        item { NewsSection("Entertainment", news.entertainment, null, onOpenHeadline, wallpaperPrimary, wallpaperSecondary) }
        item { NewsSection("Tech", news.tech, null, onOpenHeadline, wallpaperPrimary, wallpaperSecondary) }
        item { NewsSection("LEGO", news.lego, null, onOpenHeadline, wallpaperPrimary, wallpaperSecondary) }
        item { Spacer(Modifier.height(8.dp)) }
    }
}

@Composable
private fun InnerLandscapeBrief(
    weather: WeatherState,
    news: NewsState,
    nextEventTitle: String?,
    nextEventInMinutes: Int?,
    nextEventStartMillis: Long?,
    calendarPermissionGranted: Boolean,
    onRequestCalendarPermission: () -> Unit,
    onOpenHeadline: (String) -> Unit,
    onOpenWeather: () -> Unit,
    onOpenCalendar: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 18.dp, vertical = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(18.dp),
    ) {
        Box(Modifier.weight(1f).fillMaxHeight(), contentAlignment = Alignment.Center) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                ClockWidget(
                    modifier = Modifier.weight(1f).height(238.dp),
                    variant = "standard",
                )
                CalendarWidget(
                    modifier = Modifier.weight(1f).height(238.dp),
                    variant = "standard",
                    nextEventInMinutes = nextEventInMinutes,
                    nextEventTitle = nextEventTitle,
                    nextEventStartMillis = nextEventStartMillis,
                    onOpenCalendar = { if (calendarPermissionGranted) onOpenCalendar() else onRequestCalendarPermission() },
                    onOpenEvent = { if (calendarPermissionGranted) onOpenCalendar() else onRequestCalendarPermission() },
                )
            }
        }

        Box(Modifier.weight(1f).fillMaxHeight(), contentAlignment = Alignment.Center) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                WeatherWidget(
                    weather = weather,
                    modifier = Modifier.weight(1f).height(238.dp),
                    variant = "standard",
                    onClick = onOpenWeather,
                )
                InnerBriefHeadlines(
                    stories = news.headlines,
                    message = news.message,
                    onOpenHeadline = onOpenHeadline,
                    modifier = Modifier.weight(1f).height(238.dp),
                )
            }
        }
    }
}

@Composable
private fun InnerBriefHeadlines(
    stories: List<NewsHeadline>,
    message: String?,
    onOpenHeadline: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val accent = LocalHandAccentPalette.current
    HandGlassSurface(modifier = modifier, cornerRadiusDp = 26, contentPadding = PaddingValues(14.dp)) {
        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Newspaper, null, tint = accent.accentStrong, modifier = Modifier.size(22.dp))
                Spacer(Modifier.width(8.dp))
                Text("Headlines", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            }
            if (stories.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(message ?: "No stories right now", style = MaterialTheme.typography.bodySmall, color = LocalContentColor.current.copy(alpha = 0.70f))
                }
            } else {
                Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    stories.take(3).forEach { headline ->
                        Row(
                            Modifier.fillMaxWidth().weight(1f).clip(RoundedCornerShape(14.dp)).clickable { onOpenHeadline(headline.url) },
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            RemoteArticleImage(
                                imageUrl = headline.imageUrl,
                                contentDescription = headline.title,
                                articleUrl = headline.url,
                                modifier = Modifier.width(54.dp).fillMaxHeight(),
                            )
                            Spacer(Modifier.width(8.dp))
                            Column(Modifier.weight(1f)) {
                                Text(headline.title, style = MaterialTheme.typography.labelLarge, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                if (headline.source.isNotBlank()) {
                                    Text(headline.source, style = MaterialTheme.typography.labelSmall, color = LocalContentColor.current.copy(alpha = 0.60f), maxLines = 1)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun NewsSection(
    title: String,
    stories: List<NewsHeadline>,
    emptyMessage: String?,
    onOpenHeadline: (String) -> Unit,
    wallpaperPrimary: Color,
    wallpaperSecondary: Color,
) {
    var expanded by remember { mutableStateOf(true) }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth().clickable { expanded = !expanded }.padding(vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(title, style = MaterialTheme.typography.titleLarge, color = wallpaperPrimary, modifier = Modifier.weight(1f))
            Icon(if (expanded) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore, if (expanded) "Collapse" else "Expand", tint = wallpaperSecondary)
        }
        if (expanded) {
            if (stories.isEmpty()) {
                HandGlassSurface(modifier = Modifier.fillMaxWidth(), cornerRadiusDp = 22) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Newspaper, null)
                        Spacer(Modifier.width(12.dp))
                        Text(emptyMessage ?: "No stories right now", color = LocalContentColor.current.copy(alpha = 0.78f))
                    }
                }
            } else {
                stories.take(5).forEach { headline ->
                    val cleanTitle = remember(headline.title, headline.source) {
                        if (headline.source.isBlank()) headline.title else headline.title.removeSuffix(" - ${headline.source}").removeSuffix(" – ${headline.source}").trim()
                    }
                    HandGlassSurface(
                        modifier = Modifier.fillMaxWidth().clickable { onOpenHeadline(headline.url) },
                        cornerRadiusDp = 22,
                        contentPadding = PaddingValues(0.dp),
                    ) {
                        Row(Modifier.fillMaxWidth().height(112.dp)) {
                            RemoteArticleImage(
                                imageUrl = headline.imageUrl,
                                contentDescription = cleanTitle,
                                articleUrl = headline.url,
                                modifier = Modifier.weight(0.20f).fillMaxHeight(),
                            )
                            Column(
                                modifier = Modifier.weight(0.80f).fillMaxHeight().padding(horizontal = 14.dp, vertical = 12.dp),
                                verticalArrangement = Arrangement.Center,
                            ) {
                                Text(cleanTitle, style = MaterialTheme.typography.titleSmall, maxLines = 3, overflow = TextOverflow.Ellipsis)
                                if (headline.source.isNotBlank()) {
                                    Spacer(Modifier.height(5.dp))
                                    Text(headline.source, style = MaterialTheme.typography.labelMedium, color = LocalContentColor.current.copy(alpha = 0.72f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun NotificationCapsule(
    notifications: List<LauncherNotification>,
    onOpenNotification: (LauncherNotification) -> Unit,
    onDismissNotification: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    if (notifications.isEmpty()) return

    val accent = LocalHandAccentPalette.current
    val scrollState = rememberScrollState()
    HandGlassSurface(
        modifier = modifier,
        cornerRadiusDp = 28,
        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 144.dp)
                .verticalScroll(scrollState),
        ) {
            notifications.forEachIndexed { index, notification ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(68.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .clickable { onOpenNotification(notification) }
                        .padding(horizontal = 2.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Row(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .padding(horizontal = 3.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(11.dp),
                    ) {
                        Box(
                            modifier = Modifier
                                .size(46.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(accent.accentFaint)
                                .border(0.8.dp, accent.outline, RoundedCornerShape(14.dp)),
                            contentAlignment = Alignment.Center,
                        ) {
                            ThemedPackageIcon(
                                packageName = notification.packageName,
                                contentDescription = null,
                                modifier = Modifier.size(34.dp),
                                sizePx = 96,
                            )
                        }
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
                            if (notification.title.isNotBlank()) {
                                Text(
                                    notification.title,
                                    style = MaterialTheme.typography.titleSmall,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            }
                            if (notification.text.isNotBlank()) {
                                Text(
                                    notification.text,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = LocalContentColor.current.copy(alpha = 0.72f),
                                    maxLines = if (notification.title.isBlank()) 2 else 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            }
                        }
                    }
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(accent.accentFaint)
                            .border(0.8.dp, accent.outline, CircleShape),
                        contentAlignment = Alignment.Center,
                    ) {
                        IconButton(
                            onClick = { onDismissNotification(notification.key) },
                            modifier = Modifier.fillMaxSize(),
                        ) {
                            Icon(Icons.Rounded.Close, contentDescription = "Dismiss notification", modifier = Modifier.size(20.dp))
                        }
                    }
                }
                if (index != notifications.lastIndex) {
                    HorizontalDivider(Modifier.padding(start = 58.dp), color = accent.accentSoft.copy(alpha = 0.30f))
                }
            }
        }
    }
}


@Composable
private fun NotificationAccessCapsule(
    onEnable: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val accent = LocalHandAccentPalette.current
    HandGlassSurface(
        modifier = modifier,
        cornerRadiusDp = 24,
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Icon(
                Icons.Rounded.NotificationsOff,
                contentDescription = null,
                tint = accent.accent,
                modifier = Modifier.size(24.dp),
            )
            Column(Modifier.weight(1f)) {
                Text("Notification access required", style = MaterialTheme.typography.titleSmall)
                Text(
                    "Enable BOAL to show notifications and media controls.",
                    style = MaterialTheme.typography.bodySmall,
                    color = LocalContentColor.current.copy(alpha = 0.72f),
                    maxLines = 2,
                )
            }
            TextButton(onClick = onEnable) { Text("Enable") }
        }
    }
}

@Composable
private fun HomeControlCapsule(
    onAutomations: () -> Unit,
    onSettings: () -> Unit,
    onEnterEditMode: () -> Unit,
    onAiDesign: () -> Unit,
    modifier: Modifier = Modifier,
) {
    HandGlassSurface(
        modifier = modifier,
        cornerRadiusDp = 30,
        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 5.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(2.dp)) {
            IconButton(onClick = onAutomations) { Icon(Icons.Rounded.Bolt, "Automations", tint = Color.White) }
            IconButton(onClick = onSettings) { Icon(Icons.Rounded.Settings, "Settings", tint = Color.White) }
            IconButton(onClick = onEnterEditMode) { Icon(Icons.Rounded.Edit, "Edit Home", tint = Color.White) }
            IconButton(onClick = onAiDesign) { Icon(Icons.Rounded.AutoAwesome, "AI Design", tint = Color.White) }
        }
    }
}

@Composable
private fun HomeEditControls(
    activeLayout: LauncherLayout?,
    onAddObject: () -> Unit,
    onToggleFinePositioning: () -> Unit,
    onToggleLock: () -> Unit,
    onExitEditMode: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(modifier, verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.End) {
        FilledTonalIconButton(onClick = onAddObject) { Icon(Icons.Rounded.Add, "Add object") }
        FilledTonalIconButton(onClick = onToggleFinePositioning) { Icon(if (activeLayout?.finePositioning == true) Icons.Rounded.OpenWith else Icons.Rounded.Grid4x4, "Positioning") }
        FilledTonalIconButton(onClick = onToggleLock) { Icon(Icons.Rounded.Lock, "Lock") }
        Button(onClick = onExitEditMode) { Text("Done") }
    }
}

@Composable
fun PhoneHomePage(
    apps: List<AppEntry>,
    smartObjectOverrides: Map<String, SmartObject>,
    smartStacks: Map<String, SmartStackDefinition>,
    battery: BatteryState,
    weather: WeatherState,
    media: MediaPlaybackState,
    connectivity: ConnectivityState,
    notifications: List<LauncherNotification>,
    notificationAccessGranted: Boolean,
    contextDecision: ContextDecision,
    connectedDeviceNames: Set<String>,
    nextEventInMinutes: Int?,
    nextEventTitle: String?,
    nextEventStartMillis: Long?,
    loadStackPosition: (String) -> Int,
    onStackPositionChanged: (String, Int) -> Unit,
    homePageVisible: Boolean,
    profile: LayoutProfile,
    activeLayout: LauncherLayout?,
    editMode: Boolean,
    isHomeRoleHeld: Boolean,
    requestHomeRole: () -> Unit,
    onLaunch: (AppEntry) -> Unit,
    onEditSmartObject: (AppEntry) -> Unit,
    onSearch: () -> Unit,
    onLibrary: () -> Unit,
    onOpenNotificationShade: () -> Unit,
    onOpenQuickSettings: () -> Unit,
    onAiDesign: () -> Unit,
    onAutomations: () -> Unit,
    onSettings: () -> Unit,
    onOpenClock: () -> Unit,
    onOpenCalendar: () -> Unit,
    onOpenCalendarApp: () -> Unit,
    onOpenWeather: () -> Unit,
    onOpenBattery: () -> Unit,
    onOpenMedia: () -> Unit,
    onMediaPlayPause: () -> Unit,
    onMediaPrevious: () -> Unit,
    onMediaNext: () -> Unit,
    onMediaSeek: (Long) -> Unit,
    onOpenNotification: (LauncherNotification) -> Unit,
    onDismissNotification: (String) -> Unit,
    onRequestNotificationAccess: () -> Unit,
    onRunCommand: (String) -> Unit,
    onAddObject: () -> Unit,
    onEnterEditMode: () -> Unit,
    onExitEditMode: () -> Unit,
    onToggleLock: () -> Unit,
    onToggleFinePositioning: () -> Unit,
    onObjectGesture: (SmartObject, GestureSlot) -> Unit,
    onObjectRectChange: (String, GridRect, Boolean) -> Unit,
    onRemoveObject: (SmartObject) -> Unit,
    onEditObject: (SmartObject) -> Unit,
    widgetHostController: AndroidWidgetHostController,
    modifier: Modifier = Modifier,
) {
    var verticalDrag by remember { mutableFloatStateOf(0f) }
    val density = LocalDensity.current
    val view = LocalView.current
    val cutoutAwarePhoneProfile = profile == LayoutProfile.COVER || profile == LayoutProfile.PHONE_PORTRAIT
    var physicalCutoutBottomPx by remember(view, profile) { mutableIntStateOf(0) }
    DisposableEffect(view, profile) {
        fun refreshCutoutBounds() {
            physicalCutoutBottomPx = if (cutoutAwarePhoneProfile) {
                view.rootWindowInsets?.displayCutout?.boundingRects
                    ?.filter { it.top <= view.height / 3 }
                    ?.maxOfOrNull { it.bottom }
                    ?: 0
            } else {
                0
            }
        }
        val listener = android.view.ViewTreeObserver.OnGlobalLayoutListener { refreshCutoutBounds() }
        view.viewTreeObserver.addOnGlobalLayoutListener(listener)
        refreshCutoutBounds()
        onDispose {
            if (view.viewTreeObserver.isAlive) {
                view.viewTreeObserver.removeOnGlobalLayoutListener(listener)
            }
        }
    }
    val coverCutoutTopPadding = if (cutoutAwarePhoneProfile && physicalCutoutBottomPx > 0) {
        with(density) { (physicalCutoutBottomPx.toFloat() + 0.5f).toDp() }
    } else {
        6.dp
    }
    val gestureThresholdPx = with(density) { 96.dp.toPx() }
    val maxGestureTravelPx = with(density) { 24.dp.toPx() }
    val gestureTranslation by animateFloatAsState(
        targetValue = (verticalDrag * 0.14f).coerceIn(-maxGestureTravelPx, maxGestureTravelPx),
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "homeGestureTranslation",
    )
    val innerHorizontal = profile == LayoutProfile.INNER_FOLD && LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE

    Box(
        modifier = modifier.fillMaxSize().then(
            if (!editMode && activeLayout == null) Modifier.pointerInput(Unit) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    val width = size.width.coerceAtLeast(1).toFloat()
                    // Home is split into three explicit downward gesture zones:
                    // left 30% -> Notifications, center 40% -> BOAL Search,
                    // right 30% -> full Quick Settings. Upward App Library stays global.
                    val downZone = when {
                        down.position.x < width * 0.30f -> 0
                        down.position.x > width * 0.70f -> 2
                        else -> 1
                    }
                    val systemGestureThresholdPx = with(density) { 56.dp.toPx() }
                    val directionDominance = 1.20f
                    var totalX = 0f
                    var totalY = 0f
                    var verticalIntentLocked = false
                    var systemActionFired = false

                    while (true) {
                        val event = awaitPointerEvent()
                        val change = event.changes.firstOrNull { it.id == down.id } ?: break
                        if (!change.pressed) break

                        val delta = change.positionChange()
                        totalX += delta.x
                        totalY += delta.y

                        if (!verticalIntentLocked) {
                            val absX = abs(totalX)
                            val absY = abs(totalY)
                            val crossedTouchSlop = maxOf(absX, absY) > viewConfiguration.touchSlop

                            if (crossedTouchSlop && absX > absY * directionDominance) {
                                // Horizontal intent belongs to the outer Home/Brief/Workspace pager.
                                // Yield immediately and, crucially, do not consume any movement.
                                // This makes page throws work from almost the whole Home surface
                                // while Smart Stack and other true horizontal children retain
                                // their own gesture ownership.
                                verticalDrag = 0f
                                return@awaitEachGesture
                            }

                            if (crossedTouchSlop && absY > absX * directionDominance) {
                                verticalIntentLocked = true
                            }
                        }

                        if (verticalIntentLocked) {
                            verticalDrag = totalY
                            change.consume()

                            // System panels should feel immediate: fire once as soon as
                            // the downward swipe is intentional instead of waiting for lift.
                            if (!systemActionFired && totalY > systemGestureThresholdPx && downZone != 1) {
                                systemActionFired = true
                                if (downZone == 0) onOpenNotificationShade() else onOpenQuickSettings()
                            }
                        }
                    }

                    if (verticalIntentLocked && !systemActionFired && abs(totalY) > gestureThresholdPx) {
                        if (totalY > 0f) onSearch() else onLibrary()
                    }
                    verticalDrag = 0f
                }
            } else Modifier
        )
    ) {
        if (innerHorizontal && activeLayout == null && !editMode) {
            InnerLandscapeHome(
                battery = battery,
                weather = weather,
                connectedDeviceNames = connectedDeviceNames,
                nextEventInMinutes = nextEventInMinutes,
                nextEventTitle = nextEventTitle,
                nextEventStartMillis = nextEventStartMillis,
                onOpenClock = onOpenClock,
                onOpenCalendar = onOpenCalendarApp,
                onOpenCalendarEvent = onOpenCalendar,
                onOpenWeather = onOpenWeather,
                onOpenBattery = onOpenBattery,
                modifier = Modifier.fillMaxSize().graphicsLayer { translationY = gestureTranslation },
            )
            return@Box
        }

        Column(
            modifier = Modifier.fillMaxSize()
                .graphicsLayer { translationY = gestureTranslation }
                .navigationBarsPadding()
                .padding(start = 14.dp, end = 14.dp, top = coverCutoutTopPadding),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            if (activeLayout == null) {
                val homeStack = smartStacks["default_home_stack"] ?: smartStacks.values.firstOrNull()
                val homeStackId = homeStack?.id ?: "default_home_stack"
                SmartWidgetStack(
                    battery = battery,
                    contextDecision = contextDecision,
                    modifier = Modifier.fillMaxWidth().height(if (profile == LayoutProfile.INNER_FOLD) 222.dp else 214.dp),
                    definition = homeStack,
                    connectedDeviceNames = connectedDeviceNames,
                    connectivity = connectivity,
                    nextEventInMinutes = nextEventInMinutes,
                    nextEventTitle = nextEventTitle,
                    nextEventStartMillis = nextEventStartMillis,
                    weather = weather,
                    media = media,
                    initialPermanentIndex = loadStackPosition(homeStackId),
                    onPermanentIndexChanged = { onStackPositionChanged(homeStackId, it) },
                    autoAdvanceAllowed = homePageVisible,
                    onOpenClock = onOpenClock,
                    onOpenCalendar = onOpenCalendarApp,
                    onOpenCalendarEvent = onOpenCalendar,
                    onOpenWeather = onOpenWeather,
                    onOpenBattery = onOpenBattery,
                    onOpenMedia = onOpenMedia,
                    onMediaPlayPause = onMediaPlayPause,
                    onMediaPrevious = onMediaPrevious,
                    onMediaNext = onMediaNext,
                    onMediaSeek = onMediaSeek,
                )

                if (editMode) {
                    HomeEditControls(
                        activeLayout = activeLayout,
                        onAddObject = onAddObject,
                        onToggleFinePositioning = onToggleFinePositioning,
                        onToggleLock = onToggleLock,
                        onExitEditMode = onExitEditMode,
                        modifier = Modifier.fillMaxWidth(),
                    )
                } else {
                    HomeControlCapsule(
                        onAutomations = onAutomations,
                        onSettings = onSettings,
                        onEnterEditMode = onEnterEditMode,
                        onAiDesign = onAiDesign,
                        modifier = Modifier.align(Alignment.End),
                    )
                    if (notificationAccessGranted) {
                        NotificationCapsule(
                            notifications = notifications,
                            onOpenNotification = onOpenNotification,
                            onDismissNotification = onDismissNotification,
                            modifier = Modifier.fillMaxWidth(),
                        )
                    } else {
                        NotificationAccessCapsule(
                            onEnable = onRequestNotificationAccess,
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                }

                if (!isHomeRoleHeld && !editMode) {
                    ElevatedCard(shape = RoundedCornerShape(24.dp)) {
                        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Icon(Icons.Rounded.Home, null)
                            Text("Make this your default Home", fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                            Button(onClick = requestHomeRole) { Text("Choose") }
                        }
                    }
                }

                if (!editMode) {
                    contextDecision.effects.filterIsInstance<ContextEffect.SuggestCommand>().firstOrNull()?.let { suggestion ->
                        ElevatedCard(onClick = { onRunCommand(suggestion.command) }, shape = RoundedCornerShape(22.dp)) {
                            Row(
                                Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                            ) {
                                Icon(Icons.Rounded.AutoAwesome, null)
                                Text(suggestion.title, style = MaterialTheme.typography.labelLarge, modifier = Modifier.weight(1f))
                                Icon(Icons.Rounded.ChevronRight, null)
                            }
                        }
                    }
                }
                Spacer(Modifier.weight(1f))
            } else {
                DeclarativeLayoutCanvas(
                    layout = activeLayout,
                    apps = apps,
                    battery = battery,
                    weather = weather,
                    media = media,
                    connectivity = connectivity,
                    contextDecision = contextDecision,
                    connectedDeviceNames = connectedDeviceNames,
                    nextEventInMinutes = nextEventInMinutes,
                    nextEventTitle = nextEventTitle,
                    nextEventStartMillis = nextEventStartMillis,
                    smartStacks = smartStacks,
                    editMode = editMode,
                    onGesture = onObjectGesture,
                    onRectChange = onObjectRectChange,
                    onRemoveObject = onRemoveObject,
                    onEditObject = onEditObject,
                    loadStackPosition = loadStackPosition,
                    onStackPositionChanged = onStackPositionChanged,
                    stackAutoAdvanceAllowed = homePageVisible,
                    onOpenClock = onOpenClock,
                    onOpenCalendar = onOpenCalendarApp,
                    onOpenCalendarEvent = onOpenCalendar,
                    onOpenWeather = onOpenWeather,
                    onOpenBattery = onOpenBattery,
                    onOpenMedia = onOpenMedia,
                    onMediaPlayPause = onMediaPlayPause,
                    onMediaPrevious = onMediaPrevious,
                    onMediaNext = onMediaNext,
                    onMediaSeek = onMediaSeek,
                    onBackgroundSwipeDown = onSearch,
                    onBackgroundSwipeLeftDown = onOpenNotificationShade,
                    onBackgroundSwipeRightDown = onOpenQuickSettings,
                    onBackgroundSwipeUp = onLibrary,
                    widgetHostController = widgetHostController,
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                )

                if (editMode) {
                    HomeEditControls(
                        activeLayout = activeLayout,
                        onAddObject = onAddObject,
                        onToggleFinePositioning = onToggleFinePositioning,
                        onToggleLock = onToggleLock,
                        onExitEditMode = onExitEditMode,
                        modifier = Modifier.fillMaxWidth(),
                    )
                } else {
                    HomeControlCapsule(
                        onAutomations = onAutomations,
                        onSettings = onSettings,
                        onEnterEditMode = onEnterEditMode,
                        onAiDesign = onAiDesign,
                        modifier = Modifier.align(Alignment.End),
                    )
                }
            }

            if (editMode) {
                Text(
                    if (activeLayout?.finePositioning == true) "Fine positioning" else "Grid snapping",
                    modifier = Modifier.align(Alignment.CenterHorizontally),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                )
            }
        }
    }
}

@Composable
private fun InnerLandscapeHome(
    battery: BatteryState,
    weather: WeatherState,
    connectedDeviceNames: Set<String>,
    nextEventInMinutes: Int?,
    nextEventTitle: String?,
    nextEventStartMillis: Long?,
    onOpenClock: () -> Unit,
    onOpenCalendar: () -> Unit,
    onOpenCalendarEvent: () -> Unit,
    onOpenWeather: () -> Unit,
    onOpenBattery: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier.navigationBarsPadding().padding(horizontal = 18.dp, vertical = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(18.dp),
    ) {
        Row(
            modifier = Modifier.weight(1f).fillMaxHeight(),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.Top,
        ) {
            ClockWidget(
                modifier = Modifier.weight(1f).height(244.dp),
                variant = "standard",
                onClick = onOpenClock,
            )
            CalendarWidget(
                modifier = Modifier.weight(1f).height(244.dp),
                variant = "standard",
                nextEventInMinutes = nextEventInMinutes,
                nextEventTitle = nextEventTitle,
                nextEventStartMillis = nextEventStartMillis,
                onOpenCalendar = onOpenCalendar,
                onOpenEvent = onOpenCalendarEvent,
            )
        }
        Row(
            modifier = Modifier.weight(1f).fillMaxHeight(),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.Top,
        ) {
            WeatherWidget(
                weather = weather,
                modifier = Modifier.weight(1f).height(244.dp),
                variant = "standard",
                onClick = onOpenWeather,
            )
            BatteryWidget(
                battery = battery,
                modifier = Modifier.weight(1f).height(244.dp),
                variant = "standard",
                connectedDeviceNames = connectedDeviceNames,
                onClick = onOpenBattery,
            )
        }
    }
}

@Composable
fun ExtraHomePage(
    contextDecision: ContextDecision,
    battery: BatteryState,
    weather: WeatherState,
    connectivity: ConnectivityState,
    onToggleMobileData: () -> Unit,
    onToggleBluetooth: () -> Unit,
    onToggleWifi: () -> Unit,
    onToggleHotspot: () -> Unit,
    profile: LayoutProfile,
    widgetHostController: AndroidWidgetHostController,
    notifications: List<LauncherNotification>,
    systemState: WorkspaceSystemState,
    energyState: EnergyGridState,
    carouselInitialIndex: Int,
    showlyShowsWidgetId: Int?,
    showlyMoviesWidgetId: Int?,
    onCarouselIndexChanged: (Int) -> Unit,
    onRequestEnergyHealthAccess: () -> Unit,
    onSetupShowly: () -> Unit,
    onOpenNotification: (LauncherNotification) -> Unit,
    onOpenWorkspacePackage: (String) -> Unit,
) {
    val accent = LocalHandAccentPalette.current
    val innerHorizontal = profile == LayoutProfile.INNER_FOLD && LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE

    if (innerHorizontal) {
        WorkspaceInnerLandscape(
            battery = battery,
            weather = weather,
            systemState = systemState,
            notifications = notifications,
            showlyShowsWidgetId = showlyShowsWidgetId,
            showlyMoviesWidgetId = showlyMoviesWidgetId,
            widgetHostController = widgetHostController,
            onSetupShowly = onSetupShowly,
            onOpenNotification = onOpenNotification,
            onOpenPackage = onOpenWorkspacePackage,
            modifier = Modifier.fillMaxSize(),
        )
        return
    }

    Column(
        modifier = Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("Workspace", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.SemiBold)

        HandGlassSurface(modifier = Modifier.fillMaxWidth(), cornerRadiusDp = 26, contentPadding = PaddingValues(16.dp)) {
            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.AutoAwesome, null, tint = accent.accentStrong)
                    Spacer(Modifier.width(8.dp))
                    Text("At a glance", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    WorkspaceMetric(
                        modifier = Modifier.weight(1f),
                        icon = Icons.Rounded.BatteryFull,
                        label = "Battery",
                        value = "${battery.percent}%",
                        detail = if (battery.charging) "Charging" else "On battery",
                    )
                    WorkspaceMetric(
                        modifier = Modifier.weight(1f),
                        icon = Icons.Rounded.Cloud,
                        label = "Weather",
                        value = weather.temperatureC?.let { "${kotlin.math.round(it).toInt()}°" } ?: "—°",
                        detail = weather.condition,
                    )
                    WorkspaceMetric(
                        modifier = Modifier.weight(1.15f),
                        icon = Icons.Rounded.LocationOn,
                        label = "Location",
                        value = weather.location.label.ifBlank { "Weather" },
                        detail = if (weather.available) "Live" else "Saved",
                    )
                }
                contextDecision.effects.filterIsInstance<ContextEffect.SuggestCommand>().firstOrNull()?.let { suggestion ->
                    HorizontalDivider(color = accent.outline.copy(alpha = 0.35f))
                    Text(suggestion.title, style = MaterialTheme.typography.bodySmall, color = LocalContentColor.current.copy(alpha = 0.72f))
                }
            }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            WorkspaceConnectivityButton(
                modifier = Modifier.weight(1f),
                icon = Icons.Rounded.SignalCellularAlt,
                label = "Mobile data",
                detail = if (connectivity.mobileDataEnabled) connectivity.mobileType else "Off",
                enabled = connectivity.mobileDataEnabled,
                onClick = onToggleMobileData,
            )
            WorkspaceConnectivityButton(
                modifier = Modifier.weight(1f),
                icon = Icons.Rounded.Bluetooth,
                label = "Bluetooth",
                detail = if (!connectivity.bluetoothEnabled) "Off" else connectivity.bluetoothDeviceNames.firstOrNull() ?: "On",
                enabled = connectivity.bluetoothEnabled,
                onClick = onToggleBluetooth,
            )
            WorkspaceConnectivityButton(
                modifier = Modifier.weight(1f),
                icon = Icons.Rounded.Wifi,
                label = "Wi-Fi",
                detail = when {
                    !connectivity.wifiEnabled -> "Off"
                    connectivity.wifiConnected -> connectivity.wifiName
                    else -> "On"
                },
                enabled = connectivity.wifiEnabled,
                onClick = onToggleWifi,
            )
            WorkspaceConnectivityButton(
                modifier = Modifier.weight(1f),
                icon = Icons.Rounded.WifiTethering,
                label = "Hotspot",
                detail = if (connectivity.hotspotEnabled) "On" else "Off",
                enabled = connectivity.hotspotEnabled,
                onClick = onToggleHotspot,
            )
        }

        WorkspaceModuleCarousel(
            battery = battery,
            weather = weather,
            systemState = systemState,
            energyState = energyState,
            notifications = notifications,
            initialIndex = carouselInitialIndex,
            showlyShowsWidgetId = showlyShowsWidgetId,
            showlyMoviesWidgetId = showlyMoviesWidgetId,
            widgetHostController = widgetHostController,
            onIndexChanged = onCarouselIndexChanged,
            onRequestEnergyHealthAccess = onRequestEnergyHealthAccess,
            onSetupShowly = onSetupShowly,
            onOpenNotification = onOpenNotification,
            onOpenPackage = onOpenWorkspacePackage,
            modifier = Modifier.fillMaxWidth().weight(1f),
        )
    }
}

@Composable
private fun WorkspaceMetric(
    modifier: Modifier,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    value: String,
    detail: String,
) {
    val accent = LocalHandAccentPalette.current
    Column(modifier, verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Surface(shape = RoundedCornerShape(14.dp), color = accent.accentFaint) {
            Icon(icon, null, tint = accent.accentStrong, modifier = Modifier.padding(9.dp).size(20.dp))
        }
        Text(label, style = MaterialTheme.typography.labelSmall, color = LocalContentColor.current.copy(alpha = 0.65f))
        Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(detail, style = MaterialTheme.typography.labelSmall, color = LocalContentColor.current.copy(alpha = 0.65f), maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun WorkspaceConnectivityButton(
    modifier: Modifier,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    detail: String,
    enabled: Boolean,
    onClick: () -> Unit,
) {
    val accent = LocalHandAccentPalette.current
    Surface(
        modifier = modifier.height(78.dp).clickable(onClick = onClick),
        shape = RoundedCornerShape(24.dp),
        color = if (enabled) accent.accent.copy(alpha = 0.82f) else MaterialTheme.colorScheme.surface.copy(alpha = 0.64f),
        border = androidx.compose.foundation.BorderStroke(0.8.dp, if (enabled) accent.accentStrong else accent.outline),
    ) {
        Column(
            Modifier.fillMaxSize().padding(horizontal = 5.dp, vertical = 9.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Icon(icon, null, tint = Color.White, modifier = Modifier.size(21.dp))
            Spacer(Modifier.height(4.dp))
            Text(
                label,
                color = Color.White,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.labelMedium,
            )
            Text(
                detail,
                color = Color.White.copy(alpha = if (enabled) 0.86f else 0.62f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.labelSmall,
            )
        }
    }
}

@Composable
private fun WorkspaceChatBubble(message: WorkspaceChatMessage) {
    val accent = LocalHandAccentPalette.current
    val fromUser = message.role == WorkspaceChatRole.USER
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (fromUser) Arrangement.End else Arrangement.Start) {
        Surface(
            modifier = Modifier.fillMaxWidth(0.91f),
            shape = RoundedCornerShape(18.dp),
            color = if (fromUser) accent.accentFaint else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.42f),
            border = androidx.compose.foundation.BorderStroke(0.6.dp, accent.outline.copy(alpha = if (fromUser) 0.65f else 0.32f)),
        ) {
            Row(Modifier.padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.Top) {
                Icon(
                    if (fromUser) Icons.Rounded.Person else Icons.Rounded.AutoAwesome,
                    null,
                    tint = if (fromUser) LocalContentColor.current.copy(alpha = 0.72f) else accent.accentStrong,
                    modifier = Modifier.size(18.dp),
                )
                Spacer(Modifier.width(8.dp))
                Text(message.text, style = MaterialTheme.typography.bodyMedium, maxLines = 4, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
fun DesktopHomePage(
    apps: List<AppEntry>,
    smartObjectOverrides: Map<String, SmartObject>,
    smartStacks: Map<String, SmartStackDefinition>,
    battery: BatteryState,
    weather: WeatherState,
    media: MediaPlaybackState,
    connectivity: ConnectivityState,
    contextDecision: ContextDecision,
    connectedDeviceNames: Set<String>,
    nextEventInMinutes: Int?,
    nextEventTitle: String?,
    nextEventStartMillis: Long?,
    loadStackPosition: (String) -> Int,
    onStackPositionChanged: (String, Int) -> Unit,
    activeLayout: LauncherLayout?,
    editMode: Boolean,
    onLaunch: (AppEntry) -> Unit,
    onEditSmartObject: (AppEntry) -> Unit,
    onSearch: () -> Unit,
    onAiDesign: () -> Unit,
    onAutomations: () -> Unit,
    onSettings: () -> Unit,
    onOpenClock: () -> Unit,
    onOpenCalendar: () -> Unit,
    onOpenCalendarApp: () -> Unit,
    onOpenWeather: () -> Unit,
    onOpenBattery: () -> Unit,
    onOpenMedia: () -> Unit,
    onMediaPlayPause: () -> Unit,
    onMediaPrevious: () -> Unit,
    onMediaNext: () -> Unit,
    onMediaSeek: (Long) -> Unit,
    onAddObject: () -> Unit,
    onEnterEditMode: () -> Unit,
    onExitEditMode: () -> Unit,
    onToggleLock: () -> Unit,
    onToggleFinePositioning: () -> Unit,
    onObjectGesture: (SmartObject, GestureSlot) -> Unit,
    onObjectRectChange: (String, GridRect, Boolean) -> Unit,
    onRemoveObject: (SmartObject) -> Unit,
    onEditObject: (SmartObject) -> Unit,
    widgetHostController: AndroidWidgetHostController,
) {
    Row(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(14.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        Surface(modifier = Modifier.width(250.dp).fillMaxHeight(), shape = RoundedCornerShape(28.dp), tonalElevation = 3.dp) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Workspace", style = MaterialTheme.typography.titleLarge)
                NavigationDrawerItem(label = { Text("Search") }, selected = false, icon = { Icon(Icons.Rounded.Search, null) }, onClick = onSearch)
                NavigationDrawerItem(label = { Text("AI Design") }, selected = false, icon = { Icon(Icons.Rounded.AutoAwesome, null) }, onClick = onAiDesign)
                NavigationDrawerItem(label = { Text("Automations") }, selected = false, icon = { Icon(Icons.Rounded.Bolt, null) }, onClick = onAutomations)
                NavigationDrawerItem(label = { Text("Settings") }, selected = false, icon = { Icon(Icons.Rounded.Settings, null) }, onClick = onSettings)
                HorizontalDivider()
                if (editMode) {
                    Button(onClick = onAddObject, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Rounded.Add, null); Spacer(Modifier.width(6.dp)); Text("Add object") }
                    Button(onClick = onExitEditMode, modifier = Modifier.fillMaxWidth()) { Text("Done editing") }
                    FilledTonalButton(onClick = onToggleFinePositioning, modifier = Modifier.fillMaxWidth()) { Text(if (activeLayout?.finePositioning == true) "Fine positioning" else "Grid snapping") }
                    FilledTonalButton(onClick = onToggleLock, modifier = Modifier.fillMaxWidth()) { Text("Lock layout") }
                } else {
                    Button(onClick = onEnterEditMode, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Rounded.Edit, null); Spacer(Modifier.width(8.dp)); Text("Edit layout") }
                    if (activeLayout?.locked == true) TextButton(onClick = onToggleLock, modifier = Modifier.fillMaxWidth()) { Text("Unlock layout") }
                }
                Spacer(Modifier.weight(1f))
                Text("Battery ${battery.percent}%", style = MaterialTheme.typography.labelMedium)
            }
        }

        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            if (activeLayout != null) {
                DeclarativeLayoutCanvas(
                    layout = activeLayout,
                    apps = apps,
                    battery = battery,
                    weather = weather,
                    media = media,
                    connectivity = connectivity,
                    contextDecision = contextDecision,
                    connectedDeviceNames = connectedDeviceNames,
                    nextEventInMinutes = nextEventInMinutes,
                    nextEventTitle = nextEventTitle,
                    nextEventStartMillis = nextEventStartMillis,
                    smartStacks = smartStacks,
                    editMode = editMode,
                    onGesture = onObjectGesture,
                    onRectChange = onObjectRectChange,
                    onRemoveObject = onRemoveObject,
                    onEditObject = onEditObject,
                    loadStackPosition = loadStackPosition,
                    onStackPositionChanged = onStackPositionChanged,
                    onOpenClock = onOpenClock,
                    onOpenCalendar = onOpenCalendarApp,
                    onOpenCalendarEvent = onOpenCalendar,
                    onOpenWeather = onOpenWeather,
                    onOpenBattery = onOpenBattery,
                    onOpenMedia = onOpenMedia,
                    onMediaPlayPause = onMediaPlayPause,
                    onMediaPrevious = onMediaPrevious,
                    onMediaNext = onMediaNext,
                    onMediaSeek = onMediaSeek,
                    widgetHostController = widgetHostController,
                    modifier = Modifier.fillMaxSize(),
                )
            } else {
                val homeStack = smartStacks["default_home_stack"] ?: smartStacks.values.firstOrNull()
                val homeStackId = homeStack?.id ?: "default_home_stack"
                SmartWidgetStack(
                    battery = battery,
                    contextDecision = contextDecision,
                    modifier = Modifier.height(220.dp),
                    definition = homeStack,
                    connectedDeviceNames = connectedDeviceNames,
                    connectivity = connectivity,
                    nextEventInMinutes = nextEventInMinutes,
                    nextEventTitle = nextEventTitle,
                    nextEventStartMillis = nextEventStartMillis,
                    weather = weather,
                    media = media,
                    initialPermanentIndex = loadStackPosition(homeStackId),
                    onPermanentIndexChanged = { onStackPositionChanged(homeStackId, it) },
                    onOpenClock = onOpenClock,
                    onOpenCalendar = onOpenCalendarApp,
                    onOpenCalendarEvent = onOpenCalendar,
                    onOpenWeather = onOpenWeather,
                    onOpenBattery = onOpenBattery,
                    onOpenMedia = onOpenMedia,
                    onMediaPlayPause = onMediaPlayPause,
                    onMediaPrevious = onMediaPrevious,
                    onMediaNext = onMediaNext,
                    onMediaSeek = onMediaSeek,
                )
                Text("Apps", style = MaterialTheme.typography.titleLarge)
                LazyVerticalGrid(columns = GridCells.Adaptive(100.dp), modifier = Modifier.fillMaxSize()) {
                    items(apps, key = { it.stableId }) { app ->
                        AppIcon(app, { onLaunch(app) }, displayLabel = smartObjectOverrides[app.stableId]?.title ?: app.label, onLongClick = { onEditSmartObject(app) })
                    }
                }
            }
        }
    }
}
