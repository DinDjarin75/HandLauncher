package com.handlauncher.platform

import android.app.Notification
import android.app.PendingIntent
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.handlauncher.data.LauncherNotification
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Shared notification/media listener used by launcher surfaces after explicit user permission. */
class LauncherNotificationListener : NotificationListenerService() {
    override fun onListenerConnected() {
        instance = this
        publish(activeNotifications.orEmpty())
    }

    override fun onListenerDisconnected() {
        if (instance === this) instance = null
        _notifications.value = emptyList()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        publish(activeNotifications.orEmpty())
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        publish(activeNotifications.orEmpty())
    }

    private fun publish(items: Array<out StatusBarNotification>) {
        _notifications.value = items.asSequence()
            .filter(::isEligible)
            .map(::toModel)
            .sortedByDescending { it.postTime }
            .toList()
    }

    private fun isEligible(sbn: StatusBarNotification): Boolean {
        val n = sbn.notification
        val flags = n.flags
        if (sbn.packageName == packageName) return false
        if (!sbn.isClearable) return false
        if (sbn.isOngoing) return false
        if (flags and Notification.FLAG_ONGOING_EVENT != 0) return false
        if (flags and Notification.FLAG_NO_CLEAR != 0) return false
        if (flags and Notification.FLAG_FOREGROUND_SERVICE != 0) return false
        if (flags and Notification.FLAG_GROUP_SUMMARY != 0) return false
        val title = n.extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = n.extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
            .ifBlank { n.extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString().orEmpty() }
        return title.isNotBlank() || text.isNotBlank()
    }

    private fun toModel(sbn: StatusBarNotification): LauncherNotification {
        val n = sbn.notification
        return LauncherNotification(
            key = sbn.key,
            packageName = sbn.packageName,
            title = n.extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty(),
            text = n.extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
                .ifBlank { n.extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString().orEmpty() },
            postTime = sbn.postTime,
        )
    }

    companion object {
        @Volatile private var instance: LauncherNotificationListener? = null
        private val _notifications = MutableStateFlow<List<LauncherNotification>>(emptyList())
        val notifications: StateFlow<List<LauncherNotification>> = _notifications.asStateFlow()

        fun dismiss(key: String) {
            runCatching { instance?.cancelNotification(key) }
        }

        fun open(key: String) {
            val service = instance ?: return
            val target = service.activeNotifications?.firstOrNull { it.key == key } ?: return
            val intent: PendingIntent = target.notification.contentIntent ?: return
            runCatching { intent.send() }
        }
    }
}
