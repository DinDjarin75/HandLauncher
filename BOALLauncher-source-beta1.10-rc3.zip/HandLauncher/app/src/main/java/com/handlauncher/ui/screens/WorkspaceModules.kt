package com.handlauncher.ui.screens

import android.content.pm.PackageManager
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.handlauncher.data.*
import com.handlauncher.platform.AndroidWidgetHostController
import com.handlauncher.ui.components.AndroidHostedWidget
import com.handlauncher.ui.components.HandGlassSurface
import com.handlauncher.ui.components.ThemedPackageIcon
import com.handlauncher.ui.components.WeatherGraphic
import com.handlauncher.ui.theme.LocalHandAccentPalette
import kotlinx.coroutines.delay
import java.time.Instant
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import kotlin.math.roundToInt

private enum class WorkspaceModule(val label: String) {
    SYSTEM("System"),
    WORLD_CLOCK("World Clock"),
    COMMS_RADAR("Comms Radar"),
    WEATHER_ATLAS("Weather Atlas"),
    ENERGY_GRID("Energy Grid"),
    CINE_CLUB("Ciné Club"),
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun WorkspaceModuleCarousel(
    battery: BatteryState,
    weather: WeatherState,
    systemState: WorkspaceSystemState,
    energyState: EnergyGridState,
    notifications: List<LauncherNotification>,
    initialIndex: Int,
    showlyShowsWidgetId: Int?,
    showlyMoviesWidgetId: Int?,
    widgetHostController: AndroidWidgetHostController,
    onIndexChanged: (Int) -> Unit,
    onRequestEnergyHealthAccess: () -> Unit,
    onSetupShowly: () -> Unit,
    onOpenNotification: (LauncherNotification) -> Unit,
    onOpenPackage: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val modules = remember { WorkspaceModule.entries }
    val moduleCount = modules.size
    val safeInitial = initialIndex.coerceIn(0, moduleCount - 1)
    val pagerState = rememberPagerState(initialPage = safeInitial + 1, pageCount = { moduleCount + 2 })

    LaunchedEffect(pagerState.settledPage) {
        when (pagerState.settledPage) {
            0 -> pagerState.scrollToPage(moduleCount)
            moduleCount + 1 -> pagerState.scrollToPage(1)
            else -> onIndexChanged(pagerState.settledPage - 1)
        }
    }

    val canonicalPage = when (pagerState.currentPage) {
        0 -> moduleCount - 1
        moduleCount + 1 -> 0
        else -> pagerState.currentPage - 1
    }.coerceIn(0, moduleCount - 1)

    Box(modifier = modifier) {
        HorizontalPager(
            state = pagerState,
            modifier = Modifier.fillMaxSize(),
            beyondViewportPageCount = 1,
        ) { virtualPage ->
            val moduleIndex = when (virtualPage) {
                0 -> moduleCount - 1
                moduleCount + 1 -> 0
                else -> virtualPage - 1
            }
            HandGlassSurface(
                modifier = Modifier.fillMaxSize().padding(horizontal = 1.dp, vertical = 1.dp),
                cornerRadiusDp = 26,
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 14.dp),
            ) {
                Column(Modifier.fillMaxSize()) {
                    Box(Modifier.weight(1f).fillMaxWidth()) {
                        when (modules[moduleIndex]) {
                            WorkspaceModule.SYSTEM -> SystemModule(battery, systemState)
                            WorkspaceModule.WORLD_CLOCK -> WorldClockModule()
                            WorkspaceModule.COMMS_RADAR -> CommsRadarModule(notifications, onOpenNotification, onOpenPackage)
                            WorkspaceModule.WEATHER_ATLAS -> WeatherAtlasModule(weather)
                            WorkspaceModule.ENERGY_GRID -> EnergyGridModule(energyState, onRequestEnergyHealthAccess)
                            WorkspaceModule.CINE_CLUB -> CineClubModule(
                                showlyShowsWidgetId = showlyShowsWidgetId,
                                showlyMoviesWidgetId = showlyMoviesWidgetId,
                                widgetHostController = widgetHostController,
                                onSetupShowly = onSetupShowly,
                                onOpenShowly = { onOpenPackage(SHOWLY_PACKAGE) },
                            )
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        modules.indices.forEach { index ->
                            val selected = index == canonicalPage
                            Box(
                                Modifier
                                    .padding(horizontal = 3.dp)
                                    .width(if (selected) 22.dp else 7.dp)
                                    .height(7.dp)
                                    .clip(CircleShape)
                                    .background(
                                        if (selected) LocalHandAccentPalette.current.accentStrong
                                        else LocalContentColor.current.copy(alpha = 0.24f)
                                    )
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ModuleHeader(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String? = null) {
    val accent = LocalHandAccentPalette.current
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = accent.accentStrong, modifier = Modifier.size(28.dp))
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
            subtitle?.let {
                Text(it, style = MaterialTheme.typography.bodySmall, color = LocalContentColor.current.copy(alpha = 0.64f))
            }
        }
    }
}

@Composable
private fun SystemModule(battery: BatteryState, state: WorkspaceSystemState) {
    val storageUsed = if (state.storageTotalGb > 0) 1f - (state.storageFreeGb / state.storageTotalGb).toFloat() else 0f
    val memoryUsed = if (state.memoryTotalGb > 0) 1f - (state.memoryFreeGb / state.memoryTotalGb).toFloat() else 0f
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        ModuleHeader(Icons.Rounded.Memory, "System", "Device health · refreshes every 30 min")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SystemRing("Storage", storageUsed, "${state.storageFreeGb.round1()} GB free", Modifier.weight(1f))
            SystemRing("Memory", memoryUsed, "${state.memoryFreeGb.round1()} GB free", Modifier.weight(1f))
            SystemRing("Battery", battery.percent / 100f, "${battery.percent}%", Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SystemMetricCard(Icons.Rounded.DeviceThermostat, "Temperature", state.batteryTemperatureC?.let { "${it.round1()}°C" } ?: "—", state.thermalLabel, Modifier.weight(1f))
            SystemMetricCard(Icons.Rounded.Timer, "Uptime", formatUptime(state.uptimeHours), "Since reboot", Modifier.weight(1f))
        }
    }
}

@Composable
private fun SystemRing(label: String, progress: Float, detail: String, modifier: Modifier = Modifier) {
    val accent = LocalHandAccentPalette.current
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Box(contentAlignment = Alignment.Center, modifier = Modifier.size(72.dp)) {
            CircularProgressIndicator(
                progress = { progress.coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxSize(),
                color = accent.accentStrong,
                trackColor = LocalContentColor.current.copy(alpha = 0.10f),
                strokeWidth = 7.dp,
            )
            Text("${(progress.coerceIn(0f, 1f) * 100).roundToInt()}%", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        }
        Text(label, style = MaterialTheme.typography.labelMedium)
        Text(detail, style = MaterialTheme.typography.labelSmall, color = LocalContentColor.current.copy(alpha = 0.62f), maxLines = 1)
    }
}

@Composable
private fun SystemMetricCard(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, value: String, detail: String, modifier: Modifier = Modifier) {
    val accent = LocalHandAccentPalette.current
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(20.dp))
            .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.40f))
            .padding(horizontal = 11.dp, vertical = 9.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        Icon(icon, null, tint = accent.accentStrong, modifier = Modifier.size(20.dp))
        Text(label, style = MaterialTheme.typography.labelSmall, color = LocalContentColor.current.copy(alpha = 0.68f))
        Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        Text(detail, style = MaterialTheme.typography.labelSmall, color = LocalContentColor.current.copy(alpha = 0.58f), maxLines = 1)
    }
}

@Composable
private fun WorldClockModule() {
    var now by remember { mutableStateOf(Instant.now()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = Instant.now()
            delay(30_000)
        }
    }
    val cities = remember {
        listOf(
            ClockCity("Luxembourg", "Europe/Luxembourg"),
            ClockCity("Raleigh", "America/New_York"),
            ClockCity("Seoul", "Asia/Seoul"),
        )
    }
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ModuleHeader(Icons.Rounded.Public, "World Clock", "Three places, one glance")
        cities.forEach { city ->
            val time = ZonedDateTime.ofInstant(now, ZoneId.of(city.zoneId))
            WorldClockRow(city.name, time)
        }
        Spacer(Modifier.weight(1f))
        val lux = ZonedDateTime.ofInstant(now, ZoneId.of("Europe/Luxembourg"))
        val raleigh = ZonedDateTime.ofInstant(now, ZoneId.of("America/New_York"))
        val seoul = ZonedDateTime.ofInstant(now, ZoneId.of("Asia/Seoul"))
        Text(
            "Raleigh ${offsetLabel(raleigh, lux)} · Seoul ${offsetLabel(seoul, lux)} vs Luxembourg",
            style = MaterialTheme.typography.labelSmall,
            color = LocalContentColor.current.copy(alpha = 0.54f),
        )
    }
}

private data class ClockCity(val name: String, val zoneId: String)

@Composable
private fun WorldClockRow(name: String, time: ZonedDateTime) {
    val accent = LocalHandAccentPalette.current
    val daylight = time.hour in 7..18
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.36f))
            .padding(horizontal = 15.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(if (daylight) Icons.Rounded.LightMode else Icons.Rounded.DarkMode, null, tint = accent.accentStrong)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Text(time.format(DateTimeFormatter.ofPattern("EEE, d MMM")), style = MaterialTheme.typography.labelSmall, color = LocalContentColor.current.copy(alpha = 0.60f))
        }
        Text(time.format(DateTimeFormatter.ofPattern("HH:mm")), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Light)
    }
}

@Composable
private fun CommsRadarModule(
    notifications: List<LauncherNotification>,
    onOpenNotification: (LauncherNotification) -> Unit,
    onOpenPackage: (String) -> Unit,
) {
    val context = LocalContext.current
    val apps = remember {
        COMM_APPS.filter { app ->
            runCatching { context.packageManager.getApplicationInfo(app.packageName, 0) }.isSuccess
        }
    }
    val grouped = remember(notifications) { notifications.groupBy { it.packageName } }
    val total = apps.sumOf { grouped[it.packageName]?.size ?: 0 }

    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        ModuleHeader(Icons.Rounded.Radar, "Comms Radar", if (total == 0) "No active communication alerts" else "$total active communication alerts")
        if (apps.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text("No supported communication apps found", color = LocalContentColor.current.copy(alpha = 0.62f))
            }
        } else {
            Column(
                Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                apps.forEach { app ->
                    val appNotifications = grouped[app.packageName].orEmpty().sortedByDescending { it.postTime }
                    val latest = appNotifications.firstOrNull()
                    CommsAppRow(
                        app = app,
                        count = appNotifications.size,
                        latest = latest,
                        onClick = {
                            if (latest != null) onOpenNotification(latest) else onOpenPackage(app.packageName)
                        },
                    )
                }
            }
        }
        Text(
            "Swipe vertically for more apps · tap to open the latest alert or app.",
            style = MaterialTheme.typography.labelSmall,
            color = LocalContentColor.current.copy(alpha = 0.50f),
        )
    }
}

private data class CommApp(val packageName: String, val label: String)

@Composable
private fun CommsAppRow(app: CommApp, count: Int, latest: LauncherNotification?, onClick: () -> Unit) {
    val accent = LocalHandAccentPalette.current
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.34f))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        ThemedPackageIcon(app.packageName, contentDescription = app.label, modifier = Modifier.size(36.dp), sizePx = 96)
        Spacer(Modifier.width(11.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(app.label, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                if (count > 0) {
                    Surface(shape = CircleShape, color = accent.accentSoft) {
                        Text("$count", modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp), style = MaterialTheme.typography.labelSmall, color = accent.onAccent)
                    }
                }
            }
            Text(
                latest?.let { it.title.ifBlank { it.text } }?.ifBlank { "Active alert" } ?: "Quiet",
                style = MaterialTheme.typography.bodySmall,
                color = LocalContentColor.current.copy(alpha = 0.62f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        Spacer(Modifier.width(6.dp))
        Icon(Icons.Rounded.ChevronRight, null, tint = LocalContentColor.current.copy(alpha = 0.40f))
    }
}

@Composable
private fun WeatherAtlasModule(weather: WeatherState) {
    val accent = LocalHandAccentPalette.current
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        ModuleHeader(Icons.Rounded.Cloud, "Weather Atlas", weather.location.label)
        Row(verticalAlignment = Alignment.CenterVertically) {
            WeatherGraphic(weather.condition, Modifier.size(56.dp))
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(weather.temperatureC?.let { "${it.roundToInt()}°" } ?: "—°", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Light)
                Text(weather.condition, style = MaterialTheme.typography.titleSmall)
            }
            weather.rainExpectedInMinutes?.let { mins ->
                Column(horizontalAlignment = Alignment.End) {
                    Icon(Icons.Rounded.WaterDrop, null, tint = accent.accentStrong)
                    Text(if (mins <= 0) "Rain now" else "Rain in ${mins}m", style = MaterialTheme.typography.labelMedium)
                }
            }
        }
        if (weather.hourlyForecast.isNotEmpty()) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                weather.hourlyForecast.take(6).forEach { hour ->
                    Column(
                        Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(14.dp))
                            .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.30f))
                            .padding(vertical = 4.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Text(hour.timeLabel, style = MaterialTheme.typography.labelSmall)
                        WeatherGraphic(hour.condition, Modifier.size(21.dp))
                        Text(hour.temperatureC?.let { "${it.roundToInt()}°" } ?: "—", style = MaterialTheme.typography.labelMedium)
                        hour.precipitationChancePercent?.takeIf { it > 0 }?.let { Text("$it%", style = MaterialTheme.typography.labelSmall, color = accent.accentStrong) }
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            AtlasMetric(Icons.Rounded.Air, "Wind", weather.windKmh?.let { "${it.roundToInt()} km/h" } ?: "—", Modifier.weight(1f))
            AtlasMetric(Icons.Rounded.WaterDrop, "Humidity", weather.humidityPercent?.let { "$it%" } ?: "—", Modifier.weight(1f))
            AtlasMetric(Icons.Rounded.Eco, "Air quality", weather.airQualityIndex?.let { "AQI $it" } ?: "—", Modifier.weight(1f))
        }
        if (weather.dailyForecast.isNotEmpty()) {
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                weather.dailyForecast.take(3).forEach { day ->
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(day.dayLabel, modifier = Modifier.width(58.dp), style = MaterialTheme.typography.labelMedium)
                        WeatherGraphic(day.condition, Modifier.size(18.dp))
                        Spacer(Modifier.weight(1f))
                        day.precipitationChancePercent?.let { Text("$it%  ", style = MaterialTheme.typography.labelSmall, color = accent.accentStrong) }
                        Text("${day.highC?.roundToInt() ?: "—"}° / ${day.lowC?.roundToInt() ?: "—"}°", style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
        }
    }
}

@Composable
private fun AtlasMetric(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, value: String, modifier: Modifier = Modifier) {
    val accent = LocalHandAccentPalette.current
    Column(
        modifier.clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.surface.copy(alpha = 0.32f)).padding(horizontal = 8.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(1.dp),
    ) {
        Icon(icon, null, tint = accent.accentStrong, modifier = Modifier.size(17.dp))
        Text(label, style = MaterialTheme.typography.labelSmall, color = LocalContentColor.current.copy(alpha = 0.60f), maxLines = 1)
        Text(value, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

@Composable
private fun EnergyGridModule(state: EnergyGridState, onRequestAccess: () -> Unit) {
    val accent = LocalHandAccentPalette.current
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(11.dp)) {
        ModuleHeader(Icons.Rounded.Bolt, "Energy Grid", "Samsung Health + RingConn")
        if (!state.available || !state.permissionsGranted) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Icon(Icons.Rounded.HealthAndSafety, null, tint = accent.accentStrong, modifier = Modifier.size(48.dp))
                    Text(state.message ?: "Connect your health sources", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "BOAL reads wellness data shared through Health Connect. Data stays on this device.",
                        style = MaterialTheme.typography.bodySmall,
                        color = LocalContentColor.current.copy(alpha = 0.62f),
                    )
                    FilledTonalButton(onClick = onRequestAccess) { Text("Connect Health sources") }
                }
            }
            return@Column
        }

        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(contentAlignment = Alignment.Center, modifier = Modifier.size(112.dp)) {
                CircularProgressIndicator(
                    progress = { ((state.energyIndex ?: 0) / 100f).coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxSize(),
                    color = accent.accentStrong,
                    trackColor = LocalContentColor.current.copy(alpha = 0.10f),
                    strokeWidth = 10.dp,
                )
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(state.energyIndex?.toString() ?: "—", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.SemiBold)
                    Text("Energy", style = MaterialTheme.typography.labelSmall)
                }
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("BOAL Energy", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text("A simple sleep + activity index — not a medical score.", style = MaterialTheme.typography.bodySmall, color = LocalContentColor.current.copy(alpha = 0.62f))
                Text(
                    if (state.backgroundPermissionGranted) "30-minute background sync enabled" else "Background health access not granted",
                    style = MaterialTheme.typography.labelSmall,
                    color = if (state.backgroundPermissionGranted) accent.accentStrong else LocalContentColor.current.copy(alpha = 0.52f),
                )
            }
        }
        EnergySourceCard(state.samsung, Modifier.fillMaxWidth())
        EnergySourceCard(state.ringConn, Modifier.fillMaxWidth())
        state.message?.let { Text(it, style = MaterialTheme.typography.labelSmall, color = LocalContentColor.current.copy(alpha = 0.54f)) }
        Spacer(Modifier.weight(1f))
    }
}

@Composable
private fun EnergySourceCard(source: EnergySourceSnapshot, modifier: Modifier = Modifier) {
    val accent = LocalHandAccentPalette.current
    Column(
        modifier.clip(RoundedCornerShape(18.dp)).background(MaterialTheme.colorScheme.surface.copy(alpha = 0.34f)).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            ThemedPackageIcon(source.packageName, contentDescription = source.label, modifier = Modifier.size(28.dp), sizePx = 72)
            Spacer(Modifier.width(9.dp))
            Text(source.label, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.weight(1f))
            Box(Modifier.size(7.dp).clip(CircleShape).background(if (source.hasAnyData()) accent.accentStrong else LocalContentColor.current.copy(alpha = 0.24f)))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            EnergyDatum("Steps", source.steps?.toString() ?: "—")
            EnergyDatum("Sleep", source.sleepMinutes?.let(::formatSleep) ?: "—")
            EnergyDatum("HR", source.heartRateBpm?.let { "$it bpm" } ?: "—")
            EnergyDatum("SpO₂", source.oxygenPercent?.let { "${it.roundToInt()}%" } ?: "—")
        }
    }
}

@Composable
private fun EnergyDatum(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
        Text(label, style = MaterialTheme.typography.labelSmall, color = LocalContentColor.current.copy(alpha = 0.54f))
    }
}

@Composable
private fun CineClubModule(
    showlyShowsWidgetId: Int?,
    showlyMoviesWidgetId: Int?,
    widgetHostController: AndroidWidgetHostController,
    onSetupShowly: () -> Unit,
    onOpenShowly: () -> Unit,
) {
    val accent = LocalHandAccentPalette.current
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val validShows = showlyShowsWidgetId?.takeIf { widgetHostController.providerInfo(it) != null }
    val validMovies = showlyMoviesWidgetId?.takeIf { widgetHostController.providerInfo(it) != null }
    val selectedId = if (tab == 0) validShows ?: validMovies else validMovies ?: validShows

    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.Movie, null, tint = accent.accentStrong, modifier = Modifier.size(28.dp))
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text("Ciné Club", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                Text("Powered by Showly", style = MaterialTheme.typography.bodySmall, color = LocalContentColor.current.copy(alpha = 0.62f))
            }
            IconButton(onClick = onOpenShowly) { Icon(Icons.Rounded.OpenInNew, "Open Showly") }
        }

        if (selectedId == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Icon(Icons.Rounded.LocalMovies, null, tint = accent.accentStrong, modifier = Modifier.size(48.dp))
                    Text("Connect Showly", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "BOAL hosts Showly's own Progress widgets, so your shows, movies and tap actions stay native to Showly.",
                        style = MaterialTheme.typography.bodySmall,
                        color = LocalContentColor.current.copy(alpha = 0.62f),
                    )
                    FilledTonalButton(onClick = onSetupShowly) { Text("Add Showly widgets") }
                }
            }
        } else {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = tab == 0, onClick = { tab = 0 }, label = { Text("Series") })
                FilterChip(selected = tab == 1, onClick = { tab = 1 }, label = { Text("Movies") })
                Spacer(Modifier.weight(1f))
                TextButton(onClick = onSetupShowly) { Text("Reconnect") }
            }
            Box(
                Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .clip(RoundedCornerShape(18.dp))
            ) {
                AndroidHostedWidget(
                    appWidgetId = selectedId,
                    hostController = widgetHostController,
                    modifier = Modifier.fillMaxSize(),
                )
            }
        }
    }
}

private fun EnergySourceSnapshot.hasAnyData(): Boolean = steps != null || sleepMinutes != null || heartRateBpm != null || oxygenPercent != null
private fun Double.round1(): String = String.format(java.util.Locale.US, "%.1f", this)
private fun formatUptime(hours: Long): String = if (hours < 24) "${hours}h" else "${hours / 24}d ${hours % 24}h"
private fun formatSleep(minutes: Long): String = "${minutes / 60}h ${minutes % 60}m"
private fun offsetLabel(city: ZonedDateTime, reference: ZonedDateTime): String {
    val deltaSeconds = city.offset.totalSeconds - reference.offset.totalSeconds
    val hours = deltaSeconds / 3600
    return if (hours >= 0) "+${hours}h" else "${hours}h"
}

private val COMM_APPS = listOf(
    CommApp("com.google.android.gm", "Gmail"),
    CommApp("com.facebook.orca", "Messenger"),
    CommApp("com.whatsapp", "WhatsApp"),
    CommApp("org.telegram.messenger", "Telegram"),
    CommApp("com.google.android.apps.messaging", "Messages"),
    CommApp("com.discord", "Discord"),
    CommApp("org.thoughtcrime.securesms", "Signal"),
    CommApp("com.instagram.android", "Instagram"),
    CommApp("com.Slack", "Slack"),
    CommApp("com.microsoft.teams2", "Teams"),
)

private const val SHOWLY_PACKAGE = "com.michaldrabik.showly2"
