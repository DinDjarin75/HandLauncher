BOAL Launcher 1.0.0-beta1.7: interactive Workspace with Google Keep + BOAL ChatGPT.

# BOAL Launcher — Project Status

## Current source milestone
**1.0.0-beta1.7 — 27 October 2026**

BOAL is a real Android HOME launcher project, not a visual mock-up. Its permanent state is declarative and profile-specific so phone, Fold, landscape and external-display layouts can evolve independently while sharing the same object, search, context and AI engines.

## Implemented in the current beta

### Launcher / navigation
- Android HOME role registration and system role request.
- Installed-app discovery through `LauncherApps` and launch support.
- Refresh after returning Home so installs/removals/updates are reflected.
- Swipe down left 30% → full notification shade; center 40% → Search; right 30% → full Quick Settings.
- Swipe up on Home → category-first App Library.
- Full-width Android bottom Home gesture exits transient BOAL surfaces such as Search back to Home.
- Gesture arbitration prevents a Home swipe from stealing a Smart Object's own vertical gesture.
- Left page is a native personal briefing with weather, forecast, Calendar, battery, context suggestions and four collapsible news sections: Headlines, Entertainment, Tech and LEGO; Google remains an optional shortcut.
- Right Workspace surface redesigned to the adaptive glass system with at-a-glance metrics, AI Design / Automations / Settings actions, an interactive Google Keep widget module, and a BOAL ChatGPT conversation module.
- Entire Brief refreshes automatically every 30 minutes while preserving in-page UI state.

### Workspace
- Google Keep is hosted as a real Android AppWidget inside BOAL rather than mirrored data; Keep owns note content and sync while BOAL owns placement/chrome.
- Keep setup uses Android widget binding/configuration and a Workspace-specific persisted widget ID independent of canvas widgets.
- Workspace ChatGPT supports an inline BOAL-specific OpenAI conversation with encrypted local API-key storage, persistent conversation ID and compact local transcript.
- The official ChatGPT Android app remains the account-history surface; when inline API access is not configured, BOAL hands prompts to that app instead.

### Category-first App Library
- No conventional bottom drawer.
- Initial category classification uses Android publisher categories first, then BOAL heuristics.
- Editable category names.
- User-created categories.
- Manual app reassignment; user decisions override automatic sorting.
- Searchable independent tags under the visual category model.
- Direct left/right swipe navigation between categories with synchronized category chips.

### Universal Search / Command Layer
- App search by label, package, tags and category.
- Quick launcher commands for App Library, AI Design, Automations, Add and Settings.
- Results are local-first and open apps directly.

### Declarative Home editor
- Explicit Edit Mode so ordinary use cannot accidentally rearrange Home.
- Drag and resize objects.
- Fine positioning or grid snapping.
- Layout lock/unlock.
- Normalized geometry survives different display sizes.
- Add palette supports apps, BOAL widgets, Android widgets, Smart Stacks, category objects and commands.
- Remove/edit controls are part of Edit Mode.

### Smart Objects
- Shared model for apps, folders/category objects, native widgets, Android widgets, Smart Stacks, shortcuts and commands.
- Per-object tap, swipe-up, swipe-down and long-press action slots.
- Per-app Smart Object label/action editor.
- Smart Object actions execute directly from Home.

### BOAL-native widgets
- Digital clock with minimal/standard/detailed variants, optional date and seconds; standard cards include next-alarm context and a live day-progress gauge.
- Calendar/date widget with event-aware state when Calendar access is granted.
- Weather widget backed by Open-Meteo using a user-selected coarse location (no continuous location permission required), with shared native weather graphics on Home and Brief.
- Battery widget with live phone state, connected audio-device awareness and an adaptive circular charge gauge; accessory percentages are displayed only where Android/device providers make them available.
- Native widget appearance editor.

### Smart Stacks
- Multiple independently persisted Smart Stacks.
- Editable stack names.
- Add/remove native widgets.
- Reorder stack contents.
- Manual horizontal paging (left/right), wrap-around navigation and optional automatic looping.
- The last viewed permanent widget is persisted per stack/display profile and restored when Home returns.
- Home keeps the default Smart Stack anchored at the top and removes carousel indicator clutter.
- Clock, Weather and Battery are permanent core stack widgets.
- Calendar remains user-optional.
- Active music/podcast sessions add a temporary contextual player with metadata, artwork, transport controls, elapsed/total duration, seek scrubber, output-device indicator and app launch.
- Contextual media never rewrites the saved permanent stack order.

### Android widgets
- Real `AppWidgetHost`.
- System widget picker and provider configuration flow.
- Durable widget IDs.
- Third-party widgets can be placed directly on the free-form Home canvas and resized.
- Widget size options update as the canvas object changes size.
- Removing a hosted widget deallocates its ID.

### Fold / orientation / desktop
Independent profiles:
- cover display
- unfolded / inner Fold
- portrait phone
- landscape phone
- external display

Resolution uses window dimensions plus Jetpack Window `FoldingFeature` data. External-display mode uses the same declarative editor but a dedicated desktop shell/navigation rail.

### Context Automation
User-editable rules can combine:
- battery threshold
- charging state
- time window, including overnight ranges
- display profile
- connected audio-device name
- upcoming Calendar event
- incoming rain

Current effects:
- promote an eligible Smart Stack widget
- surface a contextual command suggestion
- data model for temporary Smart Object surfacing

Rules are persisted and evaluated without rewriting permanent layout state.

### Wallpaper Adaptive Accent
- BOAL listens to Android wallpaper-color changes and updates its accent without requiring a restart.
- The wallpaper primary color is preferred when usable; low-chroma primaries can yield to a stronger secondary/tertiary color.
- Extreme light/dark tones are normalized for UI contrast while preserving the wallpaper hue.
- The accent is applied to outlines, gauges, progress, active controls and focus states; glass surfaces stay neutral.
- Settings > Appearance shows the currently extracted accent.

### AI layout + theme generation
- Local deterministic designer works without a cloud account/key.
- Optional Gemini-backed design provider.
- Gemini returns only a constrained JSON design plan; BOAL composes the actual layout itself.
- Preview before Apply.
- AI layouts persist independently by display profile.
- AI themes currently affect dark/light mode, transparency, widget corner radius and typography mood.
- Gemini key is encrypted with Android Keystore and excluded from backups.
- Default cloud model setting: `gemini-3.8-flash` (editable in Settings).

### Backup / restore
JSON backup includes:
- categories and assignments
- layouts for every profile
- Smart Objects
- Smart Stacks
- hosted-widget ID state
- automations
- AI-generated theme state
- coarse weather location

AI credentials are intentionally excluded.

### Reproducible build path
- Current AGP / Compose project files.
- GitHub Actions workflow runs unit tests, builds the debug APK and publishes it as an artifact.
- `BUILDING.md` documents Android Studio and cloud-build paths.

## Local validation completed in this runtime
- Kotlin PSI syntax parse completed successfully across all 47 Kotlin source files for beta1.4.
- Balanced Kotlin source structure check across the project.
- Platform-independent domain/search/context sources compile with local `kotlinc`.
- Core search and context behavior has dedicated JUnit tests in the project.

## Platform-gated / not honestly claimable as complete

### Google Discover
Google does not provide a normal public third-party launcher API for embedding the Pixel/Google Discover surface. BOAL therefore owns the left-page experience with its native briefing surface and retains a Google-app shortcut. A companion bridge can still be added later without coupling the launcher core to undocumented behavior.

### Accessory battery percentages
Android does not expose one universal public API that reliably returns phone + watch + earbuds + case battery levels across manufacturers. BOAL shows what it can obtain without inventing values; provider-specific integrations can be layered in later.

### APK assembly in this chat runtime
This runtime has JDK/Kotlin but no Android SDK, Android platform jar or Gradle distribution, and binary downloads are unavailable. Therefore an APK cannot be truthfully claimed as locally assembled here. The included GitHub workflow/Android Studio project is the reproducible build route.


## BOAL Beta 1.2
- Stable canonical Home Smart Stack roster.
- Media promotion is once per session and survives Home/Brief recomposition.
- Manual wraparound navigation remains the only permanent-widget rotation.
