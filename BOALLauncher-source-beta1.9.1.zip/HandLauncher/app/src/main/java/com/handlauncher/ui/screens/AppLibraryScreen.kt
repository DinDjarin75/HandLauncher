@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.handlauncher.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Velocity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.handlauncher.domain.AppCategory
import com.handlauncher.domain.AppEntry
import com.handlauncher.ui.components.AppIcon
import com.handlauncher.ui.components.HandGlassSurface
import com.handlauncher.ui.components.ThemedPackageIcon
import com.handlauncher.ui.theme.LocalHandAccentPalette
import kotlinx.coroutines.launch

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppLibraryScreen(
    apps: List<AppEntry>,
    categories: List<AppCategory>,
    selectedCategoryId: String,
    onSelectCategory: (String) -> Unit,
    onLaunch: (AppEntry) -> Unit,
    onEditCategories: () -> Unit,
    onAssignApp: (AppEntry, String) -> Unit,
    onAddToHome: (AppEntry) -> Unit,
    onAppInfo: (AppEntry) -> Unit,
    onUninstall: (AppEntry) -> Unit,
    onDismiss: () -> Unit,
) {
    if (categories.isEmpty()) return

    var overview by remember { mutableStateOf(true) }
    var query by remember { mutableStateOf("") }
    var contextualApp by remember { mutableStateOf<AppEntry?>(null) }
    var moveApp by remember { mutableStateOf<AppEntry?>(null) }

    BackHandler {
        when {
            contextualApp != null -> contextualApp = null
            moveApp != null -> moveApp = null
            query.isNotBlank() -> query = ""
            !overview -> overview = true
            else -> onDismiss()
        }
    }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val expanded = maxWidth >= 700.dp
        val currentCategory = categories.firstOrNull { it.id == selectedCategoryId } ?: categories.first()
        val backgroundAlpha = if (overview && !expanded) 0.16f else {
            (1f - currentCategory.backgroundTransparencyPercent.coerceIn(0, 90) / 100f).coerceIn(0.10f, 0.72f)
        }

        Surface(
            Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background.copy(alpha = backgroundAlpha),
            contentColor = Color.White,
        ) {
            if (expanded) {
                ExpandedLibrary(
                    apps = apps,
                    categories = categories,
                    selectedCategoryId = selectedCategoryId,
                    query = query,
                    onQueryChange = { query = it },
                    onSelectCategory = onSelectCategory,
                    onLaunch = onLaunch,
                    onLongPress = { contextualApp = it },
                    onEditCategories = onEditCategories,
                    onDismiss = onDismiss,
                )
            } else if (query.isNotBlank()) {
                CompactSearch(
                    apps = apps,
                    categories = categories,
                    query = query,
                    onQueryChange = { query = it },
                    onLaunch = onLaunch,
                    onLongPress = { contextualApp = it },
                    onSelectCategory = {
                        onSelectCategory(it)
                        query = ""
                        overview = false
                    },
                    onDismiss = { query = "" },
                )
            } else if (overview) {
                CategoryOverview(
                    apps = apps,
                    categories = categories,
                    selectedCategoryId = selectedCategoryId,
                    onOpenCategory = {
                        onSelectCategory(it)
                        overview = false
                    },
                    onQueryChange = { query = it },
                    onEditCategories = onEditCategories,
                    onDismiss = onDismiss,
                )
            } else {
                CompactCategoryPager(
                    apps = apps,
                    categories = categories,
                    selectedCategoryId = selectedCategoryId,
                    onSelectCategory = onSelectCategory,
                    onLaunch = onLaunch,
                    onLongPress = { contextualApp = it },
                    onEditCategories = onEditCategories,
                    onSearch = { query = " " },
                    onOverview = { overview = true },
                    onDismiss = onDismiss,
                )
            }
        }
    }

    contextualApp?.let { app ->
        AppContextDialog(
            app = app,
            onDismiss = { contextualApp = null },
            onInfo = {
                contextualApp = null
                onAppInfo(app)
            },
            onMove = {
                contextualApp = null
                moveApp = app
            },
            onAddHome = {
                contextualApp = null
                onAddToHome(app)
            },
            onUninstall = if (!app.isSystemApp) {{
                contextualApp = null
                onUninstall(app)
            }} else null,
        )
    }

    moveApp?.let { app ->
        MoveCategoryDialog(
            app = app,
            categories = categories,
            onMove = { id ->
                onAssignApp(app, id)
                onSelectCategory(id)
                moveApp = null
                overview = false
            },
            onDismiss = { moveApp = null },
        )
    }
}

@Composable
private fun CategoryOverview(
    apps: List<AppEntry>,
    categories: List<AppCategory>,
    selectedCategoryId: String,
    onOpenCategory: (String) -> Unit,
    onQueryChange: (String) -> Unit,
    onEditCategories: () -> Unit,
    onDismiss: () -> Unit,
) {
    val accent = LocalHandAccentPalette.current
    val gridState = rememberLazyGridState()
    val closeThreshold = with(LocalDensity.current) { 72.dp.toPx() }
    var upwardPull by remember { mutableFloatStateOf(0f) }
    var closeTriggered by remember { mutableStateOf(false) }
    val closeOnSwipeUp = remember(gridState, closeThreshold, onDismiss) {
        object : NestedScrollConnection {
            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                if (!closeTriggered && !gridState.canScrollForward && available.y < 0f) {
                    upwardPull += -available.y
                    if (upwardPull >= closeThreshold) {
                        closeTriggered = true
                        upwardPull = 0f
                        onDismiss()
                    }
                } else if (available.y > 0f) {
                    upwardPull = 0f
                }
                return Offset.Zero
            }

            override suspend fun onPreFling(available: Velocity): Velocity {
                if (!closeTriggered && !gridState.canScrollForward && available.y < -1400f) {
                    closeTriggered = true
                    onDismiss()
                }
                upwardPull = 0f
                return Velocity.Zero
            }
        }
    }
    Column(
        Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 16.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Apps", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            IconButton(onClick = onEditCategories) { Icon(Icons.Rounded.Edit, "Edit categories") }
            IconButton(onClick = onDismiss) { Icon(Icons.Rounded.Close, "Home") }
        }
        LibrarySearchField(value = "", onValueChange = onQueryChange)
        LazyVerticalGrid(
            state = gridState,
            columns = GridCells.Fixed(3),
            contentPadding = PaddingValues(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxSize().nestedScroll(closeOnSwipeUp),
        ) {
            gridItems(categories, key = { it.id }) { category ->
                val count = apps.count { it.categoryId == category.id }
                val selected = category.id == selectedCategoryId
                Column(
                    Modifier
                        .height(112.dp)
                        .background(
                            if (selected) MaterialTheme.colorScheme.surface.copy(alpha = 0.66f) else MaterialTheme.colorScheme.surface.copy(alpha = 0.60f),
                            RoundedCornerShape(22.dp),
                        )
                        .border(
                            0.8.dp,
                            if (selected) accent.accent else accent.outline.copy(alpha = 0.62f),
                            RoundedCornerShape(22.dp),
                        )
                        .combinedClickable(onClick = { onOpenCategory(category.id) })
                        .padding(12.dp),
                    verticalArrangement = Arrangement.SpaceBetween,
                ) {
                    Icon(categoryIcon(category.iconKey), null, tint = accent.accentStrong, modifier = Modifier.size(28.dp))
                    Column {
                        Text(category.name, style = MaterialTheme.typography.labelLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("$count", style = MaterialTheme.typography.labelMedium, color = Color.White.copy(alpha = 0.58f))
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun CompactCategoryPager(
    apps: List<AppEntry>,
    categories: List<AppCategory>,
    selectedCategoryId: String,
    onSelectCategory: (String) -> Unit,
    onLaunch: (AppEntry) -> Unit,
    onLongPress: (AppEntry) -> Unit,
    onEditCategories: () -> Unit,
    onSearch: () -> Unit,
    onOverview: () -> Unit,
    onDismiss: () -> Unit,
) {
    val initial = categories.indexOfFirst { it.id == selectedCategoryId }.coerceAtLeast(0)
    val pagerState = rememberPagerState(initialPage = initial, pageCount = { categories.size })
    val scope = rememberCoroutineScope()

    LaunchedEffect(selectedCategoryId, categories) {
        val target = categories.indexOfFirst { it.id == selectedCategoryId }
        if (target >= 0 && target != pagerState.currentPage && !pagerState.isScrollInProgress) pagerState.scrollToPage(target)
    }
    LaunchedEffect(pagerState) {
        snapshotFlow { pagerState.currentPage }.collect { page -> categories.getOrNull(page)?.id?.let(onSelectCategory) }
    }

    val category = categories.getOrNull(pagerState.currentPage) ?: categories.first()
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(top = 8.dp)) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onOverview) { Icon(Icons.Rounded.ArrowBack, "All categories") }
            Text(
                category.name,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.weight(1f),
            )
            IconButton(onClick = onSearch) { Icon(Icons.Rounded.Search, "Search") }
            IconButton(onClick = onEditCategories) { Icon(Icons.Rounded.Edit, "Edit categories") }
            IconButton(onClick = onDismiss) { Icon(Icons.Rounded.Close, "Home") }
        }

        LibraryCategoryStrip(
            categories = categories,
            selectedIndex = pagerState.currentPage,
            onSelect = { index -> scope.launch { pagerState.animateScrollToPage(index) } },
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 4.dp),
        )

        Spacer(Modifier.height(10.dp))
        HorizontalPager(state = pagerState, modifier = Modifier.fillMaxSize(), beyondViewportPageCount = 1) { page ->
            val pageApps = apps.filter { it.categoryId == categories[page].id }
            CompactCategoryCanvas(
                apps = pageApps,
                onLaunch = onLaunch,
                onLongPress = onLongPress,
                onDismiss = onDismiss,
                modifier = Modifier.padding(horizontal = 14.dp),
            )
        }
    }
}

@Composable
private fun ExpandedLibrary(
    apps: List<AppEntry>,
    categories: List<AppCategory>,
    selectedCategoryId: String,
    query: String,
    onQueryChange: (String) -> Unit,
    onSelectCategory: (String) -> Unit,
    onLaunch: (AppEntry) -> Unit,
    onLongPress: (AppEntry) -> Unit,
    onEditCategories: () -> Unit,
    onDismiss: () -> Unit,
) {
    val initial = categories.indexOfFirst { it.id == selectedCategoryId }.coerceAtLeast(0)
    val pagerState = rememberPagerState(initialPage = initial, pageCount = { categories.size })
    val scope = rememberCoroutineScope()

    LaunchedEffect(selectedCategoryId, categories) {
        val target = categories.indexOfFirst { it.id == selectedCategoryId }
        if (target >= 0 && target != pagerState.currentPage && !pagerState.isScrollInProgress) pagerState.scrollToPage(target)
    }
    LaunchedEffect(pagerState) {
        snapshotFlow { pagerState.currentPage }.collect { page -> categories.getOrNull(page)?.id?.let(onSelectCategory) }
    }

    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Apps", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            Box(Modifier.widthIn(max = 380.dp)) { LibrarySearchField(query, onQueryChange) }
            IconButton(onClick = onEditCategories) { Icon(Icons.Rounded.Edit, "Edit categories") }
            IconButton(onClick = onDismiss) { Icon(Icons.Rounded.Close, "Home") }
        }
        Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            HandGlassSurface(Modifier.width(220.dp).fillMaxHeight(), contentPadding = PaddingValues(10.dp)) {
                LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    items(categories, key = { it.id }) { category ->
                        val selected = category.id == selectedCategoryId
                        val accent = LocalHandAccentPalette.current
                        Row(
                            Modifier.fillMaxWidth()
                                .background(if (selected) accent.accentFaint else Color.Transparent, RoundedCornerShape(14.dp))
                                .combinedClickable(onClick = {
                                    val index = categories.indexOfFirst { it.id == category.id }
                                    if (index >= 0) scope.launch { pagerState.animateScrollToPage(index) }
                                })
                                .padding(horizontal = 10.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(categoryIcon(category.iconKey), null, tint = if (selected) accent.accentStrong else Color.White.copy(alpha = .72f), modifier = Modifier.size(20.dp))
                            Spacer(Modifier.width(10.dp))
                            Text(category.name, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("${apps.count { it.categoryId == category.id }}", style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = .5f))
                        }
                    }
                }
            }
            HandGlassSurface(Modifier.weight(1f).fillMaxHeight(), contentPadding = PaddingValues(16.dp)) {
                if (query.isBlank()) {
                    HorizontalPager(state = pagerState, modifier = Modifier.fillMaxSize(), beyondViewportPageCount = 1) { page ->
                        val selected = categories[page]
                        Column(Modifier.fillMaxSize()) {
                            Text(selected.name, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
                            Text("${apps.count { it.categoryId == selected.id }} apps", style = MaterialTheme.typography.labelMedium, color = Color.White.copy(alpha = .55f))
                            Spacer(Modifier.height(10.dp))
                            CategoryAppGrid(
                                apps = apps.filter { it.categoryId == selected.id },
                                onLaunch = onLaunch,
                                onLongPress = onLongPress,
                                onDismiss = onDismiss,
                                columns = GridCells.Adaptive(92.dp),
                            )
                        }
                    }
                } else {
                    SearchResults(apps, categories, query, onLaunch, onLongPress) { id ->
                        val index = categories.indexOfFirst { it.id == id }
                        if (index >= 0) scope.launch { pagerState.animateScrollToPage(index) }
                        onQueryChange("")
                    }
                }
            }
        }
    }
}

@Composable
private fun CompactSearch(
    apps: List<AppEntry>,
    categories: List<AppCategory>,
    query: String,
    onQueryChange: (String) -> Unit,
    onLaunch: (AppEntry) -> Unit,
    onLongPress: (AppEntry) -> Unit,
    onSelectCategory: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onDismiss) { Icon(Icons.Rounded.ArrowBack, "Back") }
            Box(Modifier.weight(1f)) { LibrarySearchField(query.trimStart(), onQueryChange) }
        }
        SearchResults(apps, categories, query.trim(), onLaunch, onLongPress, onSelectCategory)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun SearchResults(
    apps: List<AppEntry>,
    categories: List<AppCategory>,
    query: String,
    onLaunch: (AppEntry) -> Unit,
    onLongPress: (AppEntry) -> Unit,
    onSelectCategory: (String) -> Unit,
) {
    val q = query.trim().lowercase()
    if (q.isBlank()) return
    val matchingCategories = categories.filter { it.name.lowercase().contains(q) }
    val matchingApps = apps.filter { app ->
        app.label.lowercase().contains(q) || app.tags.any { it.lowercase().contains(q) }
    }.take(30)
    LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        if (matchingCategories.isNotEmpty()) {
            item { Text("Categories", style = MaterialTheme.typography.labelLarge, color = Color.White.copy(alpha = .62f), modifier = Modifier.padding(vertical = 4.dp)) }
            items(matchingCategories, key = { "cat_${it.id}" }) { category ->
                ListItem(
                    headlineContent = { Text(category.name) },
                    supportingContent = { Text("${apps.count { it.categoryId == category.id }} apps") },
                    leadingContent = { Icon(categoryIcon(category.iconKey), null, tint = LocalHandAccentPalette.current.accentStrong) },
                    modifier = Modifier.background(MaterialTheme.colorScheme.surface.copy(alpha = .46f), RoundedCornerShape(16.dp)).combinedClickable(onClick = { onSelectCategory(category.id) }),
                    colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                )
            }
        }
        item { Text("Apps", style = MaterialTheme.typography.labelLarge, color = Color.White.copy(alpha = .62f), modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)) }
        items(matchingApps, key = { it.stableId }) { app ->
            val categoryName = categories.firstOrNull { it.id == app.categoryId }?.name.orEmpty()
            ListItem(
                headlineContent = { Text(app.label) },
                supportingContent = { Text(categoryName) },
                leadingContent = { ThemedPackageIcon(app.packageName, app.activityName, app.label, Modifier.size(42.dp), 96) },
                trailingContent = { Icon(Icons.Rounded.ChevronRight, null, tint = Color.White.copy(alpha = .5f)) },
                modifier = Modifier.background(MaterialTheme.colorScheme.surface.copy(alpha = .46f), RoundedCornerShape(16.dp)).combinedClickable(onClick = { onLaunch(app) }, onLongClick = { onLongPress(app) }),
                colors = ListItemDefaults.colors(containerColor = Color.Transparent),
            )
        }
    }
}

@Composable
private fun CategoryAppGrid(
    apps: List<AppEntry>,
    onLaunch: (AppEntry) -> Unit,
    onLongPress: (AppEntry) -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
    columns: GridCells = GridCells.Adaptive(78.dp),
) {
    val gridState = rememberLazyGridState()
    val dismissThreshold = with(LocalDensity.current) { 84.dp.toPx() }
    var downwardPull by remember { mutableFloatStateOf(0f) }
    val nestedConnection = remember(gridState, dismissThreshold) {
        object : NestedScrollConnection {
            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                if (!gridState.canScrollBackward && available.y > 0f) downwardPull += available.y
                else if (available.y < 0f) downwardPull = 0f
                return Offset.Zero
            }
            override suspend fun onPreFling(available: Velocity): Velocity {
                if (!gridState.canScrollBackward && (downwardPull >= dismissThreshold || available.y > 1500f)) onDismiss()
                downwardPull = 0f
                return Velocity.Zero
            }
        }
    }
    LazyVerticalGrid(
        state = gridState,
        columns = columns,
        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        modifier = modifier.fillMaxSize().nestedScroll(nestedConnection),
    ) {
        gridItems(apps, key = { it.stableId }) { app ->
            AppIcon(app, onClick = { onLaunch(app) }, onLongClick = { onLongPress(app) })
        }
    }
}

@Composable
private fun LibrarySearchField(value: String, onValueChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        placeholder = { Text("Search apps and categories…") },
        leadingIcon = { Icon(Icons.Rounded.Search, null) },
        trailingIcon = if (value.isNotEmpty()) { { IconButton(onClick = { onValueChange("") }) { Icon(Icons.Rounded.Close, "Clear") } } } else null,
        singleLine = true,
        shape = RoundedCornerShape(22.dp),
        modifier = Modifier.fillMaxWidth(),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = LocalHandAccentPalette.current.accent,
            unfocusedBorderColor = Color.White.copy(alpha = .20f),
            focusedContainerColor = MaterialTheme.colorScheme.surface.copy(alpha = .54f),
            unfocusedContainerColor = MaterialTheme.colorScheme.surface.copy(alpha = .44f),
        ),
    )
}

@Composable
private fun LibraryCategoryStrip(
    categories: List<AppCategory>,
    selectedIndex: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    LibraryGlassPanel(modifier = modifier.fillMaxWidth(), cornerRadius = 22.dp, contentPadding = PaddingValues(5.dp)) {
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            categories.forEachIndexed { index, item ->
                LibraryCategoryChip(
                    selected = index == selectedIndex,
                    label = item.name,
                    onClick = { onSelect(index) },
                )
            }
        }
    }
}

@Composable
private fun LibraryCategoryChip(selected: Boolean, label: String, onClick: () -> Unit) {
    val accent = LocalHandAccentPalette.current
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(17.dp),
        color = if (selected) accent.accentSoft else Color.Transparent,
        border = if (selected) androidx.compose.foundation.BorderStroke(0.8.dp, accent.accent) else null,
    ) {
        Text(
            label,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
            style = MaterialTheme.typography.labelLarge,
            color = if (selected) Color.White else Color.White.copy(alpha = .78f),
        )
    }
}

@Composable
private fun LibraryGlassPanel(
    modifier: Modifier = Modifier,
    cornerRadius: androidx.compose.ui.unit.Dp = 26.dp,
    contentPadding: PaddingValues = PaddingValues(12.dp),
    content: @Composable BoxScope.() -> Unit,
) {
    val accent = LocalHandAccentPalette.current
    val shape = RoundedCornerShape(cornerRadius)
    Box(
        modifier
            .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.60f), shape)
            .border(0.8.dp, accent.outline.copy(alpha = 0.62f), shape)
            .padding(contentPadding),
        content = content,
    )
}

@Composable
private fun CompactCategoryCanvas(
    apps: List<AppEntry>,
    onLaunch: (AppEntry) -> Unit,
    onLongPress: (AppEntry) -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
) {
    BoxWithConstraints(modifier.fillMaxSize()) {
        val columnCount = (maxWidth.value / 78f).toInt().coerceAtLeast(4)
        val rows = ((apps.size + columnCount - 1) / columnCount).coerceAtLeast(1)
        val naturalHeight = (rows * 104 + 48).dp
        val canvasHeight = minOf(maxHeight, naturalHeight).coerceAtLeast(176.dp)

        LibraryGlassPanel(
            modifier = Modifier.fillMaxWidth().height(canvasHeight),
            cornerRadius = 26.dp,
            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 10.dp),
        ) {
            Column(Modifier.fillMaxSize()) {
                Text(
                    "${apps.size} apps",
                    style = MaterialTheme.typography.labelLarge,
                    color = Color.White.copy(alpha = .68f),
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                )
                Spacer(Modifier.height(4.dp))
                CategoryAppGrid(
                    apps = apps,
                    onLaunch = onLaunch,
                    onLongPress = onLongPress,
                    onDismiss = onDismiss,
                    modifier = Modifier.weight(1f),
                )
            }
        }
    }
}

@Composable
private fun AppContextDialog(
    app: AppEntry,
    onDismiss: () -> Unit,
    onInfo: () -> Unit,
    onMove: () -> Unit,
    onAddHome: () -> Unit,
    onUninstall: (() -> Unit)?,
) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        HandGlassSurface(
            Modifier.fillMaxWidth().padding(horizontal = 24.dp),
            cornerRadiusDp = 28,
            contentPadding = PaddingValues(18.dp),
        ) {
            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    ThemedPackageIcon(app.packageName, app.activityName, app.label, Modifier.size(52.dp), 128)
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(app.label, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text(app.packageName, style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = .48f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
                HorizontalDivider(Modifier.padding(vertical = 6.dp), color = Color.White.copy(alpha = .10f))
                ContextAction(Icons.Rounded.Info, "App info", onInfo)
                ContextAction(Icons.Rounded.DriveFileMove, "Move category", onMove)
                ContextAction(Icons.Rounded.AddToHomeScreen, "Add to Home", onAddHome)
                if (onUninstall != null) {
                    ContextAction(Icons.Rounded.DeleteOutline, "Uninstall", onUninstall, destructive = true)
                }
            }
        }
    }
}

@Composable
private fun ContextAction(icon: ImageVector, label: String, onClick: () -> Unit, destructive: Boolean = false) {
    val color = if (destructive) MaterialTheme.colorScheme.error else Color.White
    Row(
        Modifier.fillMaxWidth().combinedClickable(onClick = onClick).padding(horizontal = 4.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, tint = color)
        Spacer(Modifier.width(14.dp))
        Text(label, color = color, style = MaterialTheme.typography.titleMedium)
    }
}

@Composable
private fun MoveCategoryDialog(
    app: AppEntry,
    categories: List<AppCategory>,
    onMove: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        HandGlassSurface(
            Modifier.fillMaxWidth().padding(horizontal = 24.dp).heightIn(max = 620.dp),
            cornerRadiusDp = 28,
            contentPadding = PaddingValues(18.dp),
        ) {
            Column(Modifier.fillMaxWidth()) {
                Text("Move ${app.label}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                Text("This overrides automatic sorting until you move it again.", style = MaterialTheme.typography.bodySmall, color = Color.White.copy(alpha = .58f), modifier = Modifier.padding(top = 4.dp, bottom = 10.dp))
                LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    items(categories, key = { it.id }) { category ->
                        Row(
                            Modifier.fillMaxWidth()
                                .background(if (category.id == app.categoryId) LocalHandAccentPalette.current.accentFaint else Color.Transparent, RoundedCornerShape(14.dp))
                                .combinedClickable(onClick = { onMove(category.id) })
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(categoryIcon(category.iconKey), null, tint = LocalHandAccentPalette.current.accentStrong)
                            Spacer(Modifier.width(12.dp))
                            Text(category.name, modifier = Modifier.weight(1f))
                            if (category.id == app.categoryId) Icon(Icons.Rounded.Check, null, tint = LocalHandAccentPalette.current.accentStrong)
                        }
                    }
                }
            }
        }
    }
}

private fun categoryIcon(key: String): ImageVector = when (key) {
    "chat" -> Icons.Rounded.ChatBubble
    "people" -> Icons.Rounded.People
    "play" -> Icons.Rounded.PlayCircle
    "camera" -> Icons.Rounded.PhotoCamera
    "work" -> Icons.Rounded.Work
    "wallet" -> Icons.Rounded.AccountBalanceWallet
    "bag" -> Icons.Rounded.ShoppingBag
    "map" -> Icons.Rounded.Flight
    "home" -> Icons.Rounded.Home
    "gamepad" -> Icons.Rounded.SportsEsports
    "tools" -> Icons.Rounded.Build
    "folder" -> Icons.Rounded.Folder
    else -> Icons.Rounded.Apps
}
