package com.handlauncher

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.handlauncher.data.BatteryRepository
import com.handlauncher.data.DeviceContextRepository
import com.handlauncher.data.AiSettingsRepository
import com.handlauncher.data.WeatherRepository
import com.handlauncher.data.WeatherLocation
import com.handlauncher.data.WeatherState
import com.handlauncher.data.CalendarEventState
import com.handlauncher.data.BatteryState
import com.handlauncher.data.LauncherPreferencesRepository
import com.handlauncher.data.LauncherRepository
import com.handlauncher.data.NewsRepository
import com.handlauncher.data.NewsState
import com.handlauncher.data.MediaPlaybackState
import com.handlauncher.data.MediaSessionRepository
import com.handlauncher.data.NotificationRepository
import com.handlauncher.data.LauncherNotification
import com.handlauncher.data.IconPackRepository
import com.handlauncher.data.IconPackInfo
import com.handlauncher.data.ConnectivityRepository
import com.handlauncher.data.ConnectivityState
import com.handlauncher.domain.*
import com.handlauncher.engine.ContextEngine
import com.handlauncher.engine.LocalPrototypeAiLayoutProvider
import com.handlauncher.engine.GeminiAiLayoutProvider
import com.handlauncher.engine.SearchEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDateTime
import java.util.UUID
import org.json.JSONObject
import kotlinx.coroutines.delay
import kotlin.math.round

enum class SurfaceMode {
    HOME, SEARCH, APP_LIBRARY, AI_DESIGN, CATEGORY_EDITOR, SMART_OBJECT_EDITOR, CANVAS_OBJECT_EDITOR, STACK_EDITOR, OBJECT_PALETTE, AUTOMATION_EDITOR, SETTINGS
}

data class LauncherUiState(
    val apps: List<AppEntry> = emptyList(),
    val categories: List<AppCategory> = DefaultCategories.all,
    val selectedCategoryId: String = DefaultCategories.communication.id,
    val categoryAssignments: Map<String, String> = emptyMap(),
    val searchQuery: String = "",
    val searchResults: List<AppEntry> = emptyList(),
    val surfaceMode: SurfaceMode = SurfaceMode.HOME,
    val battery: BatteryState = BatteryState(100, false),
    val profile: LayoutProfile = LayoutProfile.PHONE_PORTRAIT,
    val contextDecision: ContextDecision = ContextDecision(emptyList(), emptyList()),
    val aiPrompt: String = "",
    val aiProposal: AiLayoutProposal? = null,
    val activeLayout: LauncherLayout? = null,
    val activeTheme: AiThemeTokens? = null,
    val editMode: Boolean = false,
    val editingApp: AppEntry? = null,
    val editingSmartObject: SmartObject? = null,
    val editingStack: SmartStackDefinition? = null,
    val smartObjectOverrides: Map<String, SmartObject> = emptyMap(),
    val smartStacks: Map<String, SmartStackDefinition> = emptyMap(),
    val androidWidgetIds: Set<Int> = emptySet(),
    val automationRules: List<ContextRule> = emptyList(),
    val editingRule: ContextRule? = null,
    val connectedAudioNames: Set<String> = emptySet(),
    val nextCalendarEventInMinutes: Int? = null,
    val nextCalendarEvent: CalendarEventState? = null,
    val calendarPermissionGranted: Boolean = false,
    val aiSettings: AiProviderSettings = AiProviderSettings(),
    val weather: WeatherState = WeatherState(),
    val news: NewsState = NewsState(),
    val media: MediaPlaybackState = MediaPlaybackState(),
    val notifications: List<LauncherNotification> = emptyList(),
    val iconPacks: List<IconPackInfo> = emptyList(),
    val selectedIconPackPackage: String? = null,
    val connectivity: ConnectivityState = ConnectivityState(),
    val statusMessage: String? = null,
    val loading: Boolean = true,
)

class LauncherViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = LauncherRepository(application)
    private val preferences = LauncherPreferencesRepository(application)
    private val batteryRepository = BatteryRepository(application)
    private val deviceContextRepository = DeviceContextRepository(application)
    private val aiSettingsRepository = AiSettingsRepository(application)
    private val weatherRepository = WeatherRepository(application)
    private val newsRepository = NewsRepository(application)
    private val mediaSessionRepository = MediaSessionRepository(application)
    private val notificationRepository = NotificationRepository()
    private val iconPackRepository = IconPackRepository(application)
    private val connectivityRepository = ConnectivityRepository(application)
    private val searchEngine = SearchEngine()
    private val contextEngine = ContextEngine()
    private val localAiProvider = LocalPrototypeAiLayoutProvider()

    private val _state = MutableStateFlow(LauncherUiState())
    val state: StateFlow<LauncherUiState> = _state.asStateFlow()

    init {
        refreshApps()
        viewModelScope.launch {
            batteryRepository.state.collect { battery ->
                _state.update { it.copy(battery = battery) }
                refreshContext()
            }
        }
        viewModelScope.launch {
            while (true) {
                refreshContext()
                delay(60_000)
            }
        }
        viewModelScope.launch {
            while (true) {
                refreshConnectivity()
                delay(8_000)
            }
        }
        viewModelScope.launch {
            while (true) {
                refreshBrief()
                delay(30 * 60_000L)
            }
        }
        viewModelScope.launch {
            notificationRepository.notifications.collect { notifications ->
                _state.update { it.copy(notifications = notifications) }
            }
        }
        viewModelScope.launch {
            while (true) {
                val media = withContext(Dispatchers.IO) { mediaSessionRepository.snapshot() }
                _state.update { it.copy(media = media) }
                delay(2_000)
            }
        }
    }

    fun refreshApps() {
        viewModelScope.launch {
            val loaded = withContext(Dispatchers.IO) { repository.loadLaunchableApps() }
            val persistedCategories = preferences.loadCategories()
            val assignments = preferences.loadCategoryAssignments()
            val validCategoryIds = persistedCategories.mapTo(mutableSetOf()) { it.id }

            val apps = loaded.map { app ->
                val assigned = assignments[app.stableId]
                if (assigned != null && assigned in validCategoryIds) app.copy(categoryId = assigned) else app
            }
            val categoryIdsInUse = apps.map { it.categoryId }.toSet()
            val categories = persistedCategories.filter {
                it.userCreated || it.id in categoryIdsInUse || it.id == DefaultCategories.other.id
            }.sortedBy { it.sortOrder }
            val currentSelected = _state.value.selectedCategoryId
            val selected = currentSelected.takeIf { id -> categories.any { it.id == id } }
                ?: categories.firstOrNull()?.id
                ?: DefaultCategories.other.id
            val overrides = withContext(Dispatchers.IO) {
                apps.mapNotNull { app -> preferences.loadSmartObject(app.stableId)?.let { app.stableId to it } }.toMap()
            }
            val loadedDefaultStack = preferences.loadSmartStack(DEFAULT_STACK_ID) ?: defaultStackDefinition()
            val defaultStack = if (loadedDefaultStack.items.any { it.widgetKind == NativeWidgetKind.CONNECTIVITY }) {
                loadedDefaultStack
            } else {
                loadedDefaultStack.copy(items = loadedDefaultStack.items + StackItem(NativeWidgetKind.CONNECTIVITY, allowAutomaticPromotion = false))
            }.also(preferences::saveSmartStack)
            val persistedStackIds = LayoutProfile.entries.asSequence()
                .mapNotNull(preferences::loadLayout)
                .flatMap { it.pages.asSequence() }
                .flatMap { it.objects.asSequence() }
                .filter { it.type == SmartObjectType.SMART_STACK }
                .mapNotNull { it.payload["stackId"] }
                .toSet() + DEFAULT_STACK_ID
            val stacks = persistedStackIds.mapNotNull { id ->
                (if (id == DEFAULT_STACK_ID) defaultStack else preferences.loadSmartStack(id))?.let { id to it }
            }.toMap()
            val iconPacks = withContext(Dispatchers.IO) { iconPackRepository.discover() }
            val selectedIconPack = iconPackRepository.selectedPackage()
                ?.takeIf { selected -> iconPacks.any { it.packageName == selected } }

            _state.update {
                it.copy(
                    apps = apps,
                    categories = categories,
                    selectedCategoryId = selected,
                    categoryAssignments = assignments,
                    smartObjectOverrides = overrides,
                    smartStacks = stacks,
                    iconPacks = iconPacks,
                    selectedIconPackPackage = selectedIconPack,
                    androidWidgetIds = preferences.loadAndroidWidgetIds(),
                    automationRules = preferences.loadAutomationRules(),
                    calendarPermissionGranted = deviceContextRepository.hasCalendarPermission(),
                    aiSettings = aiSettingsRepository.settings(),
                    weather = it.weather.copy(location = weatherRepository.location()),
                    activeLayout = cleanLegacyStarterApps(preferences.loadLayout(it.profile)),
                    activeTheme = preferences.loadTheme(it.profile),
                    searchResults = searchEngine.search(apps, it.searchQuery),
                    loading = false,
                )
            }
        }
    }

    fun setProfile(profile: LayoutProfile) {
        _state.update {
            if (it.profile == profile) it else it.copy(
                profile = profile,
                activeLayout = cleanLegacyStarterApps(preferences.loadLayout(profile)),
                activeTheme = preferences.loadTheme(profile),
                editMode = false,
            )
        }
        reevaluateContext()
    }

    fun showHome() = _state.update {
        it.copy(
            surfaceMode = SurfaceMode.HOME,
            searchQuery = "",
            editingApp = null,
            editingSmartObject = null,
            editingStack = null,
            editingRule = null,
        )
    }

    fun showSearch() = _state.update {
        it.copy(surfaceMode = SurfaceMode.SEARCH, searchResults = searchEngine.search(it.apps, it.searchQuery))
    }

    fun showLibrary() = _state.update { it.copy(surfaceMode = SurfaceMode.APP_LIBRARY) }
    fun showAiDesign() = _state.update { it.copy(surfaceMode = SurfaceMode.AI_DESIGN) }
    fun showCategoryEditor() = _state.update { it.copy(surfaceMode = SurfaceMode.CATEGORY_EDITOR) }
    fun showObjectPalette() = _state.update { it.copy(surfaceMode = SurfaceMode.OBJECT_PALETTE) }
    fun showAutomationEditor() = _state.update { it.copy(surfaceMode = SurfaceMode.AUTOMATION_EDITOR, editingRule = null) }
    fun showSettings() = _state.update { it.copy(surfaceMode = SurfaceMode.SETTINGS) }

    fun updateSearch(query: String) = _state.update {
        it.copy(searchQuery = query, searchResults = searchEngine.search(it.apps, query))
    }

    fun selectCategory(id: String) = _state.update { it.copy(selectedCategoryId = id) }

    fun launch(app: AppEntry) {
        repository.launch(app)
        showHome()
    }

    fun runLauncherCommand(command: String) {
        executeAction(SmartAction.RunCommand(command), null)
    }

    fun renameCategory(id: String, newName: String) {
        val cleaned = newName.trim()
        if (cleaned.isBlank()) return
        _state.update { current ->
            val updated = current.categories.map { if (it.id == id) it.copy(name = cleaned) else it }
            preferences.saveCategories(mergeWithUnusedDefaults(updated))
            current.copy(categories = updated, statusMessage = "Category renamed")
        }
    }

    fun createCategory(name: String) {
        val cleaned = name.trim()
        if (cleaned.isBlank()) return
        _state.update { current ->
            val category = AppCategory(
                id = "custom_${UUID.randomUUID()}",
                name = cleaned,
                iconKey = "folder",
                sortOrder = (current.categories.maxOfOrNull { it.sortOrder } ?: 0) + 1,
                userCreated = true,
                backgroundTransparencyPercent = 38,
            )
            val updated = current.categories + category
            preferences.saveCategories(mergeWithUnusedDefaults(updated))
            current.copy(categories = updated, selectedCategoryId = category.id, statusMessage = "Category created")
        }
    }

    fun setCategoryTransparency(id: String, percent: Int) {
        _state.update { current ->
            val updated = current.categories.map { category ->
                if (category.id == id) category.copy(backgroundTransparencyPercent = percent.coerceIn(0, 90)) else category
            }
            preferences.saveCategories(mergeWithUnusedDefaults(updated))
            current.copy(categories = updated)
        }
    }

    fun assignAppToCategory(app: AppEntry, categoryId: String) {
        _state.update { current ->
            val assignments = current.categoryAssignments.toMutableMap().apply { put(app.stableId, categoryId) }
            val apps = current.apps.map { if (it.stableId == app.stableId) it.copy(categoryId = categoryId) else it }
            preferences.saveCategoryAssignments(assignments)
            current.copy(
                apps = apps,
                categoryAssignments = assignments,
                searchResults = searchEngine.search(apps, current.searchQuery),
            )
        }
    }

    fun editSmartObject(app: AppEntry) {
        val existing = _state.value.smartObjectOverrides[app.stableId] ?: defaultSmartObject(app)
        _state.update {
            it.copy(surfaceMode = SurfaceMode.SMART_OBJECT_EDITOR, editingApp = app, editingSmartObject = existing)
        }
    }

    fun updateEditingObjectTitle(title: String) = _state.update { current ->
        current.copy(editingSmartObject = current.editingSmartObject?.copy(title = title))
    }

    fun updateEditingObjectAction(slot: GestureSlot, action: SmartAction) = _state.update { current ->
        val obj = current.editingSmartObject ?: return@update current
        val actions = when (slot) {
            GestureSlot.TAP -> obj.actions.copy(tap = action)
            GestureSlot.SWIPE_UP -> obj.actions.copy(swipeUp = action)
            GestureSlot.SWIPE_DOWN -> obj.actions.copy(swipeDown = action)
            GestureSlot.LONG_PRESS -> obj.actions.copy(longPress = action)
        }
        current.copy(editingSmartObject = obj.copy(actions = actions))
    }

    fun editCanvasObject(obj: SmartObject) {
        when (obj.type) {
            SmartObjectType.APP -> obj.payload["appStableId"]?.let { id -> _state.value.apps.firstOrNull { it.stableId == id } }?.let(::editSmartObject)
            SmartObjectType.SMART_STACK -> obj.payload["stackId"]?.let(::editSmartStack)
            SmartObjectType.ANDROID_WIDGET -> _state.update { it.copy(statusMessage = "Resize Android widgets directly on the canvas") }
            else -> _state.update { it.copy(surfaceMode = SurfaceMode.CANVAS_OBJECT_EDITOR, editingSmartObject = obj, editingApp = null) }
        }
    }

    fun updateEditingObjectPayload(key: String, value: String) = _state.update { current ->
        val obj = current.editingSmartObject ?: return@update current
        current.copy(editingSmartObject = obj.copy(payload = obj.payload + (key to value)))
    }

    fun saveEditingCanvasObject() {
        val obj = _state.value.editingSmartObject ?: return
        _state.update { current ->
            val updated = current.activeLayout?.mapObjects { existing -> if (existing.id == obj.id) obj else existing } ?: return@update current
            preferences.saveLayout(updated)
            current.copy(activeLayout = updated, editingSmartObject = null, surfaceMode = SurfaceMode.HOME, statusMessage = "Object updated")
        }
    }

    fun saveEditingSmartObject() {
        val current = _state.value
        val app = current.editingApp ?: return
        val obj = current.editingSmartObject ?: return
        preferences.saveSmartObject(app.stableId, obj)
        _state.update { state ->
            val updatedLayout = state.activeLayout?.mapObjects { existing ->
                if (existing.payload["appStableId"] == app.stableId) {
                    obj.copy(id = existing.id, rect = existing.rect, payload = existing.payload)
                } else existing
            }
            if (updatedLayout != null) preferences.saveLayout(updatedLayout)
            state.copy(
                smartObjectOverrides = state.smartObjectOverrides + (app.stableId to obj),
                activeLayout = updatedLayout,
                surfaceMode = SurfaceMode.HOME,
                editingApp = null,
                editingSmartObject = null,
                statusMessage = "Smart Object saved",
            )
        }
    }

    fun enterEditMode() {
        _state.update { current ->
            val layout = current.activeLayout ?: starterLayout(current.profile, current.apps, current.smartObjectOverrides)
            preferences.saveLayout(layout)
            current.copy(activeLayout = layout, editMode = !layout.locked, statusMessage = if (layout.locked) "Layout is locked" else "Edit mode")
        }
    }

    fun exitEditMode() {
        _state.value.activeLayout?.let(preferences::saveLayout)
        _state.update { it.copy(editMode = false, statusMessage = "Layout saved") }
    }

    fun toggleLayoutLock() {
        _state.update { current ->
            val layout = (current.activeLayout ?: starterLayout(current.profile, current.apps, current.smartObjectOverrides))
                .let { it.copy(locked = !it.locked) }
            preferences.saveLayout(layout)
            current.copy(
                activeLayout = layout,
                editMode = if (layout.locked) false else current.editMode,
                statusMessage = if (layout.locked) "Layout locked" else "Layout unlocked",
            )
        }
    }

    fun toggleFinePositioning() {
        _state.update { current ->
            val layout = current.activeLayout ?: return@update current
            val updated = layout.copy(finePositioning = !layout.finePositioning)
            preferences.saveLayout(updated)
            current.copy(activeLayout = updated, statusMessage = if (updated.finePositioning) "Fine positioning on" else "Grid snapping on")
        }
    }

    fun updateObjectRect(objectId: String, candidate: GridRect, commit: Boolean = false) {
        _state.update { current ->
            val layout = current.activeLayout ?: return@update current
            if (!current.editMode || layout.locked) return@update current
            val normalized = normalizeRect(candidate, layout)
            val updated = layout.mapObjects { if (it.id == objectId) it.copy(rect = normalized) else it }
            if (commit) preferences.saveLayout(updated)
            current.copy(activeLayout = updated)
        }
    }

    fun commitActiveLayout() {
        _state.value.activeLayout?.let(preferences::saveLayout)
    }

    fun executeSmartObjectGesture(obj: SmartObject, slot: GestureSlot) {
        val action = when (slot) {
            GestureSlot.TAP -> obj.actions.tap
            GestureSlot.SWIPE_UP -> obj.actions.swipeUp
            GestureSlot.SWIPE_DOWN -> obj.actions.swipeDown
            GestureSlot.LONG_PRESS -> obj.actions.longPress
        }
        executeAction(action, obj)
    }

    private fun executeAction(action: SmartAction, source: SmartObject?) {
        when (action) {
            is SmartAction.LaunchApp -> {
                _state.value.apps.firstOrNull {
                    it.packageName == action.packageName && it.activityName == action.activityName
                }?.let(::launch)
            }
            is SmartAction.OpenCollection -> {
                if (_state.value.categories.any { it.id == action.collectionId }) {
                    _state.update { it.copy(selectedCategoryId = action.collectionId, surfaceMode = SurfaceMode.APP_LIBRARY) }
                }
            }
            is SmartAction.ShowSurface -> when (action.surfaceId) {
                "search" -> showSearch()
                "app_library" -> showLibrary()
                "ai_design" -> showAiDesign()
                "smart_object_editor" -> source?.payload?.get("appStableId")
                    ?.let { stableId -> _state.value.apps.firstOrNull { it.stableId == stableId } }
                    ?.let(::editSmartObject)
                "stack_editor" -> source?.payload?.get("stackId")?.let(::editSmartStack)
                "object_palette" -> showObjectPalette()
                "automation" -> showAutomationEditor()
                "settings" -> showSettings()
                else -> _state.update { it.copy(statusMessage = "Surface '${action.surfaceId}' is not wired yet") }
            }
            is SmartAction.RunCommand -> when (action.command.trim().lowercase()) {
                "search" -> showSearch()
                "library", "apps" -> showLibrary()
                "ai", "design" -> showAiDesign()
                "automation", "automations" -> showAutomationEditor()
                "settings" -> showSettings()
                "edit", "add" -> showObjectPalette()
                else -> _state.update { it.copy(statusMessage = "Command: ${action.command}") }
            }
            SmartAction.None -> Unit
        }
    }

    fun editSmartStack(stackId: String = DEFAULT_STACK_ID) {
        val loaded = _state.value.smartStacks[stackId] ?: preferences.loadSmartStack(stackId) ?: defaultStackDefinition()
        val stack = if (loaded.items.any { it.widgetKind == NativeWidgetKind.CONNECTIVITY }) loaded
        else loaded.copy(items = loaded.items + StackItem(NativeWidgetKind.CONNECTIVITY, allowAutomaticPromotion = false))
        _state.update { it.copy(surfaceMode = SurfaceMode.STACK_EDITOR, editingStack = stack) }
    }

    fun updateEditingStackName(name: String) = _state.update { current ->
        current.copy(editingStack = current.editingStack?.copy(name = name))
    }

    fun setStackSmartRotation(enabled: Boolean) = _state.update { current ->
        current.copy(editingStack = current.editingStack?.copy(smartRotationEnabled = enabled))
    }

    fun setStackAutoLoop(enabled: Boolean) = _state.update { current ->
        current.copy(editingStack = current.editingStack?.copy(autoLoopEnabled = enabled))
    }

    fun setStackWidgetEnabled(kind: NativeWidgetKind, enabled: Boolean) = _state.update { current ->
        val stack = current.editingStack ?: return@update current
        val core = setOf(NativeWidgetKind.CLOCK, NativeWidgetKind.WEATHER, NativeWidgetKind.BATTERY, NativeWidgetKind.CONNECTIVITY)
        if (!enabled && kind in core) return@update current
        val items = if (enabled) {
            if (stack.items.any { it.widgetKind == kind }) stack.items else stack.items + StackItem(kind)
        } else stack.items.filterNot { it.widgetKind == kind }
        current.copy(editingStack = stack.copy(items = items))
    }

    fun setStackPromotion(kind: NativeWidgetKind, enabled: Boolean) = _state.update { current ->
        val stack = current.editingStack ?: return@update current
        current.copy(editingStack = stack.copy(items = stack.items.map {
            if (it.widgetKind == kind) it.copy(allowAutomaticPromotion = enabled) else it
        }))
    }

    fun moveStackItem(kind: NativeWidgetKind, delta: Int) = _state.update { current ->
        val stack = current.editingStack ?: return@update current
        val from = stack.items.indexOfFirst { it.widgetKind == kind }
        if (from < 0) return@update current
        val to = (from + delta).coerceIn(0, stack.items.lastIndex)
        if (to == from) return@update current
        val items = stack.items.toMutableList()
        val item = items.removeAt(from)
        items.add(to, item)
        current.copy(editingStack = stack.copy(items = items))
    }

    fun saveEditingStack() {
        val stack = _state.value.editingStack ?: return
        if (stack.items.isEmpty()) {
            _state.update { it.copy(statusMessage = "A stack needs at least one widget") }
            return
        }
        preferences.saveSmartStack(stack)
        _state.update {
            it.copy(
                smartStacks = it.smartStacks + (stack.id to stack),
                editingStack = null,
                surfaceMode = SurfaceMode.HOME,
                statusMessage = "Smart Stack saved",
            )
        }
    }

    fun createAutomationRule() {
        val rule = ContextRule(
            id = "rule_${UUID.randomUUID()}",
            name = "New automation",
            enabled = true,
            conditions = listOf(ContextCondition.TimeBetween(8, 18)),
            effect = ContextEffect.PromoteWidget(NativeWidgetKind.CALENDAR),
            userCreated = true,
        )
        _state.update { it.copy(editingRule = rule, surfaceMode = SurfaceMode.AUTOMATION_EDITOR) }
    }

    fun editAutomationRule(rule: ContextRule) = _state.update { it.copy(editingRule = rule, surfaceMode = SurfaceMode.AUTOMATION_EDITOR) }
    fun cancelAutomationRuleEdit() = _state.update { it.copy(editingRule = null) }

    fun updateEditingRuleName(name: String) = _state.update { current ->
        current.copy(editingRule = current.editingRule?.copy(name = name))
    }

    fun updateEditingRuleEnabled(enabled: Boolean) = _state.update { current ->
        current.copy(editingRule = current.editingRule?.copy(enabled = enabled))
    }

    fun addEditingRuleCondition(condition: ContextCondition) = _state.update { current ->
        val rule = current.editingRule ?: return@update current
        current.copy(editingRule = rule.copy(conditions = rule.conditions + condition))
    }

    fun updateEditingRuleCondition(index: Int, condition: ContextCondition) = _state.update { current ->
        val rule = current.editingRule ?: return@update current
        val updated = rule.conditions.mapIndexed { i, item -> if (i == index) condition else item }
        current.copy(editingRule = rule.copy(conditions = updated))
    }

    fun removeEditingRuleCondition(index: Int) = _state.update { current ->
        val rule = current.editingRule ?: return@update current
        current.copy(editingRule = rule.copy(conditions = rule.conditions.filterIndexed { i, _ -> i != index }))
    }

    fun updateEditingRuleEffect(effect: ContextEffect) = _state.update { current ->
        current.copy(editingRule = current.editingRule?.copy(effect = effect))
    }

    fun saveEditingAutomationRule() {
        val rule = _state.value.editingRule ?: return
        if (rule.name.isBlank() || rule.conditions.isEmpty()) {
            _state.update { it.copy(statusMessage = "Automation needs a name and at least one condition") }
            return
        }
        _state.update { current ->
            val existing = current.automationRules.any { it.id == rule.id }
            val updated = if (existing) current.automationRules.map { if (it.id == rule.id) rule else it } else current.automationRules + rule
            preferences.saveAutomationRules(updated)
            current.copy(automationRules = updated, editingRule = null, statusMessage = "Automation saved")
        }
        refreshContext()
    }

    fun toggleAutomationRule(ruleId: String, enabled: Boolean) {
        _state.update { current ->
            val updated = current.automationRules.map { if (it.id == ruleId) it.copy(enabled = enabled) else it }
            preferences.saveAutomationRules(updated)
            current.copy(automationRules = updated)
        }
        refreshContext()
    }

    fun deleteAutomationRule(ruleId: String) {
        _state.update { current ->
            val updated = current.automationRules.filterNot { it.id == ruleId }
            preferences.saveAutomationRules(updated)
            current.copy(automationRules = updated, editingRule = null, statusMessage = "Automation deleted")
        }
        refreshContext()
    }

    fun onCalendarPermissionResult() {
        _state.update { it.copy(calendarPermissionGranted = deviceContextRepository.hasCalendarPermission()) }
        refreshContext()
    }

    fun saveAiSettings(model: String, apiKey: String?) {
        aiSettingsRepository.saveModel(model)
        if (!apiKey.isNullOrBlank()) aiSettingsRepository.saveApiKey(apiKey)
        _state.update { it.copy(aiSettings = aiSettingsRepository.settings(), statusMessage = "AI settings saved") }
    }

    fun clearAiApiKey() {
        aiSettingsRepository.clearApiKey()
        _state.update { it.copy(aiSettings = aiSettingsRepository.settings(), statusMessage = "AI API key removed") }
    }

    fun saveWeatherLocation(label: String, latitude: Double, longitude: Double) {
        weatherRepository.saveLocation(WeatherLocation(label.trim().ifBlank { "Weather" }, latitude, longitude))
        _state.update { it.copy(weather = it.weather.copy(location = weatherRepository.location()), statusMessage = "Weather location saved") }
        refreshWeather()
    }

    fun refreshWeather() {
        viewModelScope.launch {
            val weather = weatherRepository.refresh()
            _state.update { it.copy(weather = weather) }
            refreshContext()
        }
    }

    fun refreshNews() {
        viewModelScope.launch {
            val news = newsRepository.refresh()
            _state.update { it.copy(news = news) }
        }
    }

    /** Refreshes the whole Brief surface as one unit: weather, calendar/context and news. */
    private fun refreshConnectivity() {
        val bluetoothNames = deviceContextRepository.connectedAudioDeviceNames()
        val snapshot = connectivityRepository.snapshot(bluetoothNames)
        _state.update { it.copy(connectivity = snapshot, connectedAudioNames = bluetoothNames) }
    }

    fun refreshBrief() {
        viewModelScope.launch {
            val weatherJob = async(Dispatchers.IO) { weatherRepository.refresh() }
            val newsJob = async(Dispatchers.IO) { newsRepository.refresh() }
            val weather = weatherJob.await()
            val news = newsJob.await()
            _state.update { it.copy(weather = weather, news = news) }
            refreshContext()
        }
    }

    fun mediaPlayPause() = mediaSessionRepository.playPause()
    fun mediaSeekTo(positionMs: Long) = mediaSessionRepository.seekTo(positionMs)
    fun mediaNext() = mediaSessionRepository.next()
    fun mediaPrevious() = mediaSessionRepository.previous()

    fun openNotification(key: String) = notificationRepository.open(key)
    fun dismissNotification(key: String) = notificationRepository.dismiss(key)

    fun selectIconPack(packageName: String?) {
        iconPackRepository.saveSelectedPackage(packageName)
        _state.update {
            it.copy(
                selectedIconPackPackage = packageName,
                statusMessage = if (packageName == null) "Original icons restored" else "Icon pack applied",
            )
        }
    }

    fun exportBackupJson(): String {
        val root = JSONObject(preferences.exportBackup())
        val weather = weatherRepository.location()
        root.put("schemaVersion", 2)
        root.put(
            "weather",
            JSONObject()
                .put("label", weather.label)
                .put("latitude", weather.latitude)
                .put("longitude", weather.longitude),
        )
        return root.toString(2)
    }

    fun importBackupJson(raw: String): Boolean {
        val ok = preferences.importBackup(raw)
        if (ok) {
            runCatching {
                val weather = JSONObject(raw).optJSONObject("weather")
                if (weather != null) {
                    weatherRepository.saveLocation(
                        WeatherLocation(
                            label = weather.optString("label", "Weather"),
                            latitude = weather.optDouble("latitude", 49.6116),
                            longitude = weather.optDouble("longitude", 6.1319),
                        )
                    )
                }
            }
            _state.update { it.copy(statusMessage = "Backup restored", loading = true) }
            refreshApps()
            refreshWeather()
            refreshContext()
        } else {
            _state.update { it.copy(statusMessage = "Could not restore this backup") }
        }
        return ok
    }

    fun setAiPrompt(prompt: String) = _state.update { it.copy(aiPrompt = prompt) }

    fun generateAiProposal() {
        val snapshot = _state.value
        if (snapshot.aiPrompt.isBlank()) return
        viewModelScope.launch {
            val request = AiLayoutRequest(
                naturalLanguagePrompt = snapshot.aiPrompt,
                targetProfile = snapshot.profile,
                availableApps = snapshot.apps,
                preferredWidgets = setOf(
                    NativeWidgetKind.CLOCK,
                    NativeWidgetKind.CALENDAR,
                    NativeWidgetKind.WEATHER,
                    NativeWidgetKind.BATTERY,
                    NativeWidgetKind.CONNECTIVITY,
                ),
                currentLayout = snapshot.activeLayout,
            )
            val key = aiSettingsRepository.readApiKey()
            val provider = if (!key.isNullOrBlank()) {
                GeminiAiLayoutProvider(key, aiSettingsRepository.settings().model, localAiProvider)
            } else localAiProvider
            val proposal = provider.generate(request)
            _state.update { it.copy(aiProposal = proposal) }
        }
    }

    fun applyAiProposal() {
        val proposal = _state.value.aiProposal ?: return
        val durableLayout = proposal.layout.copy(id = "layout_${proposal.layout.profile.name.lowercase()}")
        preferences.saveLayout(durableLayout)
        preferences.saveTheme(durableLayout.profile, proposal.theme)
        _state.update {
            it.copy(
                activeLayout = durableLayout,
                activeTheme = proposal.theme,
                aiProposal = null,
                surfaceMode = SurfaceMode.HOME,
                editMode = false,
                statusMessage = "AI layout applied to ${durableLayout.profile.name.replace('_', ' ').lowercase()}",
            )
        }
    }

    fun addAppObject(app: AppEntry) {
        val base = _state.value.smartObjectOverrides[app.stableId] ?: defaultSmartObject(app)
        addObjectToActiveLayout(base.copy(id = UUID.randomUUID().toString(), rect = defaultPlacementRect(), payload = base.payload + ("appStableId" to app.stableId)))
    }

    fun addNativeWidget(kind: NativeWidgetKind) {
        addObjectToActiveLayout(
            SmartObject(
                type = SmartObjectType.NATIVE_WIDGET,
                title = kind.name.lowercase().replaceFirstChar { it.uppercase() },
                rect = defaultWidgetRect(),
                actions = ObjectActions(longPress = SmartAction.ShowSurface("object_palette")),
                payload = mapOf("widgetKind" to kind.name),
            )
        )
    }

    fun addSmartStack() {
        val stackId = "stack_${UUID.randomUUID()}"
        val definition = defaultStackDefinition().copy(id = stackId, name = "Smart Stack")
        preferences.saveSmartStack(definition)
        _state.update { it.copy(smartStacks = it.smartStacks + (stackId to definition)) }
        addObjectToActiveLayout(
            SmartObject(
                type = SmartObjectType.SMART_STACK,
                title = definition.name,
                rect = defaultWidgetRect(),
                actions = ObjectActions(longPress = SmartAction.ShowSurface("stack_editor")),
                payload = mapOf("stackId" to stackId),
            )
        )
    }

    fun addCategoryObject(category: AppCategory) {
        addObjectToActiveLayout(
            SmartObject(
                type = SmartObjectType.FOLDER,
                title = category.name,
                rect = defaultPlacementRect(),
                actions = ObjectActions(tap = SmartAction.OpenCollection(category.id)),
                payload = mapOf("categoryId" to category.id),
            )
        )
    }

    fun addCommandObject(title: String, command: String) {
        addObjectToActiveLayout(
            SmartObject(
                type = SmartObjectType.COMMAND,
                title = title,
                rect = defaultPlacementRect(),
                actions = ObjectActions(tap = SmartAction.RunCommand(command)),
                payload = mapOf("command" to command),
            )
        )
    }

    fun addAndroidWidget(appWidgetId: Int) {
        if (appWidgetId < 0) return
        _state.update { current ->
            val ids = current.androidWidgetIds + appWidgetId
            preferences.saveAndroidWidgetIds(ids)
            val baseLayout = current.activeLayout ?: starterLayout(current.profile, current.apps, current.smartObjectOverrides)
            val widget = SmartObject(
                type = SmartObjectType.ANDROID_WIDGET,
                title = "Android widget",
                rect = defaultWidgetRect(),
                payload = mapOf("appWidgetId" to appWidgetId.toString()),
            )
            val updated = baseLayout.addObject(widget.withFreePlacement(baseLayout))
            preferences.saveLayout(updated)
            current.copy(
                androidWidgetIds = ids,
                activeLayout = updated,
                editMode = true,
                surfaceMode = SurfaceMode.HOME,
                statusMessage = "Android widget added to Home",
            )
        }
    }

    fun removeAndroidWidget(appWidgetId: Int) {
        _state.update { current ->
            val ids = current.androidWidgetIds - appWidgetId
            preferences.saveAndroidWidgetIds(ids)
            val updated = current.activeLayout?.removeObjects { it.type == SmartObjectType.ANDROID_WIDGET && it.payload["appWidgetId"] == appWidgetId.toString() }
            if (updated != null) preferences.saveLayout(updated)
            current.copy(androidWidgetIds = ids, activeLayout = updated ?: current.activeLayout, statusMessage = "Widget removed")
        }
    }

    fun removeObject(obj: SmartObject) {
        if (obj.type == SmartObjectType.ANDROID_WIDGET) {
            obj.payload["appWidgetId"]?.toIntOrNull()?.let(::removeAndroidWidget)
            return
        }
        _state.update { current ->
            val updated = current.activeLayout?.removeObjects { it.id == obj.id } ?: return@update current
            preferences.saveLayout(updated)
            current.copy(activeLayout = updated, statusMessage = "Object removed")
        }
    }

    private fun addObjectToActiveLayout(obj: SmartObject) {
        _state.update { current ->
            val base = current.activeLayout ?: starterLayout(current.profile, current.apps, current.smartObjectOverrides)
            val updated = base.addObject(obj.withFreePlacement(base))
            preferences.saveLayout(updated)
            current.copy(
                activeLayout = updated,
                editMode = true,
                surfaceMode = SurfaceMode.HOME,
                statusMessage = "${obj.title} added",
            )
        }
    }

    private fun defaultPlacementRect() = GridRect(0.05f, 0.70f, 0.21f, 0.11f)
    private fun defaultWidgetRect() = GridRect(0.05f, 0.56f, 0.90f, 0.20f)

    private fun SmartObject.withFreePlacement(layout: LauncherLayout): SmartObject {
        val existing = layout.pages.firstOrNull()?.objects.orEmpty()
        val candidates = sequence {
            val stepX = if (rect.width >= 0.5f) 0.04f else 0.23f
            val stepY = if (rect.height >= 0.18f) 0.22f else 0.13f
            var y = 0.04f
            while (y <= 0.88f) {
                var x = 0.04f
                while (x <= 0.92f) {
                    yield(GridRect(x, y, rect.width.coerceAtMost(0.92f), rect.height.coerceAtMost(0.90f)))
                    x += stepX
                }
                y += stepY
            }
        }
        val candidate = candidates.firstOrNull { c -> existing.none { overlaps(c, it.rect) } } ?: rect
        return copy(rect = normalizeRect(candidate, layout))
    }

    private fun overlaps(a: GridRect, b: GridRect): Boolean =
        a.x < b.x + b.width && a.x + a.width > b.x && a.y < b.y + b.height && a.y + a.height > b.y

    private fun LauncherLayout.addObject(obj: SmartObject): LauncherLayout {
        val first = pages.firstOrNull() ?: LayoutPage("home", "Home", emptyList())
        val updatedFirst = first.copy(objects = first.objects + obj)
        return copy(pages = if (pages.isEmpty()) listOf(updatedFirst) else listOf(updatedFirst) + pages.drop(1))
    }

    private fun LauncherLayout.removeObjects(predicate: (SmartObject) -> Boolean): LauncherLayout =
        copy(pages = pages.map { page -> page.copy(objects = page.objects.filterNot(predicate)) })

    fun clearStatusMessage() = _state.update { it.copy(statusMessage = null) }

    private fun starterLayout(
        profile: LayoutProfile,
        apps: List<AppEntry>,
        overrides: Map<String, SmartObject>,
    ): LauncherLayout {
        val columns = when (profile) {
            LayoutProfile.EXTERNAL_DISPLAY -> 12
            LayoutProfile.INNER_FOLD -> 8
            LayoutProfile.PHONE_LANDSCAPE -> 8
            else -> 4
        }
        val rows = if (profile == LayoutProfile.EXTERNAL_DISPLAY) 8 else 10
        val objects = buildList {
            add(
                SmartObject(
                    id = "home_stack_object",
                    type = SmartObjectType.SMART_STACK,
                    title = "Smart Stack",
                    rect = GridRect(0.05f, 0.04f, 0.90f, 0.25f),
                    actions = ObjectActions(longPress = SmartAction.ShowSurface("stack_editor")),
                    payload = mapOf("stackId" to DEFAULT_STACK_ID),
                )
            )
        }
        return LauncherLayout(
            id = "layout_${profile.name.lowercase()}",
            name = "BOAL layout",
            profile = profile,
            columns = columns,
            rows = rows,
            finePositioning = true,
            locked = false,
            pages = listOf(LayoutPage("home", "Home", objects)),
        )
    }

    private fun cleanLegacyStarterApps(layout: LauncherLayout?): LauncherLayout? {
        if (layout == null) return null
        val cleaned = layout.copy(pages = layout.pages.map { page ->
            page.copy(objects = page.objects.filterNot { it.id.startsWith("home_app_") })
        })
        if (cleaned != layout) preferences.saveLayout(cleaned)
        return cleaned
    }

    private fun defaultSmartObject(app: AppEntry) = SmartObject(
        type = SmartObjectType.APP,
        title = app.label,
        rect = GridRect(0f, 0f, 0.25f, 0.12f),
        tags = app.tags,
        actions = ObjectActions(
            tap = SmartAction.LaunchApp(app.packageName, app.activityName),
            swipeUp = SmartAction.OpenCollection(app.categoryId),
            swipeDown = SmartAction.ShowSurface("search"),
            longPress = SmartAction.ShowSurface("smart_object_editor"),
        ),
        payload = mapOf("appStableId" to app.stableId),
    )

    private fun defaultStackDefinition() = SmartStackDefinition(
        id = DEFAULT_STACK_ID,
        name = "Home Stack",
        items = listOf(
            StackItem(NativeWidgetKind.CLOCK, allowAutomaticPromotion = false),
            StackItem(NativeWidgetKind.CALENDAR, allowAutomaticPromotion = false),
            StackItem(NativeWidgetKind.WEATHER, allowAutomaticPromotion = false),
            StackItem(NativeWidgetKind.BATTERY, allowAutomaticPromotion = false),
            StackItem(NativeWidgetKind.CONNECTIVITY, allowAutomaticPromotion = false),
        ),
        smartRotationEnabled = false,
    )

    private fun normalizeRect(candidate: GridRect, layout: LauncherLayout): GridRect {
        val minW = 1f / layout.columns.coerceAtLeast(1)
        val minH = 1f / layout.rows.coerceAtLeast(1)
        var width = candidate.width.coerceIn(minW, 1f)
        var height = candidate.height.coerceIn(minH, 1f)
        var x = candidate.x.coerceIn(0f, 1f - width)
        var y = candidate.y.coerceIn(0f, 1f - height)
        if (!layout.finePositioning) {
            fun snap(value: Float, cells: Int) = round(value * cells) / cells
            width = snap(width, layout.columns).coerceAtLeast(minW)
            height = snap(height, layout.rows).coerceAtLeast(minH)
            x = snap(x, layout.columns).coerceIn(0f, 1f - width)
            y = snap(y, layout.rows).coerceIn(0f, 1f - height)
        }
        return GridRect(x, y, width, height)
    }

    private fun LauncherLayout.mapObjects(transform: (SmartObject) -> SmartObject): LauncherLayout =
        copy(pages = pages.map { page -> page.copy(objects = page.objects.map(transform)) })

    private fun mergeWithUnusedDefaults(visible: List<AppCategory>): List<AppCategory> {
        val ids = visible.mapTo(mutableSetOf()) { it.id }
        return (visible + DefaultCategories.all.filterNot { it.id in ids }).distinctBy { it.id }
    }

    fun loadSmartStackPosition(stackId: String): Int =
        preferences.loadSmartStackPosition(_state.value.profile, stackId)

    fun saveSmartStackPosition(stackId: String, index: Int) {
        preferences.saveSmartStackPosition(_state.value.profile, stackId, index)
    }

    fun refreshContext() {
        viewModelScope.launch {
            val audioNames = withContext(Dispatchers.IO) { deviceContextRepository.connectedAudioDeviceNames() }
            val nextEvent = withContext(Dispatchers.IO) { deviceContextRepository.nextCalendarEvent() }
            _state.update { current ->
                val snapshot = ContextSnapshot(
                    now = LocalDateTime.now(),
                    phoneBatteryPercent = current.battery.percent,
                    isCharging = current.battery.charging,
                    layoutProfile = current.profile,
                    connectedBluetoothNames = audioNames,
                    nextCalendarEventInMinutes = nextEvent?.minutesUntil,
                    rainExpectedInMinutes = current.weather.rainExpectedInMinutes,
                )
                current.copy(
                    connectedAudioNames = audioNames,
                    nextCalendarEventInMinutes = nextEvent?.minutesUntil,
                    nextCalendarEvent = nextEvent,
                    calendarPermissionGranted = deviceContextRepository.hasCalendarPermission(),
                    contextDecision = contextEngine.evaluate(snapshot, current.automationRules.ifEmpty { preferences.loadAutomationRules() }),
                )
            }
        }
    }

    private fun reevaluateContext() = refreshContext()

    companion object {
        const val DEFAULT_STACK_ID = "default_home_stack"
    }
}
