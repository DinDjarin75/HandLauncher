# Changelog

## 1.0.0-beta1.5-fix1
- Fixed missing Compose `detectVerticalDragGestures` import caught by GitHub Actions.
- No behavior changes from beta1.5.

## 1.0.0-beta1.5

- Fixed notification interaction by giving the notification body its own explicit tap target and adding robust PendingIntent/source-app fallback opening while preserving the dedicated dismiss control.
- Connectivity now scopes telephony reads to Android's default data subscription so dual-SIM devices report the registered cellular generation instead of falling back to a generic Mobile label.
- Cellular generation labels and signal state use the adaptive wallpaper accent.
- Removed the redundant numeric battery percentage from inside the charge gauge; the gauge now keeps the battery-state glyph while the main percentage remains the single numeric readout.
- Reverted Home utility controls to one widget-matched glass capsule with plain white icons and no nested circular containers.
- Downward Search is now claimed only from the center 40% of Home. Downward gestures from the outer 30% on either side remain unconsumed for system notification/control-center gestures; swipe-up App Library remains available across Home.

## 1.0.0-beta1.4

- Added Wallpaper Adaptive Accent as a launcher-wide visual feature. BOAL listens for system-wallpaper color changes, prefers the wallpaper primary color when usable, falls back to stronger supporting colors for neutral primaries, and normalizes extreme tones for UI contrast.
- Adaptive accent now drives glass outlines, progress gauges, media progress, active controls, connectivity signal state, notification chrome and Home utility controls while neutral glass surfaces remain wallpaper-independent.
- Added a visible Adaptive Accent status/swatch to Settings > Appearance.
- Redesigned the Clock card with a day-progress gauge, next-alarm status and stronger information hierarchy.
- Redesigned the Battery card with an adaptive circular charge gauge, connected-device line and clearer charging/on-battery state.
- Redesigned the contextual Media card with larger artwork, refined transport controls, output-device indicator, elapsed/total duration and a functional seek scrubber.
- Media session state now includes duration, estimated live playback position and seek capability; BOAL forwards scrubber changes to Android media-session seekTo().
- Refined the notification capsule and Home control capsule to match the adaptive glass design language.
- Preserved beta1.3 Smart Stack behavior: five permanent cards, contextual Media as an optional sixth card, manual looping only, and remembered selection during an active media session.

## 1.0.0-beta1.3

- Rebuilt Smart Stack navigation on a nested Compose HorizontalPager instead of manual drag-threshold state.
- Default stack always exposes all five permanent cards: Clock, Calendar, Weather, Battery, Connectivity.
- Added true manual circular wraparound using duplicate edge pages; there is still no timed auto-advance.
- The Smart Stack now owns horizontal gestures inside its bounds so Home/Brief paging cannot steal an in-stack swipe.
- Active Media is an optional sixth page. It may promote once when a new media session begins.
- The selected card is remembered for the lifetime of an active media session, so Brief -> Home returns to the card the user actually left selected.

## 1.0.0-beta1.2

- Fixed Smart Stack media re-promotion after leaving Home for Brief and returning.
- Media may promote once per active media session; manual swipe choice then remains authoritative.
- Restored a canonical default permanent stack: Clock, Calendar, Weather, Battery, Connectivity.
- Preserved manual circular swipe looping with no timed auto-advance.


## 1.0.0-beta1.1 — BOAL Launcher

- Fixed Fold cover placement by reading the physical top display-cutout bounding rectangle instead of relying on the fullscreen Compose inset; BOAL now applies the cutout rule to both COVER and PHONE_PORTRAIT profiles so Samsung profile classification cannot bypass it.
- Smart Stack is a manual circular loop again: swipe past the last card to return to the first, and vice versa. There is no timer-based or automatic cycling of permanent widgets.
- Active Media now joins the same circular loop as an extra card. It may promote once when a playback session starts, but manual swipes win after that; the Media card remains available until playback ends.
- When playback ends while Media is selected, the Stack returns to the remembered permanent card.
- Strengthened notification filtering for Samsung media surfaces by excluding transport/media-session notifications and the Samsung `MediaOngoingActivity` entry in addition to ongoing/no-clear/foreground flags.

## 1.0.0-beta1 — BOAL Launcher

- Renamed the consumer product from Hand Launcher to **BOAL Launcher** (Best Of All Launchers) and promoted the project to its first beta.
- Added a new adaptive BOAL launcher icon and updated app-facing labels, backup naming and project identity.
- Kept the existing Android application ID internally so beta1 installs over alpha07 without wiping launcher data, layouts or permissions.
- Cover-screen Smart Stack now starts immediately below the actual display cutout with a 0.5 physical-pixel gap, avoiding the hole-punch camera.
- Removed automatic Smart Stack cycling. Permanent cards move only by manual horizontal swipe.
- Media is now the only automatic Smart Stack context: active playback pins the Media card until playback ends, then returns to the remembered permanent card.
- Expanded weather data to five forecast days.
- Weather Smart Stack card now uses its lower space for a compact five-day forecast strip with native condition graphics and high/low temperatures.
- Brief weather forecast expanded to five days for consistency with the Stack.
- Carries forward alpha07 notification capsule, dismiss controls, icon-pack engine, Connectivity widget and fullscreen launcher behavior.

## 1.0.0-alpha07

- Smart Stack media promotion is session-aware: a new media session may surface the player once, but a manual swipe back to Clock/permanent content wins until that session ends.
- Clock remains the default permanent Smart Stack position when no saved position exists.
- Added an on-demand glass notification capsule below the Smart Stack controls; it is not composed at all when there are no eligible notifications.
- Notification capsule excludes ongoing, foreground-service, no-clear, group-summary and launcher-owned persistent notifications.
- Shows the latest two notifications at normal height and scrolls vertically when more are available.
- Each notification uses the app icon, notification text and a dedicated × dismiss action; tapping the row opens the notification destination.
- Added a shared icon-pack resolver with standard appfilter.xml support and automatic fallback to original app icons.
- Added Settings icon-pack selection for installed compatible APK packs, including Icon Pack Studio-style exports.
- Selected icon packs now flow through Home, App Library, Search, editors and notification icons via one launcher-wide icon pipeline.
- Renamed notification-listener permission entry to Notifications & media access because the same Android permission powers both contextual media and the notification capsule.
- Home now hides the Android status bar and uses the reclaimed vertical space for a taller Smart Stack surface.
- Added a permanent Connectivity Smart Stack card immediately before contextual Media: Wi-Fi name/speed, mobile network generation/operator/signal bars, and connected Bluetooth audio devices.
- Connectivity is a required Smart Stack item and is migrated into existing saved default stacks.

## 1.0.0-alpha06.1

- Hotfix external widget destinations so Clock and Calendar event taps cannot crash the launcher.
- Restore the generic Android SHOW_ALARMS contract with safe Clock-app fallback.
- Restore the alpha05 calendar-event launch behavior with guarded Calendar fallback.
- Replace Google News wrapper feeds with merged direct publisher RSS feeds that expose article imagery.
- Prefer image-bearing stories while preserving recency and resolve missing images from publisher OpenGraph/content.

## 1.0.0-alpha06

- Anchored the default Smart Stack directly below the status-bar safe area on Home.
- Consolidated Automations, Settings, Edit and AI controls into one widget-matched glass capsule positioned below the Smart Stack at the right edge.
- Persisted the last viewed permanent Smart Stack widget per display profile and stack, including across launcher restarts.
- Removed Smart Stack page/navigation indicators.
- Corrected Clock navigation to prefer the device alarm list (including Samsung Clock) instead of Date & Time settings.
- Corrected Battery navigation to open the top-level Battery settings screen rather than Battery Saver.
- Split Calendar interactions: the CALENDAR header opens the Calendar app while the event row opens that exact event.
- Added shared native weather graphics to the Smart Stack weather widget and Brief current/forecast weather surfaces.

## 1.0.0-alpha05

- Added direct left/right paging between App Library categories with synchronized category chips.
- Smart Stack auto-loop is decoupled from generic context rules; Clock, Weather and Battery are permanent core widgets.
- Added contextual media player for active music/podcast sessions, including artwork, metadata, play/pause, previous/next and app launch.
- Made native Smart Stack widgets actionable: Clock opens alarms, Calendar opens the relevant event/day, Weather opens weather, Battery opens battery settings.
- Added whole-Brief automatic refresh every 30 minutes and manual full-page refresh.
- Added collapsible Headlines, Entertainment, Tech and LEGO sections, each with five latest stories and identical glass/card treatment.
- Improved article-image resolution and image loading fallbacks while preserving the 20/80 image/text card layout.
- Removed workshop/technical labels from everyday UI and migrated legacy auto-seeded Home app objects away.

## 1.0.0-alpha04

- Unified Brief modules and native widgets on the same translucent glass surface.
- Finished high-contrast foreground treatment for wallpaper-facing launcher UI and native widget content.
- Removed arbitrary installed-app population from a fresh Home; users add apps intentionally.
- Added 20/80 image/text headline cards with lead-image discovery from feed media and article OpenGraph/Twitter metadata.
- Humanized calendar timing (for example, Tomorrow · 15:35 instead of large minute counts).

## 1.0.0-alpha03 — Contrast + Briefing
- Adaptive wallpaper readability now samples the upper wallpaper instead of relying only on global wallpaper hints.
- Direct app labels keep an opposite-color shadow for readability across mixed bright/dark wallpaper regions.
- Smart Stacks now navigate horizontally: swipe left for next, swipe right for previous.
- Smart Stacks wrap continuously at both ends and support automatic looping; contextual promotion temporarily pauses looping without losing the user's position.
- Stack editor exposes the auto-loop toggle and horizontal ordering controls.
- Left page rebuilt as a personal briefing surface with greeting, current weather, four-day forecast, phone battery, next Calendar event, contextual suggestions and live headlines.
- Headline feed uses a Luxembourg-localized RSS provider with no API key and keeps Google Discover as an optional shortcut.

## 1.0.0-alpha02 — UX refinement
- Smoother, density-aware vertical gestures with resisted motion feedback.
- Swipe down from the top of an App Library category returns Home.
- Per-category background transparency slider and Solid/Tinted/Glass/Clear presets.
- Wallpaper-first theming: AI transparency styles cards/widgets instead of veiling the wallpaper.
- Native Hand Feed replaces the Google Discover placeholder while retaining a Discover shortcut.
- More reliable Samsung/Android default-Home selector.
- Reduced persistent help/tutorial text on primary launcher surfaces.

## 1.0.0-alpha01 — 2026-10-25
- Consolidated the launcher into one declarative, per-display-profile architecture.
- Added real Android HOME registration, app discovery and Home-role request.
- Added swipe-down Search/Command Layer and swipe-up categorized App Library.
- Added Android-category-aware automatic classification plus persisted user overrides.
- Added free-form Home editing, drag/resize, fine positioning, grid snapping and layout locking.
- Added Smart Object tap/swipe/long-press execution and editing.
- Added Home object palette for apps, Hand widgets, Android widgets, Smart Stacks, categories and commands.
- Added real `AppWidgetHost` placement/configuration/removal on the Home canvas.
- Added editable native Clock, Calendar, Weather and Battery widgets.
- Added multi-instance editable Smart Stacks with naming, reorder and contextual promotion rules.
- Added Jetpack Window fold/posture handling and independent external-display desktop layouts.
- Added user-editable Context Automation rules for battery, charging, time, display, audio device, Calendar and rain.
- Added actionable contextual command suggestions.
- Added Open-Meteo weather provider using a manual coarse location.
- Added local AI layout designer plus optional Gemini-backed constrained design generation.
- Added AI theme rendering for light/dark, transparency, corners and typography mood.
- Added Android-Keystore encryption for the optional Gemini key.
- Added JSON backup/restore including weather configuration while excluding AI credentials.
- Added current Android build configuration, JUnit core tests and a GitHub Actions APK build workflow.
- Added gesture arbitration so Home search/library swipes do not steal Smart Object gestures.

## Earlier development snapshots
0.1–0.3 established the initial launcher shell, persistence, AppWidget hosting, Fold profiles, Smart Objects and free-form editor. Those snapshots were folded into the 1.0 alpha source milestone above.
