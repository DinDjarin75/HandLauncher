# Validation report — BOAL Launcher 1.0.0-beta1.5-fix1

Date: 26 October 2026

Completed in the current runtime:
- GitHub Actions beta1.5 compile failure isolated to a missing `detectVerticalDragGestures` import; import added in fix1.
- Android manifest and resource XML parse successfully.
- Kotlin PSI syntax parse completed across all 49 Kotlin files with zero syntax errors.
- Beta1.5-fix1 version code/name verified (`24` / `1.0.0-beta1.5-fix1`).
- Connectivity reads are scoped to Android's default data subscription before mapping cellular generation.
- Cellular type and signal UI use the adaptive wallpaper accent.
- Battery gauge keeps the state glyph but no longer repeats the numeric percentage.
- Home utility controls are one glass capsule with white icons and no nested button containers.
- Notification body has an explicit tap target; notification opening uses content/full-screen PendingIntent with source-app fallback.
- Downward Search gesture is center-strip only; side downward gestures are left unconsumed for system handling. Swipe-up App Library remains launcher-owned.
- Source archive integrity and source manifest are regenerated from the packaged beta1.5-fix1 tree.

Authoritative Android/Compose validation remains GitHub Actions: Java 17 + Android 36 + Gradle 9.6 -> unit tests -> `:app:assembleDebug` -> APK artifact.
