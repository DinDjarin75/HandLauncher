package com.handlauncher.domain

import java.util.UUID

enum class SmartObjectType {
    APP, FOLDER, NATIVE_WIDGET, ANDROID_WIDGET, SMART_STACK, SHORTCUT, COMMAND
}

enum class GestureSlot { TAP, SWIPE_UP, SWIPE_DOWN, LONG_PRESS }

sealed interface SmartAction {
    data class LaunchApp(val packageName: String, val activityName: String) : SmartAction
    data class OpenCollection(val collectionId: String) : SmartAction
    data class ShowSurface(val surfaceId: String) : SmartAction
    data class RunCommand(val command: String) : SmartAction
    data object None : SmartAction
}

data class ObjectActions(
    val tap: SmartAction = SmartAction.None,
    val swipeUp: SmartAction = SmartAction.None,
    val swipeDown: SmartAction = SmartAction.None,
    val longPress: SmartAction = SmartAction.None,
)

data class GridRect(
    val x: Float,
    val y: Float,
    val width: Float,
    val height: Float,
)

data class SmartObject(
    val id: String = UUID.randomUUID().toString(),
    val type: SmartObjectType,
    val title: String,
    val rect: GridRect,
    val tags: Set<String> = emptySet(),
    val actions: ObjectActions = ObjectActions(),
    val payload: Map<String, String> = emptyMap(),
    val contextualPromotionAllowed: Boolean = true,
)

enum class NativeWidgetKind { CLOCK, CALENDAR, WEATHER, BATTERY, CONNECTIVITY, MEDIA, CONTEXT, NEWS }

data class StackItem(
    val widgetKind: NativeWidgetKind,
    val allowAutomaticPromotion: Boolean = true,
)

data class SmartStackDefinition(
    val id: String,
    val name: String = "Smart Stack",
    val items: List<StackItem>,
    val smartRotationEnabled: Boolean = true,
    val autoLoopEnabled: Boolean = true,
)
