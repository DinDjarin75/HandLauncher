# BOAL Launcher validation — beta1.7

- Kotlin PSI syntax parse: 53 source files, zero syntax diagnostics before packaging.
- AndroidManifest.xml parsed successfully.
- Workspace Keep integration uses public AppWidgetManager binding/configuration APIs and the existing durable BOAL AppWidgetHost.
- Workspace ChatGPT API integration uses OpenAI Conversations + Responses endpoints with encrypted local key storage; network/API type validation remains part of GitHub Actions compilation/runtime testing.
- GitHub Actions remains the authoritative Android compiler/unit-test gate.
- Source manifest and ZIP integrity are regenerated for this release.


Date: 27 October 2026

Completed in the current runtime:
- Started from the CI-green beta1.5-fix2 source baseline.
- Added explicit Home downward routing zones: left 30% Notifications, center 40% Search, right 30% Quick Settings.
- Added minimal AccessibilityService bridge for Android GLOBAL_ACTION_NOTIFICATIONS and GLOBAL_ACTION_QUICK_SETTINGS; service metadata disables window-content retrieval.
- Added a Settings shortcut for one-time System shade gesture access setup and a first-gesture fallback to Android Accessibility settings.
- Added MAIN/HOME intent reset in MainActivity so Android's full-width bottom Home gesture returns Search and other transient surfaces to Home.
- Preserved swipe-up App Library behavior and existing Smart Stack gesture ownership.
- Beta1.6 version code/name verified (`26` / `1.0.0-beta1.6`).
- Android manifest/resource XML parsed successfully.
- Source manifest regenerated from the packaged beta1.6 tree.

Runtime note:
- Directly opening the system notification shade and Quick Settings is a privileged global action. BOAL implements it through an opt-in AccessibilityService with `canRetrieveWindowContent=false`; the user must enable BOAL System Gestures once in Android Accessibility settings.

Authoritative Android/Compose validation remains GitHub Actions: Java 17 + Android 36 + Gradle 9.6 -> unit tests -> `:app:assembleDebug` -> APK artifact.
