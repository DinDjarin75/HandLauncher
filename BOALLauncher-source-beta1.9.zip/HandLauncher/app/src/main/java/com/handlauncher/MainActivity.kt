package com.handlauncher

import android.Manifest
import android.app.ActivityOptions
import android.app.role.RoleManager
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.content.ContentUris
import android.content.Intent
import android.os.Bundle
import android.os.Build
import android.provider.Settings
import android.net.Uri
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.window.layout.WindowInfoTracker
import com.handlauncher.data.LauncherNotification
import com.handlauncher.platform.AndroidWidgetHostController
import com.handlauncher.platform.DisplayProfileDetector
import com.handlauncher.platform.LauncherGestureAccessibilityService
import com.handlauncher.ui.LauncherRoot
import com.handlauncher.ui.theme.BOALLauncherTheme
import com.handlauncher.ui.theme.resolveWallpaperDarkPalette
import kotlinx.coroutines.flow.collectLatest

class MainActivity : ComponentActivity() {
    private val viewModel: LauncherViewModel by viewModels()
    private lateinit var widgetHostController: AndroidWidgetHostController
    private var pendingWidgetId: Int? = null
    private var pendingWorkspaceKeepWidgetId: Int? = null

    private val calendarPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        viewModel.onCalendarPermissionResult()
    }

    private val createBackup = registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) runCatching {
            contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(viewModel.exportBackupJson()) }
        }
    }

    private val restoreBackup = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) runCatching {
            val raw = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: return@runCatching
            viewModel.importBackupJson(raw)
        }
    }

    private val configureWidget = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val fallback = pendingWidgetId ?: return@registerForActivityResult
        val id = AndroidWidgetHostController.widgetIdFromResult(result.data, fallback)
        if (AndroidWidgetHostController.resultSucceeded(result.resultCode)) viewModel.addAndroidWidget(id)
        else widgetHostController.deleteId(id)
        pendingWidgetId = null
    }

    private val pickWidget = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val fallback = pendingWidgetId ?: return@registerForActivityResult
        val id = AndroidWidgetHostController.widgetIdFromResult(result.data, fallback)
        if (!AndroidWidgetHostController.resultSucceeded(result.resultCode)) {
            widgetHostController.deleteId(id)
            pendingWidgetId = null
            return@registerForActivityResult
        }
        val configureIntent = widgetHostController.createConfigureIntent(id)
        if (configureIntent != null) configureWidget.launch(configureIntent)
        else {
            viewModel.addAndroidWidget(id)
            pendingWidgetId = null
        }
    }

    private val configureWorkspaceKeepWidget = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val id = pendingWorkspaceKeepWidgetId ?: return@registerForActivityResult
        if (AndroidWidgetHostController.resultSucceeded(result.resultCode)) commitWorkspaceKeepWidget(id)
        else {
            widgetHostController.deleteId(id)
            pendingWorkspaceKeepWidgetId = null
        }
    }

    private val bindWorkspaceKeepWidget = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val id = pendingWorkspaceKeepWidgetId ?: return@registerForActivityResult
        if (!AndroidWidgetHostController.resultSucceeded(result.resultCode)) {
            widgetHostController.deleteId(id)
            pendingWorkspaceKeepWidgetId = null
            return@registerForActivityResult
        }
        finishWorkspaceKeepWidgetSetup(id)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        hideLauncherStatusBar()
        widgetHostController = AndroidWidgetHostController(this)

        setContent {
            val state by viewModel.state.collectAsStateWithLifecycle()
            val detector = DisplayProfileDetector(this)

            LaunchedEffect(Unit) {
                viewModel.setProfile(detector.resolve(this@MainActivity))
                WindowInfoTracker.getOrCreate(this@MainActivity)
                    .windowLayoutInfo(this@MainActivity)
                    .collectLatest { info -> viewModel.setProfile(detector.resolve(this@MainActivity, info)) }
            }

            val darkTheme = resolveWallpaperDarkPalette(this@MainActivity, state.activeTheme?.dark ?: true)
            SideEffect {
                WindowCompat.getInsetsController(window, window.decorView).apply {
                    isAppearanceLightStatusBars = !darkTheme
                    isAppearanceLightNavigationBars = !darkTheme
                }
                hideLauncherStatusBar()
            }

            BOALLauncherTheme(theme = state.activeTheme) {
                LauncherRoot(
                    state = state,
                    viewModel = viewModel,
                    requestHomeRole = ::requestHomeRole,
                    isHomeRoleHeld = isHomeRoleHeld(),
                    widgetHostController = widgetHostController,
                    onAddAndroidWidget = ::beginWidgetPick,
                    onRemoveAndroidWidget = { id ->
                        widgetHostController.deleteId(id)
                        viewModel.removeAndroidWidget(id)
                    },
                    onRequestCalendarPermission = { calendarPermission.launch(Manifest.permission.READ_CALENDAR) },
                    onExportBackup = { createBackup.launch("boal-launcher-backup.json") },
                    onImportBackup = { restoreBackup.launch(arrayOf("application/json", "text/plain")) },
                    onOpenGoogleFeed = ::openGoogleFeed,
                    onOpenExternalUrl = ::openExternalUrl,
                    onOpenClock = ::openClock,
                    onOpenCalendar = ::openCalendarEvent,
                    onOpenCalendarApp = ::openCalendarApp,
                    onOpenWeather = ::openWeather,
                    onOpenBattery = ::openBattery,
                    onOpenMedia = ::openMedia,
                    onOpenMediaAccess = ::openMediaAccess,
                    onOpenNotification = ::openNotification,
                    onOpenNotificationShade = ::openNotificationShade,
                    onOpenQuickSettings = ::openQuickSettings,
                    onOpenSystemGestureAccess = ::openSystemGestureAccess,
                    onSetupWorkspaceKeep = ::beginWorkspaceKeepWidgetSetup,
                    onOpenKeep = ::openKeep,
                    onCreateKeepNote = ::createKeepNote,
                    onOpenChatGpt = ::openChatGpt,
                    onSendPromptToChatGpt = ::sendPromptToChatGpt,
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        hideLauncherStatusBar()
        // Keep categories/search current after installs, removals and app updates.
        viewModel.refreshApps()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        // Android's bottom-edge Home gesture re-delivers the launcher MAIN intent.
        // Reset transient launcher surfaces (Search, Library, Settings, etc.) to Home.
        if (intent.action == Intent.ACTION_MAIN) {
            viewModel.showHome()
        }
    }


    override fun onStart() {
        super.onStart()
        runCatching { widgetHostController.startListening() }
    }

    override fun onStop() {
        runCatching { widgetHostController.stopListening() }
        super.onStop()
    }

    @Suppress("DEPRECATION")
    private fun openNotification(notification: LauncherNotification) {
        val pendingIntent = notification.contentIntent ?: notification.fullScreenIntent

        if (pendingIntent != null) {
            val delivered = runCatching {
                if (Build.VERSION.SDK_INT >= 34) {
                    val options = ActivityOptions.makeBasic().apply {
                        pendingIntentBackgroundActivityStartMode =
                            if (Build.VERSION.SDK_INT >= 36) {
                                ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOW_IF_VISIBLE
                            } else {
                                ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED
                            }
                    }.toBundle()
                    pendingIntent.send(this, 0, null, null, null, null, options)
                } else {
                    pendingIntent.send()
                }
            }.isSuccess

            if (delivered) {
                viewModel.dismissNotification(notification.key)
                return
            }
        }

        // OEM/system notifications can omit contentIntent. Fall back to the source app.
        val launchIntent = packageManager.getLaunchIntentForPackage(notification.packageName)
            ?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (launchIntent != null && runCatching { startActivity(launchIntent) }.isSuccess) {
            viewModel.dismissNotification(notification.key)
        }
    }

    private fun hideLauncherStatusBar() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.statusBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    private fun openNotificationShade() {
        if (!LauncherGestureAccessibilityService.openNotifications()) {
            openSystemGestureAccess()
        }
    }

    private fun openQuickSettings() {
        if (!LauncherGestureAccessibilityService.openQuickSettings()) {
            openSystemGestureAccess()
        }
    }

    private fun openSystemGestureAccess() {
        runCatching { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
    }

    private fun beginWidgetPick() {
        val id = widgetHostController.allocateId()
        pendingWidgetId = id
        pickWidget.launch(widgetHostController.createSystemPickerIntent(id))
    }

    private fun beginWorkspaceKeepWidgetSetup() {
        val providers = widgetHostController.providersForPackage(KEEP_PACKAGE)
        val provider = providers.maxByOrNull { info ->
            val label = info.loadLabel(packageManager).toString().lowercase()
            when {
                "collection" in label -> 1000
                "notes" in label -> 700
                "single" in label -> 500
                "capture" in label -> 200
                else -> 100
            } + (info.minWidth + info.minHeight)
        } ?: run {
            openExternalUrl("https://play.google.com/store/apps/details?id=$KEEP_PACKAGE")
            return
        }
        val id = widgetHostController.allocateId()
        pendingWorkspaceKeepWidgetId = id
        if (widgetHostController.bindIfAllowed(id, provider)) {
            finishWorkspaceKeepWidgetSetup(id)
        } else {
            bindWorkspaceKeepWidget.launch(widgetHostController.createBindIntent(id, provider))
        }
    }

    private fun finishWorkspaceKeepWidgetSetup(id: Int) {
        val configureIntent = widgetHostController.createConfigureIntent(id)
        if (configureIntent != null) configureWorkspaceKeepWidget.launch(configureIntent)
        else commitWorkspaceKeepWidget(id)
    }

    private fun commitWorkspaceKeepWidget(id: Int) {
        val previous = viewModel.state.value.workspaceKeepWidgetId
        if (previous != null && previous != id) runCatching { widgetHostController.deleteId(previous) }
        viewModel.setWorkspaceKeepWidgetId(id)
        pendingWorkspaceKeepWidgetId = null
    }

    private fun openKeep() {
        packageManager.getLaunchIntentForPackage(KEEP_PACKAGE)?.let {
            if (safeStartActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))) return
        }
        openExternalUrl("https://keep.google.com/")
    }

    private fun createKeepNote() {
        val intent = Intent("com.google.android.gms.actions.CREATE_NOTE").apply {
            type = "text/plain"
            setPackage(KEEP_PACKAGE)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        if (!safeStartActivity(intent)) openKeep()
    }

    private fun openChatGpt() {
        packageManager.getLaunchIntentForPackage(CHATGPT_PACKAGE)?.let {
            if (safeStartActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))) return
        }
        openExternalUrl("https://chatgpt.com/")
    }

    private fun sendPromptToChatGpt(prompt: String) {
        val clean = prompt.trim()
        if (clean.isBlank()) {
            openChatGpt()
            return
        }
        val share = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            setPackage(CHATGPT_PACKAGE)
            putExtra(Intent.EXTRA_TEXT, clean)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        if (!safeStartActivity(share)) openChatGpt()
    }

    private fun isHomeRoleHeld(): Boolean {
        val manager = getSystemService(RoleManager::class.java)
        return manager.isRoleAvailable(RoleManager.ROLE_HOME) && manager.isRoleHeld(RoleManager.ROLE_HOME)
    }

    private fun requestHomeRole() {
        // Samsung/One UI is more reliable when the launcher opens Android's actual
        // default-Home picker instead of depending only on the ROLE_HOME dialog.
        val homeSettings = Intent(Settings.ACTION_HOME_SETTINGS)
        if (homeSettings.resolveActivity(packageManager) != null) {
            startActivity(homeSettings)
            return
        }

        val manager = getSystemService(RoleManager::class.java)
        if (manager.isRoleAvailable(RoleManager.ROLE_HOME) && !manager.isRoleHeld(RoleManager.ROLE_HOME)) {
            runCatching { startActivity(manager.createRequestRoleIntent(RoleManager.ROLE_HOME)) }
        }
    }

    private fun openGoogleFeed() {
        val launch = packageManager.getLaunchIntentForPackage("com.google.android.googlequicksearchbox")
        if (launch != null) startActivity(launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun safeStartActivity(intent: Intent): Boolean = runCatching {
        val resolved = intent.resolveActivity(packageManager) ?: return@runCatching false
        intent.component = resolved
        startActivity(intent)
        true
    }.getOrDefault(false)

    private fun openClock() {
        // Use Android's public alarm contract first. Some Samsung builds advertise
        // a packaged SHOW_ALARMS handler that is not safe to invoke directly.
        val alarms = Intent(AlarmClock.ACTION_SHOW_ALARMS)
            .addCategory(Intent.CATEGORY_DEFAULT)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (safeStartActivity(alarms)) return

        // If no app exposes SHOW_ALARMS, open the installed Clock app itself.
        listOf("com.sec.android.app.clockpackage", "com.google.android.deskclock").forEach { packageName ->
            packageManager.getLaunchIntentForPackage(packageName)?.let { launch ->
                if (safeStartActivity(launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))) return
            }
        }
    }

    private fun openCalendarApp() {
        val samsungCalendar = packageManager.getLaunchIntentForPackage("com.samsung.android.calendar")
        if (samsungCalendar != null && safeStartActivity(samsungCalendar.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))) return

        val generic = Intent(
            Intent.ACTION_VIEW,
            CalendarContract.CONTENT_URI.buildUpon()
                .appendPath("time")
                .appendPath(System.currentTimeMillis().toString())
                .build(),
        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        safeStartActivity(generic)
    }

    private fun openCalendarEvent() {
        val event = viewModel.state.value.nextCalendarEvent
        val intent = if (event != null) {
            Intent(Intent.ACTION_VIEW).apply {
                data = ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI, event.eventId)
                putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, event.beginMillis)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
        } else {
            Intent(
                Intent.ACTION_VIEW,
                CalendarContract.CONTENT_URI.buildUpon()
                    .appendPath("time")
                    .appendPath(System.currentTimeMillis().toString())
                    .build(),
            ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        if (!safeStartActivity(intent)) openCalendarApp()
    }

    private fun openWeather() {
        val samsungWeather = packageManager.getLaunchIntentForPackage("com.sec.android.daemonapp")
        if (samsungWeather != null) {
            runCatching { startActivity(samsungWeather.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }.onSuccess { return }
        }
        val label = viewModel.state.value.weather.location.label.ifBlank { "Luxembourg" }
        openExternalUrl("https://www.google.com/search?q=" + Uri.encode("weather $label"))
    }

    private fun openBattery() {
        val primary = Intent(Intent.ACTION_POWER_USAGE_SUMMARY)
            .setPackage("com.android.settings")
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (safeStartActivity(primary)) return

        val generic = Intent(Intent.ACTION_POWER_USAGE_SUMMARY).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (safeStartActivity(generic)) return

        safeStartActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun openMedia() {
        val media = viewModel.state.value.media
        if (media.needsAccess) {
            openMediaAccess()
            return
        }
        val packageName = media.packageName ?: return
        packageManager.getLaunchIntentForPackage(packageName)?.let { launch ->
            runCatching { startActivity(launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        }
    }

    private fun openMediaAccess() {
        runCatching { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
    }

    private fun openExternalUrl(url: String) {
        runCatching {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }


    companion object {
        private const val KEEP_PACKAGE = "com.google.android.keep"
        private const val CHATGPT_PACKAGE = "com.openai.chatgpt"
    }
}
