# Cleanup pass — 30 October 2026
- Search is now fully opaque black through the top display inset/cutout region.
- Replaced the default Quick Actions list with a five-app Recent Apps row. Android Usage Access provides system-wide recents when granted; BOAL launch history is the fallback.
- Energy Grid is now RingConn-first: Samsung Health is no longer read or displayed by the module, and the local Energy index is derived from RingConn sleep/activity only.
- RingConn sleep, steps, latest heart rate and SpO₂ are surfaced directly in the Workspace module.

## 1.0.0 — First public release

- Promoted the on-device validated 1.0.0-rc4 build to **BOAL Launcher 1.0.0** with no runtime or layout changes.
- Final Fold 8 landscape Home and Brief layouts use two stacked rectangular modules per physical half-screen, top-anchored for a consistent unfolded composition.
- Preserves the validated portrait/cover launcher, Smart Stack, contextual swipe gestures, App Library, notification handling, adaptive wallpaper accents, six-module Workspace carousel, Health Connect Energy Grid, Comms Radar and native Showly Ciné Club integration.
- Public CI now produces a non-debuggable release APK while reusing BOAL's stable signing identity so existing installations can update in place.
- Version code 42; version name 1.0.0.

## 1.0.0-rc3 — Inner Fold stacked-card polish

- Refined only the **INNER_FOLD + landscape** Home and Brief presentation.
- Home now uses two wide rectangular cards stacked vertically per physical half-screen: Clock over Calendar on the left, Weather over Battery on the right.
- Brief uses the same stacked rectangular pattern, top-anchored: Clock over Calendar on the left, Weather over Headlines on the right.
- Preserved all card data, click behavior, launcher gestures, portrait/cover layouts, Workspace inner landscape, wallpaper accents, notifications, Smart Stack and carousel behavior unchanged.

## 1.0.0-rc2 — Inner Fold horizontal release candidate

- Added a dedicated **INNER_FOLD + landscape** two-column composition for Brief, Home and Workspace; all portrait/cover behavior continues through the validated beta1.10-rc3 path unchanged.
- Brief centers Clock + Calendar on the left physical half and Weather + Headlines on the right physical half.
- Home places the first four permanent Smart Stack widgets directly at the top: Clock + Calendar on the left half, Weather + Battery on the right; Media is not duplicated on the unfolded landscape Home.
- Workspace centers System + vertically scrollable Comms Radar on the left half and compact Weather Atlas + full-width Ciné Club on the right; Energy Grid remains available in the portrait carousel but is intentionally absent from this landscape composition.
- Preserved launcher gestures, wallpaper accent recovery, notifications, portrait Workspace carousel, Showly integration and all other beta1.10-rc3 behavior.

## 1.0.0-beta1.10-rc3 — Workspace module fit-and-scroll polish

- Tightened **System** vertical spacing, ring sizing and metric-card density so Temperature/Uptime remain fully visible on the Fold cover display.
- Compacted **Weather Atlas** hero, hourly strip, metrics and three-day outlook so the full module fits without bottom clipping.
- Made **Comms Radar** vertically scrollable, removed the seven-app rendering cap and preserved horizontal module swipes for the carousel.
- Left **Ciné Club / Showly** integration unchanged after successful on-device validation.

## 1.0.0-beta1.10-rc1 — Workspace module carousel / Beta 2 portrait RC

- Replaced the lower Workspace Keep/ChatGPT stack with a full-height, manually swiped six-module BOAL carousel: **System, World Clock, Comms Radar, Weather Atlas, Energy Grid and Ciné Club**.
- Carousel is circular/infinite but never auto-rotates; the selected module persists across Workspace visits.
- Added a shared 30-minute refresh path via WorkManager for weather, Health Connect data and hosted Showly widgets, while World Clock and Comms Radar remain live from system time and notification state.
- World Clock is fixed to Luxembourg, Raleigh and Seoul with local date/day-night context.
- Comms Radar aggregates active alerts from supported communication apps (Gmail, Messenger, WhatsApp, Telegram, Messages, Discord, Signal, Instagram, Slack and Teams); tapping a row opens the latest notification PendingIntent or falls back to the app.
- Weather Atlas expands the existing weather source with hourly conditions, precipitation probability, humidity, wind, air quality and a compact multi-day outlook.
- Energy Grid reads source-attributed steps, sleep, heart rate and SpO₂ from Health Connect for Samsung Health and RingConn; BOAL's Energy index is explicitly a local sleep + activity visualization, not a medical score.
- Ciné Club hosts Showly's own Series and Movies Progress widgets inside BOAL glass so Showly's real content and PendingIntent interactions (details / watched actions) remain native.
- Added Health Connect permission rationale and background-read support, plus package visibility for Showly, health sources and supported communication apps.
- Preserved the Beta1.9.6 screenshot-based wallpaper accent recovery, Home gestures, Smart Stack pager behavior, App Library and Workspace connectivity row.

## 1.0.0-beta1.9.6 — Accessibility screenshot accent recovery

- Replaced the non-viable direct wallpaper-bitmap refresh path with a user-triggered AccessibilityService screenshot of BOAL Home.
- `Refresh from wallpaper` now briefly returns to Home, samples wallpaper-heavy screen regions, derives a dominant chromatic accent, applies it directly to BOAL's live palette state, then reopens Settings.
- Added `canTakeScreenshot` capability to the existing BOAL system-gesture accessibility service; captures occur only after the explicit Accent refresh tap and the bitmap is discarded immediately after sampling.
- Manual sampled accent remains authoritative for the running process so stale OEM `WallpaperColors` callbacks cannot overwrite the recovered palette.
- Automatic wallpaper listener behavior and all launcher interaction surfaces remain otherwise unchanged.

## 1.0.0-beta1.9.5 — True wallpaper accent resampling

- Fixed manual Accent refresh on OEM builds that return stale cached `WallpaperColors`.
- `Refresh from wallpaper` now samples the actual current wallpaper drawable and derives a usable dominant chromatic hue directly from its pixels.
- Low-chroma, near-black and near-white regions are filtered so illustrated wallpapers can contribute their meaningful accent color.
- Automatic wallpaper listener behavior remains unchanged; manual refresh is an isolated recovery path.

# BOAL Launcher changelog

## 1.0.0-beta1.9.4 — 2026-10-27
- Added **Refresh from wallpaper** to Settings → Appearance so users can force a fresh adaptive accent read after changing wallpaper.
- The refresh stays inside the existing wallpaper theme pipeline: it rereads system wallpaper colors, rebuilds the BOAL accent palette and reevaluates wallpaper contrast without restarting the launcher.
- Automatic wallpaper color listening remains unchanged to avoid destabilizing the Beta 2 candidate.

## 1.0.0-beta1.9.3 — Workspace connectivity controls
- Replaced the Workspace AI Design / Automations / Settings action row with four control-center-style connectivity buttons: Mobile data, Bluetooth, Wi-Fi and Hotspot.
- Buttons use the existing Workspace glass/action visual language, with adaptive-accent active states and live On/Off/network/device details.
- Added native connectivity state reads for Wi-Fi and mobile-data enablement plus Android 16+ tethered-interface tracking for Wi-Fi hotspot state.
- Reused BOAL's existing system-gesture AccessibilityService as a SystemUI-only Quick Settings bridge for explicit user-tapped connectivity toggles; the service is restricted to com.android.systemui and closes Quick Settings after a successful tile action.
- Increased connectivity-state refresh cadence for faster visual feedback after toggles.
- Preserved Beta1.9.2 synchronized App Library rail, sorting, contextual app actions, Workspace Keep/ChatGPT modules and all Home gestures.

## 1.0.0-beta1.9.2 — synchronized category rail
- Coupled the compact App Library category rail directly to the HorizontalPager's live fractional page position so the rail follows the user's finger during category swipes instead of updating only after settlement.
- Interpolated active-category accent treatment between outgoing and incoming category chips during the swipe for a continuous visual handoff.
- Automatically keeps the active category near the center of the rail when space allows, while naturally clamping at the first and last categories.
- Tapping a category still drives the same pager, keeping rail and content navigation bidirectionally synchronized.
- Preserved Beta1.9.1 overview dismissal, glass opacity/canvas treatment, auto-sort/manual overrides, search, contextual app actions and Beta1.8 Home gesture behavior.

## 1.0.0-beta1.9.1 — App Library cohesion pass
- Added swipe-up dismissal to the category overview while preserving the visible close control; if custom categories overflow the screen, the overview scrolls normally and the upward close gesture becomes available at the end of the grid.
- Increased App Library glass-container opacity by roughly 12 percentage points for stronger readability over detailed wallpapers.
- Unified compact category navigation into one continuous adaptive-glass strip; unselected categories no longer render as disconnected outlined pills.
- Wrapped each compact category app grid in a bounded adaptive-glass canvas using the same radius, outline and opacity language as the category overview.
- Moved the app-count hierarchy into the category canvas and kept the canvas height content-aware so short categories still leave wallpaper visible while large categories scroll internally.
- Added a subtle adaptive-accent state to the previously selected category on the overview, strengthening visual continuity from overview to category detail.
- Preserved Beta1.9 auto-sorting, manual overrides, horizontal category swiping, search, long-press contextual actions, Add to Home and native App info/uninstall flows.

## 1.0.0-beta1.9 — App Library redesign + app contextual actions
- Rebuilt the category-first App Library around the approved adaptive-glass design while preserving BOAL auto-sorting and direct horizontal category swiping.
- Added a category overview with live app counts, adaptive category iconography and direct category entry.
- Added in-library search across app labels, tags and category names.
- Added responsive layouts: compact cover-screen category overview/pager and unfolded/external two-pane category rail + swipeable app pane.
- Added long-press app contextual actions in BOAL glass chrome: App info, Move category, Add to Home and Uninstall for removable apps.
- App info routes to Android package details; uninstall uses Android's confirmation flow and system apps do not expose a false uninstall action.
- Manual Move category continues to persist above automatic categorization; Add to Home reuses BOAL's existing smart-object placement engine.
- Redesigned category editing with adaptive-glass controls, category reordering, rename/transparency controls and direct app assignment.
- Preserved Beta1.8 Home gesture arbitration, Smart Stack ownership, Workspace, notification handling and persistent signing identity.

## 1.0.0-beta1.8 — horizontal page gesture arbitration
- Reworked Home gesture arbitration so horizontal swipes yield immediately to the Brief / Home / Workspace pager instead of being stolen by small diagonal vertical drift.
- Added explicit 1.2× directional dominance after touch slop: clear horizontal intent belongs to page navigation, clear vertical intent belongs to Search / App Library / notification shade / Quick Settings, and ambiguous diagonals keep tracking until intent is clear.
- Expanded the practical page-swipe territory across the Home surface while preserving Smart Stack horizontal ownership and existing interactive child controls.
- Preserved Beta1.7 Workspace, Keep, ChatGPT, notification, adaptive-accent and stable-signing behavior.

## 1.0.0-beta1.7 — Workspace redesign + Keep/ChatGPT modules
- Rebuilt the right-side Workspace page to the validated premium adaptive-glass design: richer At a glance metrics, balanced action controls, vertically scrollable modular layout, and consistent wallpaper-derived accent treatment.
- Added a dedicated Google Keep Workspace module backed by Keep's real Android AppWidget. BOAL persists a separate Workspace widget ID, supports widget binding/configuration, interactive Keep checklist behavior, open-in-Keep and one-tap new-note creation.
- Added a native BOAL ChatGPT conversation module with persisted local transcript, inline composer, loading/error state, encrypted on-device OpenAI API-key storage and a persistent OpenAI Conversations API thread.
- Inline ChatGPT uses GPT-5.6 Sol through the Responses API. The BOAL thread is intentionally separate from consumer ChatGPT account history because the ChatGPT Android app does not expose third-party conversation-history embedding.
- Without an API key, the ChatGPT composer hands the prompt to the official ChatGPT Android app when available, with chatgpt.com as a fallback.
- Added package visibility for Google Keep and the official ChatGPT Android app.
- Preserved Beta1.6 gesture routing, Smart Stack behavior, notification resilience and persistent CI signing identity.

## 1.0.0-beta1.6 — system gesture routing
- Home swipe-down is now an explicit three-zone gesture: left 30% opens the full notification shade, center 40% opens BOAL Search, and right 30% opens full Quick Settings.
- Left/right system-panel actions fire as soon as the downward gesture crosses the intent threshold instead of waiting for finger-up.
- Added a minimal BOAL System Gestures AccessibilityService using Android global actions; it does not retrieve window content or inspect accessibility events.
- If system-gesture access is not enabled, the first left/right gesture routes to Android Accessibility settings; Settings > Launcher also exposes a System shade gestures shortcut.
- Android HOME intents now reset transient launcher surfaces to Home, so the device's full-width bottom Home swipe exits BOAL Search even while the keyboard is open.
- Preserved center Search, global swipe-up App Library, Smart Stack navigation, notification behavior, adaptive accent and the stable CI signing identity.

## 1.0.0-beta1.5-fix2 — notification access resilience
- Added explicit notification-listener access state to launcher UI state.
- Home now shows a glass notification-access recovery card instead of silently rendering no notifications when Android revokes/disconnects listener access.
- Added one-tap route back to Android's Notification Listener settings.
- Added listener rebind recovery when permission exists but Android has left the service disconnected.
- Fixed notification opening for Android 14-16: notification PendingIntents now execute from the visible launcher Activity with the required background-activity-start mode, rather than from the NotificationListenerService.
- The full notification row is now the open target while the dedicated × remains the independent dismiss action; successful opens dismiss the mirrored Home notification to match normal shade behavior.
- CI now persists one BOAL debug signing key in GitHub Actions cache so future beta APKs update in place and retain privileged grants.
- No Smart Stack, widget, media, connectivity or gesture behavior changed from beta1.5-fix1.

# Changelog

## 1.0.0-beta1.5-fix1
- Fixed missing Compose `detectVerticalDragGestures` import caught by GitHub Actions.
- No behavior changes from beta1.5.

## 1.0.0-beta1.5

- Fixed notification interaction by giving the notification body its own explicit tap target and adding robust PendingIntent/source-app fallback opening while preserving the dedicated dismiss control.
- Connectivity now scopes telephony reads to Android's default data subscription so dual-SIM devices report the registered cellular generation instead of falling back to a generic Mobile label.
- Cellular generation labels and signal state use the adaptive wallpaper accent.
- Removed the redundant numeric battery percentage from inside the charge gauge; the gauge now keeps the battery-state glyph while the main percentage remains the single numeric readout.
- Reverted Home utility controls to one widget-matched glass capsule with plain white icons and no nested circular containers.
- Downward Search is now claimed only from the center 40% of Home. Downward gestures from the outer 30% on either side remain unconsumed for system notification/control-center gestures; swipe-up App Library remains available across Home.

## 1.0.0-beta1.4

- Added Wallpaper Adaptive Accent as a launcher-wide visual feature. BOAL listens for system-wallpaper color changes, prefers the wallpaper primary color when usable, falls back to stronger supporting colors for neutral primaries, and normalizes extreme tones for UI contrast.
- Adaptive accent now drives glass outlines, progress gauges, media progress, active controls, connectivity signal state, notification chrome and Home utility controls while neutral glass surfaces remain wallpaper-independent.
- Added a visible Adaptive Accent status/swatch to Settings > Appearance.
- Redesigned the Clock card with a day-progress gauge, next-alarm status and stronger information hierarchy.
- Redesigned the Battery card with an adaptive circular charge gauge, connected-device line and clearer charging/on-battery state.
- Redesigned the contextual Media card with larger artwork, refined transport controls, output-device indicator, elapsed/total duration and a functional seek scrubber.
- Media session state now includes duration, estimated live playback position and seek capability; BOAL forwards scrubber changes to Android media-session seekTo().
- Refined the notification capsule and Home control capsule to match the adaptive glass design language.
- Preserved beta1.3 Smart Stack behavior: five permanent cards, contextual Media as an optional sixth card, manual looping only, and remembered selection during an active media session.

## 1.0.0-beta1.3

- Rebuilt Smart Stack navigation on a nested Compose HorizontalPager instead of manual drag-threshold state.
- Default stack always exposes all five permanent cards: Clock, Calendar, Weather, Battery, Connectivity.
- Added true manual circular wraparound using duplicate edge pages; there is still no timed auto-advance.
- The Smart Stack now owns horizontal gestures inside its bounds so Home/Brief paging cannot steal an in-stack swipe.
- Active Media is an optional sixth page. It may promote once when a new media session begins.
- The selected card is remembered for the lifetime of an active media session, so Brief -> Home returns to the card the user actually left selected.

## 1.0.0-beta1.2

- Fixed Smart Stack media re-promotion after leaving Home for Brief and returning.
- Media may promote once per active media session; manual swipe choice then remains authoritative.
- Restored a canonical default permanent stack: Clock, Calendar, Weather, Battery, Connectivity.
- Preserved manual circular swipe looping with no timed auto-advance.


## 1.0.0-beta1.1 — BOAL Launcher

- Fixed Fold cover placement by reading the physical top display-cutout bounding rectangle instead of relying on the fullscreen Compose inset; BOAL now applies the cutout rule to both COVER and PHONE_PORTRAIT profiles so Samsung profile classification cannot bypass it.
- Smart Stack is a manual circular loop again: swipe past the last card to return to the first, and vice versa. There is no timer-based or automatic cycling of permanent widgets.
- Active Media now joins the same circular loop as an extra card. It may promote once when a playback session starts, but manual swipes win after that; the Media card remains available until playback ends.
- When playback ends while Media is selected, the Stack returns to the remembered permanent card.
- Strengthened notification filtering for Samsung media surfaces by excluding transport/media-session notifications and the Samsung `MediaOngoingActivity` entry in addition to ongoing/no-clear/foreground flags.

## 1.0.0-beta1 — BOAL Launcher

- Renamed the consumer product from Hand Launcher to **BOAL Launcher** (Best Of All Launchers) and promoted the project to its first beta.
- Added a new adaptive BOAL launcher icon and updated app-facing labels, backup naming and project identity.
- Kept the existing Android application ID internally so beta1 installs over alpha07 without wiping launcher data, layouts or permissions.
- Cover-screen Smart Stack now starts immediately below the actual display cutout with a 0.5 physical-pixel gap, avoiding the hole-punch camera.
- Removed automatic Smart Stack cycling. Permanent cards move only by manual horizontal swipe.
- Media is now the only automatic Smart Stack context: active playback pins the Media card until playback ends, then returns to the remembered permanent card.
- Expanded weather data to five forecast days.
- Weather Smart Stack card now uses its lower space for a compact five-day forecast strip with native condition graphics and high/low temperatures.
- Brief weather forecast expanded to five days for consistency with the Stack.
- Carries forward alpha07 notification capsule, dismiss controls, icon-pack engine, Connectivity widget and fullscreen launcher behavior.

## 1.0.0-alpha07

- Smart Stack media promotion is session-aware: a new media session may surface the player once, but a manual swipe back to Clock/permanent content wins until that session ends.
- Clock remains the default permanent Smart Stack position when no saved position exists.
- Added an on-demand glass notification capsule below the Smart Stack controls; it is not composed at all when there are no eligible notifications.
- Notification capsule excludes ongoing, foreground-service, no-clear, group-summary and launcher-owned persistent notifications.
- Shows the latest two notifications at normal height and scrolls vertically when more are available.
- Each notification uses the app icon, notification text and a dedicated × dismiss action; tapping the row opens the notification destination.
- Added a shared icon-pack resolver with standard appfilter.xml support and automatic fallback to original app icons.
- Added Settings icon-pack selection for installed compatible APK packs, including Icon Pack Studio-style exports.
- Selected icon packs now flow through Home, App Library, Search, editors and notification icons via one launcher-wide icon pipeline.
- Renamed notification-listener permission entry to Notifications & media access because the same Android permission powers both contextual media and the notification capsule.
- Home now hides the Android status bar and uses the reclaimed vertical space for a taller Smart Stack surface.
- Added a permanent Connectivity Smart Stack card immediately before contextual Media: Wi-Fi name/speed, mobile network generation/operator/signal bars, and connected Bluetooth audio devices.
- Connectivity is a required Smart Stack item and is migrated into existing saved default stacks.

## 1.0.0-alpha06.1

- Hotfix external widget destinations so Clock and Calendar event taps cannot crash the launcher.
- Restore the generic Android SHOW_ALARMS contract with safe Clock-app fallback.
- Restore the alpha05 calendar-event launch behavior with guarded Calendar fallback.
- Replace Google News wrapper feeds with merged direct publisher RSS feeds that expose article imagery.
- Prefer image-bearing stories while preserving recency and resolve missing images from publisher OpenGraph/content.

## 1.0.0-alpha06

- Anchored the default Smart Stack directly below the status-bar safe area on Home.
- Consolidated Automations, Settings, Edit and AI controls into one widget-matched glass capsule positioned below the Smart Stack at the right edge.
- Persisted the last viewed permanent Smart Stack widget per display profile and stack, including across launcher restarts.
- Removed Smart Stack page/navigation indicators.
- Corrected Clock navigation to prefer the device alarm list (including Samsung Clock) instead of Date & Time settings.
- Corrected Battery navigation to open the top-level Battery settings screen rather than Battery Saver.
- Split Calendar interactions: the CALENDAR header opens the Calendar app while the event row opens that exact event.
- Added shared native weather graphics to the Smart Stack weather widget and Brief current/forecast weather surfaces.

## 1.0.0-alpha05

- Added direct left/right paging between App Library categories with synchronized category chips.
- Smart Stack auto-loop is decoupled from generic context rules; Clock, Weather and Battery are permanent core widgets.
- Added contextual media player for active music/podcast sessions, including artwork, metadata, play/pause, previous/next and app launch.
- Made native Smart Stack widgets actionable: Clock opens alarms, Calendar opens the relevant event/day, Weather opens weather, Battery opens battery settings.
- Added whole-Brief automatic refresh every 30 minutes and manual full-page refresh.
- Added collapsible Headlines, Entertainment, Tech and LEGO sections, each with five latest stories and identical glass/card treatment.
- Improved article-image resolution and image loading fallbacks while preserving the 20/80 image/text card layout.
- Removed workshop/technical labels from everyday UI and migrated legacy auto-seeded Home app objects away.

## 1.0.0-alpha04

- Unified Brief modules and native widgets on the same translucent glass surface.
- Finished high-contrast foreground treatment for wallpaper-facing launcher UI and native widget content.
- Removed arbitrary installed-app population from a fresh Home; users add apps intentionally.
- Added 20/80 image/text headline cards with lead-image discovery from feed media and article OpenGraph/Twitter metadata.
- Humanized calendar timing (for example, Tomorrow · 15:35 instead of large minute counts).

## 1.0.0-alpha03 — Contrast + Briefing
- Adaptive wallpaper readability now samples the upper wallpaper instead of relying only on global wallpaper hints.
- Direct app labels keep an opposite-color shadow for readability across mixed bright/dark wallpaper regions.
- Smart Stacks now navigate horizontally: swipe left for next, swipe right for previous.
- Smart Stacks wrap continuously at both ends and support automatic looping; contextual promotion temporarily pauses looping without losing the user's position.
- Stack editor exposes the auto-loop toggle and horizontal ordering controls.
- Left page rebuilt as a personal briefing surface with greeting, current weather, four-day forecast, phone battery, next Calendar event, contextual suggestions and live headlines.
- Headline feed uses a Luxembourg-localized RSS provider with no API key and keeps Google Discover as an optional shortcut.

## 1.0.0-alpha02 — UX refinement
- Smoother, density-aware vertical gestures with resisted motion feedback.
- Swipe down from the top of an App Library category returns Home.
- Per-category background transparency slider and Solid/Tinted/Glass/Clear presets.
- Wallpaper-first theming: AI transparency styles cards/widgets instead of veiling the wallpaper.
- Native Hand Feed replaces the Google Discover placeholder while retaining a Discover shortcut.
- More reliable Samsung/Android default-Home selector.
- Reduced persistent help/tutorial text on primary launcher surfaces.

## 1.0.0-alpha01 — 2026-10-25
- Consolidated the launcher into one declarative, per-display-profile architecture.
- Added real Android HOME registration, app discovery and Home-role request.
- Added swipe-down Search/Command Layer and swipe-up categorized App Library.
- Added Android-category-aware automatic classification plus persisted user overrides.
- Added free-form Home editing, drag/resize, fine positioning, grid snapping and layout locking.
- Added Smart Object tap/swipe/long-press execution and editing.
- Added Home object palette for apps, Hand widgets, Android widgets, Smart Stacks, categories and commands.
- Added real `AppWidgetHost` placement/configuration/removal on the Home canvas.
- Added editable native Clock, Calendar, Weather and Battery widgets.
- Added multi-instance editable Smart Stacks with naming, reorder and contextual promotion rules.
- Added Jetpack Window fold/posture handling and independent external-display desktop layouts.
- Added user-editable Context Automation rules for battery, charging, time, display, audio device, Calendar and rain.
- Added actionable contextual command suggestions.
- Added Open-Meteo weather provider using a manual coarse location.
- Added local AI layout designer plus optional Gemini-backed constrained design generation.
- Added AI theme rendering for light/dark, transparency, corners and typography mood.
- Added Android-Keystore encryption for the optional Gemini key.
- Added JSON backup/restore including weather configuration while excluding AI credentials.
- Added current Android build configuration, JUnit core tests and a GitHub Actions APK build workflow.
- Added gesture arbitration so Home search/library swipes do not steal Smart Object gestures.

## Earlier development snapshots
0.1–0.3 established the initial launcher shell, persistence, AppWidget hosting, Fold profiles, Smart Objects and free-form editor. Those snapshots were folded into the 1.0 alpha source milestone above.
