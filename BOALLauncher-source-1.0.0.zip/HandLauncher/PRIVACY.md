# BOAL Launcher privacy notes

BOAL is primarily a local launcher. This document summarizes the permissions and network-facing features visible in the 1.0.0 source. The source code and `AndroidManifest.xml` remain authoritative.

## Local data

Launcher layouts, categories, Smart Stacks, preferences and most context state are stored locally on the device. BOAL's JSON backup excludes AI credentials.

## Optional sensitive access

### Notification access
Used for notification/media surfaces and Comms Radar. Android requires the user to grant Notification Listener access explicitly.

### Accessibility service
Used for BOAL's system notification-shade and Quick Settings gesture actions. The service is opt-in and restricted by package name to Android SystemUI. BOAL inspects that tree only while carrying out an explicit Quick Settings toggle.

### Calendar
`READ_CALENDAR` is used for Calendar/Brief/context features when the user grants access.

### Health Connect
BOAL can request read access to steps, sleep, heart rate and oxygen saturation, including background health reads, for the Energy Grid module. Energy Grid filters these records to RingConn as its source. These permissions are granted through Android Health Connect.

### Usage access
Optional Android Usage Access is used only to rank the five most recently used launchable apps shown on the Search screen. If Usage Access is not granted, BOAL uses only its own local launch history as a fallback.

## Network access

BOAL declares `INTERNET`, `ACCESS_NETWORK_STATE` and `ACCESS_WIFI_STATE`.

The 1.0.0 source contains network integrations for:

- Open-Meteo weather and air-quality APIs.
- Public RSS/news feeds.
- Optional Google Gemini requests when the user configures a Gemini API key.
- Optional OpenAI Conversations/Responses requests when the user configures an OpenAI API key for Workspace chat.

No advertising or analytics SDK is declared in the 1.0.0 Gradle dependency list.

## API keys

Optional AI keys are user-supplied. BOAL stores them locally using Android Keystore-backed encryption and excludes them from launcher backups.
