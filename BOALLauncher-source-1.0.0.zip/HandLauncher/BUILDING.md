# Building BOAL Launcher

## Android Studio

1. Clone the repository.
2. Open the repository root as a Gradle project in a current Android Studio release.
3. Use JDK 17.
4. Install Android SDK 36 / Build Tools 36.0.0 if Android Studio asks for them.
5. Run the unit tests with `:app:testDebugUnitTest`.
6. Build a debug APK with `:app:assembleDebug` or a release APK with `:app:assembleRelease`.

Debug output: `app/build/outputs/apk/debug/app-debug.apk`

Release output: `app/build/outputs/apk/release/app-release.apk`

## GitHub Actions

`.github/workflows/build.yml` is the authoritative public CI path. It uses Java 17, Android SDK 36 and Gradle 9.6, runs the unit tests, assembles the release APK and publishes the APK plus its SHA-256 checksum as a workflow artifact.

Tag builds, or a manual workflow run with a release tag supplied, can attach those same files to GitHub Releases.

## Signing note

BOAL 1.0.0 was shipped using the project's stable prototype signing identity so it can update over earlier BOAL test builds. The release APK is non-debuggable. Signing identity continuity matters for Android updates, so do not replace the key casually in later releases.

## First launch

Install the APK, open BOAL Launcher once, then use **BOAL settings > Set BOAL as Home**. Android will show the system Home-app chooser/role request.
