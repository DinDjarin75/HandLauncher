# Security

## Installing BOAL

Use the APK attached to an official GitHub Release. Do not install copies from third-party mirrors unless you independently verify them.

Verify the APK with the SHA-256 value in `RELEASE_CHECKSUMS.sha256`.

On Linux/macOS:

```sh
sha256sum BOAL-Launcher-1.0.0.apk
```

On Windows PowerShell:

```powershell
Get-FileHash .\BOAL-Launcher-1.0.0.apk -Algorithm SHA256
```

## Review the permissions

Before granting Notification Listener, Accessibility, Calendar or Health Connect access, review `app/src/main/AndroidManifest.xml` and the relevant implementation under `app/src/main/java/com/handlauncher/`.

## Reporting a security issue

For non-sensitive bugs, use the repository issue tracker. Do not post API keys, personal data or exploit details publicly. For a sensitive security report, contact the repository owner privately before publishing details.
