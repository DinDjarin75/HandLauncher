# BOAL Launcher

**BOAL** is a fold-first Android HOME launcher built for people who want their launcher to adapt to the device without taking control away from them. Version **1.0.0** was built and validated on a Galaxy Z Fold 8.

## Why this repository is public

The full Android source is checked into this repository as normal Kotlin, XML and Gradle files so anyone can inspect the code, permissions and build configuration directly on GitHub. Release APKs should be downloaded from **GitHub Releases**, not from random mirrors or repository ZIP snapshots.

For every public APK, BOAL publishes a SHA-256 checksum. See [`RELEASE_CHECKSUMS.sha256`](RELEASE_CHECKSUMS.sha256).

## What BOAL does

- Independent cover, unfolded Fold, portrait, landscape and external-display layouts.
- Swipe-down Search / Command Layer and swipe-up category-first App Library.
- Native BOAL widgets plus real Android widgets on the same canvas.
- Smart Stacks with manual looping and contextual promotion that does not rewrite saved order.
- Native Brief page with weather, Calendar, context and headlines.
- Workspace modules including System, World Clock, Comms Radar, Weather Atlas, Energy Grid and Ciné Club.
- Optional Health Connect integration for Energy Grid.
- Optional Gemini-backed layout/theme generation and optional OpenAI-backed Workspace chat; both require the user's own API key.
- JSON backup/restore; AI credentials are excluded from backups.

## Sensitive permissions

BOAL is a launcher, so some optional features use Android permissions that deserve scrutiny:

- **Notification access** powers Comms Radar and media/notification surfaces.
- **Accessibility service** is used for system notification-shade / Quick Settings gesture actions that ordinary launcher apps cannot invoke directly. Its event scope is restricted to Android SystemUI, where BOAL may inspect the Quick Settings tree only after an explicit toggle request.
- **Calendar** access is used by the Brief and context features.
- **Health Connect** reads selected RingConn health metrics for Energy Grid when enabled.
- **Usage access** is optional and powers the five system-wide recent apps shown in Search; without it, BOAL falls back to its own launch history.
- **Internet / network state** are used for weather, RSS/news and optional AI providers.

See [`PRIVACY.md`](PRIVACY.md) and the actual [`AndroidManifest.xml`](app/src/main/AndroidManifest.xml) for the authoritative list.

## Build it yourself

See [`BUILDING.md`](BUILDING.md). The project uses JDK 17, Android SDK 36, AGP 9.4 and Gradle 9.6 in CI. GitHub Actions runs unit tests and builds the release APK from the checked-in source.

## Release status

Current public release: **BOAL Launcher 1.0.0** (`versionCode 42`, `versionName 1.0.0`).

See [`CHANGELOG.md`](CHANGELOG.md), [`PROJECT_STATUS.md`](PROJECT_STATUS.md), [`ARCHITECTURE.md`](ARCHITECTURE.md) and [`VALIDATION.md`](VALIDATION.md) for the development history and implementation notes.
