package com.handlauncher.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.handlauncher.domain.AppEntry
import com.handlauncher.ui.components.AppIcon

private data class LauncherCommand(
    val title: String,
    val command: String,
    val aliases: Set<String>,
    val icon: ImageVector,
)

private val launcherCommands = listOf(
    LauncherCommand("All apps", "apps", setOf("apps", "library", "drawer", "categories"), Icons.Rounded.Apps),
    LauncherCommand("AI design", "ai", setOf("ai", "design", "layout", "theme"), Icons.Rounded.AutoAwesome),
    LauncherCommand("Automations", "automations", setOf("automation", "automations", "context", "rules"), Icons.Rounded.Bolt),
    LauncherCommand("Add to Home", "add", setOf("add", "widget", "object", "shortcut"), Icons.Rounded.AddCircleOutline),
    LauncherCommand("Settings", "settings", setOf("settings", "preferences", "configure"), Icons.Rounded.Settings),
)

@Composable
fun SearchScreen(
    query: String,
    results: List<AppEntry>,
    recentApps: List<AppEntry>,
    usageAccessGranted: Boolean,
    onQueryChange: (String) -> Unit,
    onLaunch: (AppEntry) -> Unit,
    onCommand: (String) -> Unit,
    onRequestUsageAccess: () -> Unit,
    onDismiss: () -> Unit,
) {
    BackHandler(onBack = onDismiss)
    val focusRequester = remember { FocusRequester() }
    val keyboard = LocalSoftwareKeyboardController.current
    val normalized = query.trim().lowercase()
    val commands = remember(normalized) {
        if (normalized.isBlank()) emptyList()
        else launcherCommands.filter { command ->
            command.title.lowercase().contains(normalized) || command.aliases.any { it.contains(normalized) }
        }
    }

    LaunchedEffect(Unit) {
        focusRequester.requestFocus()
        keyboard?.show()
    }

    // Search is intentionally an opaque surface. The wallpaper should never peek through
    // the hidden status-bar / cutout region at the very top of the display.
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black),
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .padding(horizontal = 18.dp, vertical = 14.dp)
        ) {
            OutlinedTextField(
                value = query,
                onValueChange = onQueryChange,
                leadingIcon = { Icon(Icons.Rounded.Search, null) },
                trailingIcon = {
                    if (query.isNotBlank()) IconButton(onClick = { onQueryChange("") }) { Icon(Icons.Rounded.Close, "Clear") }
                },
                placeholder = { Text("Search apps, tags, categories, commands…") },
                singleLine = true,
                shape = RoundedCornerShape(26.dp),
                modifier = Modifier.fillMaxWidth().focusRequester(focusRequester),
            )
            Spacer(Modifier.height(14.dp))

            LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                if (normalized.isBlank()) {
                    item {
                        Text(
                            "RECENT APPS",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(vertical = 6.dp),
                        )
                    }
                    item {
                        if (recentApps.isNotEmpty()) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                                verticalAlignment = Alignment.Top,
                            ) {
                                recentApps.take(5).forEach { app ->
                                    AppIcon(
                                        app = app,
                                        onClick = { onLaunch(app) },
                                        compact = true,
                                        modifier = Modifier.weight(1f),
                                    )
                                }
                                repeat((5 - recentApps.take(5).size).coerceAtLeast(0)) {
                                    Spacer(Modifier.weight(1f))
                                }
                            }
                        } else {
                            Column(
                                modifier = Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 8.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(4.dp),
                            ) {
                                Text("Recent apps will appear here", style = MaterialTheme.typography.bodyMedium)
                                Text(
                                    if (usageAccessGranted) "Open a few apps and BOAL will keep the latest five here."
                                    else "Enable usage access for system-wide recents, or BOAL will learn from apps launched here.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                                if (!usageAccessGranted) {
                                    TextButton(onClick = onRequestUsageAccess) { Text("Enable usage access") }
                                }
                            }
                        }
                    }
                } else {
                    if (commands.isNotEmpty()) {
                        item {
                            Text(
                                "COMMANDS",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(vertical = 6.dp),
                            )
                        }
                        items(commands, key = { "command_${it.command}" }) { command ->
                            ListItem(
                                headlineContent = { Text(command.title) },
                                supportingContent = { Text(command.command) },
                                leadingContent = { Icon(command.icon, null) },
                                modifier = Modifier.fillMaxWidth(),
                                trailingContent = { TextButton(onClick = { onCommand(command.command) }) { Text("Run") } },
                            )
                            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = .35f))
                        }
                    }

                    if (results.isNotEmpty()) {
                        item {
                            Text(
                                "APP RESULTS",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(top = 12.dp, bottom = 6.dp),
                            )
                        }
                        items(results, key = { it.stableId }) { app ->
                            ListItem(
                                headlineContent = { Text(app.label, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                                supportingContent = {
                                    Text(app.tags.joinToString(" · "), maxLines = 1, overflow = TextOverflow.Ellipsis)
                                },
                                leadingContent = {
                                    AppIcon(app, onClick = { onLaunch(app) }, compact = true, modifier = Modifier.width(58.dp))
                                },
                                trailingContent = {
                                    TextButton(onClick = { onLaunch(app) }) { Text("Open") }
                                },
                                modifier = Modifier.fillMaxWidth(),
                            )
                        }
                    } else if (commands.isEmpty()) {
                        item {
                            Box(Modifier.fillParentMaxWidth().padding(top = 52.dp), contentAlignment = Alignment.Center) {
                                Text("No local match", color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        }
    }
}
