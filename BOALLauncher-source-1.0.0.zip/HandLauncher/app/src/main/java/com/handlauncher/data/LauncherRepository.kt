package com.handlauncher.data

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.LauncherApps
import android.net.Uri
import android.os.Process
import android.provider.Settings
import com.handlauncher.domain.AppEntry

class LauncherRepository(private val context: Context) {
    private val launcherApps = context.getSystemService(LauncherApps::class.java)
    private val usageStats = context.getSystemService(UsageStatsManager::class.java)
    private val prefs = context.getSharedPreferences("boal_recent_apps", Context.MODE_PRIVATE)

    fun loadLaunchableApps(): List<AppEntry> {
        val profile = Process.myUserHandle()
        return launcherApps.getActivityList(null, profile)
            .asSequence()
            .filterNot { it.applicationInfo.packageName == context.packageName }
            .map { info ->
                val packageName = info.applicationInfo.packageName
                val label = info.label?.toString().orEmpty().ifBlank { packageName }
                val classification = AppCategorizer.classify(packageName, label, info.applicationInfo.category)
                AppEntry(
                    packageName = packageName,
                    activityName = info.componentName.className,
                    label = label,
                    categoryId = classification.categoryId,
                    tags = classification.tags,
                    isSystemApp = info.applicationInfo.flags and ApplicationInfo.FLAG_SYSTEM != 0,
                )
            }
            .distinctBy { it.stableId }
            .sortedBy { it.label.lowercase() }
            .toList()
    }

    fun hasUsageAccess(): Boolean = runCatching {
        val appOps = context.getSystemService(AppOpsManager::class.java)
        appOps.checkOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS,
            android.os.Process.myUid(),
            context.packageName,
        ) == AppOpsManager.MODE_ALLOWED
    }.getOrDefault(false)

    fun loadRecentApps(apps: List<AppEntry>, limit: Int = 5): List<AppEntry> {
        if (apps.isEmpty() || limit <= 0) return emptyList()
        val byPackage = apps.groupBy { it.packageName }
        val byStableId = apps.associateBy { it.stableId }
        val result = mutableListOf<AppEntry>()
        val seen = mutableSetOf<String>()

        if (hasUsageAccess()) {
            usagePackages().forEach { packageName ->
                val app = byPackage[packageName]?.firstOrNull() ?: return@forEach
                if (seen.add(app.stableId)) result += app
                if (result.size >= limit) return result
            }
        }

        storedLaunchHistory().forEach { stableId ->
            val app = byStableId[stableId] ?: return@forEach
            if (seen.add(app.stableId)) result += app
            if (result.size >= limit) return result
        }
        return result
    }

    private fun usagePackages(): List<String> = runCatching {
        val end = System.currentTimeMillis()
        val start = end - 7L * 24L * 60L * 60L * 1000L
        val events = usageStats.queryEvents(start, end)
        val event = UsageEvents.Event()
        val latest = mutableMapOf<String, Long>()
        while (events.hasNextEvent()) {
            events.getNextEvent(event)
            if (
                event.packageName != context.packageName &&
                (event.eventType == UsageEvents.Event.ACTIVITY_RESUMED || event.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND)
            ) {
                latest[event.packageName] = maxOf(latest[event.packageName] ?: 0L, event.timeStamp)
            }
        }
        latest.entries.sortedByDescending { it.value }.map { it.key }
    }.getOrDefault(emptyList())

    private fun storedLaunchHistory(): List<String> =
        prefs.getString(KEY_HISTORY, null)
            ?.lineSequence()
            ?.map(String::trim)
            ?.filter(String::isNotBlank)
            ?.toList()
            .orEmpty()

    private fun rememberLaunch(entry: AppEntry) {
        val updated = buildList {
            add(entry.stableId)
            storedLaunchHistory().filterTo(this) { it != entry.stableId }
        }.take(MAX_STORED_RECENTS)
        prefs.edit().putString(KEY_HISTORY, updated.joinToString("\n")).apply()
    }

    fun launch(entry: AppEntry): Boolean = runCatching {
        val intent = Intent(Intent.ACTION_MAIN).apply {
            component = ComponentName(entry.packageName, entry.activityName)
            addCategory(Intent.CATEGORY_LAUNCHER)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        }
        context.startActivity(intent)
        rememberLaunch(entry)
        true
    }.getOrDefault(false)

    fun openAppInfo(entry: AppEntry): Boolean = runCatching {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.parse("package:${entry.packageName}")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
        true
    }.getOrDefault(false)

    fun requestUninstall(entry: AppEntry): Boolean {
        if (entry.isSystemApp) return false
        return runCatching {
            val intent = Intent(Intent.ACTION_UNINSTALL_PACKAGE).apply {
                data = Uri.parse("package:${entry.packageName}")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            true
        }.getOrDefault(false)
    }

    companion object {
        private const val KEY_HISTORY = "launch_history"
        private const val MAX_STORED_RECENTS = 20
    }
}
