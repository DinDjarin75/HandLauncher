package com.handlauncher.data

import android.content.Context
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.HeartRateRecord
import androidx.health.connect.client.records.OxygenSaturationRecord
import androidx.health.connect.client.records.SleepSessionRecord
import androidx.health.connect.client.records.StepsRecord
import androidx.health.connect.client.request.ReadRecordsRequest
import androidx.health.connect.client.time.TimeRangeFilter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.time.Duration
import java.time.Instant
import java.time.ZoneId
import java.time.ZonedDateTime
import kotlin.math.roundToInt

class EnergyGridRepository(private val context: Context) {
    private val prefs = context.getSharedPreferences("boal_energy_grid", Context.MODE_PRIVATE)

    suspend fun refresh(): EnergyGridState = withContext(Dispatchers.IO) {
        if (HealthConnectClient.getSdkStatus(context) != HealthConnectClient.SDK_AVAILABLE) {
            return@withContext cached().copy(available = false, message = "Health Connect unavailable")
        }

        val client = HealthConnectClient.getOrCreate(context)
        val granted = runCatching { client.permissionController.getGrantedPermissions() }.getOrDefault(emptySet())
        val core = corePermissions()
        val hasCore = core.all { it in granted }
        val hasBackground = HealthPermission.PERMISSION_READ_HEALTH_DATA_IN_BACKGROUND in granted
        if (!hasCore) {
            return@withContext cached().copy(
                available = true,
                permissionsGranted = false,
                backgroundPermissionGranted = hasBackground,
                message = "RingConn health access required",
            )
        }

        val end = Instant.now()
        val zone = ZoneId.systemDefault()
        val todayStart = ZonedDateTime.now(zone).toLocalDate().atStartOfDay(zone).toInstant()

        // RingConn may write sleep/vitals only after its own processing/sync completes.
        // Keep today's step count tight, but allow a few days for the latest sleep/vitals.
        val stepFilter = TimeRangeFilter.between(todayStart, end)
        val sleepFilter = TimeRangeFilter.between(end.minus(Duration.ofDays(4)), end)
        val vitalsFilter = TimeRangeFilter.between(end.minus(Duration.ofDays(2)), end)

        val steps = runCatching {
            client.readRecords(ReadRecordsRequest(StepsRecord::class, stepFilter)).records
        }.getOrDefault(emptyList())
        val sleep = runCatching {
            client.readRecords(ReadRecordsRequest(SleepSessionRecord::class, sleepFilter)).records
        }.getOrDefault(emptyList())
        val heart = runCatching {
            client.readRecords(ReadRecordsRequest(HeartRateRecord::class, vitalsFilter, ascendingOrder = false)).records
        }.getOrDefault(emptyList())
        val oxygen = runCatching {
            client.readRecords(ReadRecordsRequest(OxygenSaturationRecord::class, vitalsFilter, ascendingOrder = false)).records
        }.getOrDefault(emptyList())

        val observedOrigins = buildSet {
            steps.forEach { add(it.metadata.dataOrigin.packageName) }
            sleep.forEach { add(it.metadata.dataOrigin.packageName) }
            heart.forEach { add(it.metadata.dataOrigin.packageName) }
            oxygen.forEach { add(it.metadata.dataOrigin.packageName) }
        }.filter { it.isNotBlank() }

        fun looksLikeRingConn(packageName: String): Boolean {
            if (packageName == RINGCONN_PACKAGE || packageName.contains("ringconn", ignoreCase = true)) return true
            return runCatching {
                val info = context.packageManager.getApplicationInfo(packageName, 0)
                context.packageManager.getApplicationLabel(info).toString().contains("RingConn", ignoreCase = true)
            }.getOrDefault(false)
        }

        val ringOrigins = observedOrigins.filter(::looksLikeRingConn).toSet()
        val displayRingPackage = ringOrigins.firstOrNull() ?: RINGCONN_PACKAGE

        fun sourceSnapshot(packages: Set<String>, packageName: String, label: String): EnergySourceSnapshot {
            val sourceSteps = steps.filter { it.metadata.dataOrigin.packageName in packages }.sumOf { it.count }
            val sourceSleepMinutes = sleep
                .filter { it.metadata.dataOrigin.packageName in packages }
                .sumOf { Duration.between(it.startTime, it.endTime).toMinutes().coerceAtLeast(0L) }
            val sourceHeart = heart
                .asSequence()
                .filter { it.metadata.dataOrigin.packageName in packages }
                .flatMap { it.samples.asSequence() }
                .maxByOrNull { it.time }
                ?.beatsPerMinute
            val sourceOxygen = oxygen
                .asSequence()
                .filter { it.metadata.dataOrigin.packageName in packages }
                .maxByOrNull { it.time }
                ?.percentage
                ?.value

            return EnergySourceSnapshot(
                packageName = packageName,
                label = label,
                steps = sourceSteps.takeIf { it > 0L },
                sleepMinutes = sourceSleepMinutes.takeIf { it > 0L },
                heartRateBpm = sourceHeart,
                oxygenPercent = sourceOxygen,
            )
        }

        // RingConn is the only source surfaced by Energy Grid. Do not silently fall back to
        // Samsung/phone data: if RingConn has not written to Health Connect, tell the user.
        val ring = sourceSnapshot(ringOrigins, displayRingPackage, "RingConn")
        val energyIndex = when {
            ring.sleepMinutes == null && ring.steps == null -> null
            else -> {
                val sleepScore = ((ring.sleepMinutes ?: 0L).toDouble() / 480.0 * 100.0).coerceIn(0.0, 100.0)
                val activityScore = ((ring.steps ?: 0L).toDouble() / 10_000.0 * 100.0).coerceIn(0.0, 100.0)
                (sleepScore * 0.62 + activityScore * 0.38).roundToInt().coerceIn(0, 100)
            }
        }

        val state = EnergyGridState(
            available = true,
            permissionsGranted = true,
            backgroundPermissionGranted = hasBackground,
            energyIndex = energyIndex,
            samsung = EnergySourceSnapshot(SAMSUNG_HEALTH_PACKAGE, "Samsung Health"),
            ringConn = ring,
            lastUpdatedMillis = System.currentTimeMillis(),
            message = if (!ring.hasAnyData()) {
                "RingConn is not sharing records with Health Connect yet"
            } else null,
        )
        save(state)
        state
    }

    fun cached(): EnergyGridState = runCatching {
        val raw = prefs.getString(KEY_STATE, null) ?: return@runCatching EnergyGridState()
        val root = JSONObject(raw)
        fun source(key: String, pkg: String, label: String): EnergySourceSnapshot {
            val obj = root.optJSONObject(key) ?: JSONObject()
            return EnergySourceSnapshot(
                packageName = pkg,
                label = label,
                steps = obj.optLongOrNull("steps"),
                sleepMinutes = obj.optLongOrNull("sleepMinutes"),
                heartRateBpm = obj.optLongOrNull("heartRateBpm"),
                oxygenPercent = obj.optDoubleOrNull("oxygenPercent"),
            )
        }
        EnergyGridState(
            available = root.optBoolean("available", false),
            permissionsGranted = root.optBoolean("permissionsGranted", false),
            backgroundPermissionGranted = root.optBoolean("backgroundPermissionGranted", false),
            energyIndex = root.optInt("energyIndex", -1).takeIf { it >= 0 },
            samsung = EnergySourceSnapshot(SAMSUNG_HEALTH_PACKAGE, "Samsung Health"),
            ringConn = source("ringConn", RINGCONN_PACKAGE, "RingConn"),
            lastUpdatedMillis = root.optLong("lastUpdatedMillis", 0L).takeIf { it > 0L },
            message = root.optString("message").takeIf { it.isNotBlank() },
        )
    }.getOrDefault(EnergyGridState())

    private fun save(state: EnergyGridState) {
        fun source(snapshot: EnergySourceSnapshot) = JSONObject().apply {
            snapshot.steps?.let { put("steps", it) }
            snapshot.sleepMinutes?.let { put("sleepMinutes", it) }
            snapshot.heartRateBpm?.let { put("heartRateBpm", it) }
            snapshot.oxygenPercent?.let { put("oxygenPercent", it) }
        }
        val root = JSONObject()
            .put("available", state.available)
            .put("permissionsGranted", state.permissionsGranted)
            .put("backgroundPermissionGranted", state.backgroundPermissionGranted)
            .put("energyIndex", state.energyIndex ?: -1)
            .put("ringConn", source(state.ringConn))
            .put("lastUpdatedMillis", state.lastUpdatedMillis ?: 0L)
            .put("message", state.message.orEmpty())
        prefs.edit().putString(KEY_STATE, root.toString()).apply()
    }

    companion object {
        const val SAMSUNG_HEALTH_PACKAGE = "com.sec.android.app.shealth"
        const val RINGCONN_PACKAGE = "com.gdjztech.ringconn"
        private const val KEY_STATE = "state"

        fun corePermissions(): Set<String> = setOf(
            HealthPermission.getReadPermission(StepsRecord::class),
            HealthPermission.getReadPermission(SleepSessionRecord::class),
            HealthPermission.getReadPermission(HeartRateRecord::class),
            HealthPermission.getReadPermission(OxygenSaturationRecord::class),
        )

        fun requestedPermissions(): Set<String> = corePermissions() + HealthPermission.PERMISSION_READ_HEALTH_DATA_IN_BACKGROUND
    }
}

private fun EnergySourceSnapshot.hasAnyData(): Boolean =
    steps != null || sleepMinutes != null || heartRateBpm != null || oxygenPercent != null

private fun JSONObject.optLongOrNull(name: String): Long? = if (has(name)) optLong(name) else null
private fun JSONObject.optDoubleOrNull(name: String): Double? = if (has(name)) optDouble(name) else null
