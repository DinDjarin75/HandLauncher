package com.handlauncher

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class HealthPermissionsRationaleActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp),
                    ) {
                        Text("BOAL Energy Grid", style = MaterialTheme.typography.headlineMedium)
                        Text(
                            "BOAL reads steps, sleep, heart rate and blood-oxygen records from Android Health Connect to build the Energy Grid. " +
                                "The data stays on this device, is used only to render the Workspace module, and is never uploaded by BOAL.",
                            style = MaterialTheme.typography.bodyLarge,
                        )
                        Text(
                            "RingConn is the source used by Energy Grid. You can revoke BOAL's access at any time in Health Connect.",
                            style = MaterialTheme.typography.bodyMedium,
                        )
                    }
                }
            }
        }
    }
}
