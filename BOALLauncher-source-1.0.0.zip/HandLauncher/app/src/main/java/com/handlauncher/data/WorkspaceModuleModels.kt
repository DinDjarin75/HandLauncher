package com.handlauncher.data

data class WorkspaceSystemState(
    val storageFreeGb: Double = 0.0,
    val storageTotalGb: Double = 0.0,
    val memoryFreeGb: Double = 0.0,
    val memoryTotalGb: Double = 0.0,
    val batteryTemperatureC: Double? = null,
    val thermalLabel: String = "Normal",
    val uptimeHours: Long = 0,
)

data class EnergySourceSnapshot(
    val packageName: String,
    val label: String,
    val steps: Long? = null,
    val sleepMinutes: Long? = null,
    val deepSleepMinutes: Long? = null,
    val remSleepMinutes: Long? = null,
    val lightSleepMinutes: Long? = null,
    val awakeMinutes: Long? = null,
    val heartRateBpm: Long? = null,
    val oxygenPercent: Double? = null,
)

data class EnergyGridState(
    val available: Boolean = false,
    val permissionsGranted: Boolean = false,
    val backgroundPermissionGranted: Boolean = false,
    val energyIndex: Int? = null,
    val samsung: EnergySourceSnapshot = EnergySourceSnapshot(
        packageName = EnergyGridRepository.SAMSUNG_HEALTH_PACKAGE,
        label = "Samsung Health",
    ),
    val ringConn: EnergySourceSnapshot = EnergySourceSnapshot(
        packageName = EnergyGridRepository.RINGCONN_PACKAGE,
        label = "RingConn",
    ),
    val lastUpdatedMillis: Long? = null,
    val message: String? = null,
)
