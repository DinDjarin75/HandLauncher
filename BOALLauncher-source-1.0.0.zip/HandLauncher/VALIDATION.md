# BOAL Launcher validation — 1.0.0

- Final source is a promotion of the on-device validated 1.0.0-rc4 code path; no Kotlin runtime source changed for the 1.0.0 promotion.
- Version updated to 42 / 1.0.0.
- Release build is explicitly non-debuggable and signed with BOAL's existing stable signing configuration for update compatibility.
- Galaxy Z Fold 8 on-device approval covers cover/portrait Home, Brief, App Library and Workspace plus unfolded horizontal Home, Brief and Workspace.
- Final unfolded Home and Brief stacks are top-anchored.
- GitHub Actions remains the authoritative Android compiler, unit-test and release-APK gate.

# BOAL Launcher validation — 1.0.0-rc3

- Runtime scope is isolated to `HomePages.kt` unfolded-landscape Home and Brief composition plus version/docs metadata.
- Home inner landscape: Clock over Calendar on left; Weather over Battery on right; two rectangular cards per half-screen, vertically centered.
- Brief inner landscape: Clock over Calendar on left; Weather over Headlines on right; two rectangular cards per half-screen, top-anchored.
- Portrait/cover paths and Workspace inner-landscape composition are unchanged from RC2.
- GitHub Actions remains the authoritative Android type/compiler/unit-test gate.

# BOAL Launcher validation — 1.0.0-rc2

- Scope is isolated to unfolded-landscape rendering: `LayoutProfile.INNER_FOLD` plus Android landscape orientation.
- Cover, phone portrait, inner portrait and external-display routing remain unchanged.
- Kotlin PSI syntax parse: all launcher Kotlin source files, zero syntax diagnostics before packaging.
- AndroidManifest/resources XML parsed successfully.
- Home inner landscape uses Clock + Calendar / Weather + Battery directly; Media is excluded only from this landscape composition.
- Workspace inner landscape uses System + Comms Radar / Weather Atlas + Ciné Club; Energy Grid remains untouched in the portrait carousel.
- GitHub Actions remains the authoritative Android type/compiler/unit-test gate.

# BOAL Launcher validation — beta1.10-rc1

- Kotlin PSI syntax parse: 57 source files, zero syntax diagnostics before packaging.
- AndroidManifest/resources: 10 XML files parsed successfully.
- Workspace carousel uses a manual circular pager with duplicate edge pages; there is no timed rotation.
- Health Connect integration requests read access for steps, sleep, heart rate and oxygen saturation plus background health reads; records are source-filtered for Samsung Health and RingConn.
- Ciné Club embeds Showly AppWidgets rather than scraping private app data, preserving Showly PendingIntent interactions.
- Weather, health and Showly widget refresh work is scheduled every 30 minutes with WorkManager; World Clock and Comms Radar remain live from system time/notifications.
- GitHub Actions remains the authoritative Android type/compiler/unit-test gate for new Health Connect and WorkManager dependencies.
- Source manifest and ZIP integrity are regenerated for this release.

# BOAL Launcher validation — beta1.7

- Kotlin PSI syntax parse: 53 source files, zero syntax diagnostics before packaging.
- AndroidManifest.xml parsed successfully.
- Workspace Keep integration uses public AppWidgetManager binding/configuration APIs and the existing durable BOAL AppWidgetHost.
- Workspace ChatGPT API integration uses OpenAI Conversations + Responses endpoints with encrypted local key storage; network/API type validation remains part of GitHub Actions compilation/runtime testing.
- GitHub Actions remains the authoritative Android compiler/unit-test gate.
- Source manifest and ZIP integrity are regenerated for this release.


Date: 27 October 2026

Completed in the current runtime:
- Started from the CI-green beta1.5-fix2 source baseline.
- Added explicit Home downward routing zones: left 30% Notifications, center 40% Search, right 30% Quick Settings.
- Added minimal AccessibilityService bridge for Android GLOBAL_ACTION_NOTIFICATIONS and GLOBAL_ACTION_QUICK_SETTINGS; service metadata disables window-content retrieval.
- Added a Settings shortcut for one-time System shade gesture access setup and a first-gesture fallback to Android Accessibility settings.
- Added MAIN/HOME intent reset in MainActivity so Android's full-width bottom Home gesture returns Search and other transient surfaces to Home.
- Preserved swipe-up App Library behavior and existing Smart Stack gesture ownership.
- Beta1.6 version code/name verified (`26` / `1.0.0-beta1.6`).
- Android manifest/resource XML parsed successfully.
- Source manifest regenerated from the packaged beta1.6 tree.

Runtime note:
- Directly opening the system notification shade and Quick Settings is a privileged global action. BOAL implements it through an opt-in AccessibilityService with `canRetrieveWindowContent=false`; the user must enable BOAL System Gestures once in Android Accessibility settings.

Authoritative Android/Compose validation remains GitHub Actions: Java 17 + Android 36 + Gradle 9.6 -> unit tests -> `:app:assembleDebug` -> APK artifact.
