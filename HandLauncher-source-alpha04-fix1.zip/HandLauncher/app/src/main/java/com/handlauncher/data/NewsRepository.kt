package com.handlauncher.data

import android.content.Context
import android.text.Html
import android.util.Xml
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import org.xmlpull.v1.XmlPullParser
import java.net.HttpURLConnection
import java.net.URL
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

data class NewsHeadline(
    val title: String,
    val url: String,
    val source: String = "",
    val publishedAtMillis: Long? = null,
    val imageUrl: String? = null,
)

data class NewsState(
    val headlines: List<NewsHeadline> = emptyList(),
    val available: Boolean = false,
    val lastUpdatedMillis: Long? = null,
    val message: String? = null,
)

/**
 * Lightweight, local-first headline provider for the briefing surface.
 * Google News RSS supplies the regional headline set without an API key. Hand
 * prefers media embedded in the feed and, when absent, resolves the article's
 * OpenGraph/Twitter lead image so each Brief headline can carry source imagery.
 */
class NewsRepository(@Suppress("UNUSED_PARAMETER") context: Context) {
    private val resolvedImageCache = ConcurrentHashMap<String, String>()
    suspend fun refresh(): NewsState = withContext(Dispatchers.IO) {
        runCatching {
            val connection = (URL(FEED_URL).openConnection() as HttpURLConnection).apply {
                connectTimeout = 8_000
                readTimeout = 10_000
                requestMethod = "GET"
                setRequestProperty("User-Agent", "HandLauncher/1.0")
            }
            connection.inputStream.buffered().use { input ->
                val parser = Xml.newPullParser().apply {
                    setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
                    setInput(input, null)
                }
                val parsed = parse(parser).take(8)
                val items = coroutineScope {
                    parsed.map { headline ->
                        async {
                            if (!headline.imageUrl.isNullOrBlank()) headline
                            else headline.copy(imageUrl = resolvedImageCache[headline.url] ?: resolveLeadImage(headline.url)?.also { resolvedImageCache[headline.url] = it })
                        }
                    }.awaitAll()
                }
                NewsState(
                    headlines = items,
                    available = items.isNotEmpty(),
                    lastUpdatedMillis = System.currentTimeMillis(),
                    message = if (items.isEmpty()) "No headlines available" else null,
                )
            }
        }.getOrElse {
            NewsState(message = "Headlines unavailable")
        }
    }

    private fun parse(parser: XmlPullParser): List<NewsHeadline> {
        val results = mutableListOf<NewsHeadline>()
        var event = parser.eventType
        var inItem = false
        var currentTag: String? = null
        var title = ""
        var link = ""
        var source = ""
        var description = ""
        var published: Long? = null
        var imageUrl: String? = null

        while (event != XmlPullParser.END_DOCUMENT && results.size < 12) {
            when (event) {
                XmlPullParser.START_TAG -> {
                    currentTag = parser.name
                    if (parser.name.equals("item", ignoreCase = true)) {
                        inItem = true
                        title = ""
                        link = ""
                        source = ""
                        description = ""
                        published = null
                        imageUrl = null
                    } else if (inItem) {
                        val tag = parser.name.lowercase(Locale.ROOT)
                        if (tag in setOf("media:content", "media:thumbnail", "enclosure")) {
                            imageUrl = parser.getAttributeValue(null, "url") ?: imageUrl
                        }
                    }
                }
                XmlPullParser.TEXT -> if (inItem) {
                    val raw = parser.text.orEmpty()
                    val value = raw.trim()
                    if (value.isNotBlank()) {
                        when (currentTag?.lowercase(Locale.ROOT)) {
                            "title" -> title += value
                            "link" -> link += value
                            "source" -> source += value
                            "description" -> description += raw
                            "pubdate" -> published = parseDate(value)
                        }
                    }
                }
                XmlPullParser.END_TAG -> {
                    if (parser.name.equals("item", ignoreCase = true)) {
                        val descriptionImage = firstImageInHtml(description)
                        if (title.isNotBlank() && link.isNotBlank()) {
                            results += NewsHeadline(
                                title = title.trim(),
                                url = link.trim(),
                                source = source.trim(),
                                publishedAtMillis = published,
                                imageUrl = imageUrl ?: descriptionImage,
                            )
                        }
                        inItem = false
                    }
                    currentTag = null
                }
            }
            event = parser.next()
        }
        return results
    }

    private fun firstImageInHtml(html: String): String? {
        val match = IMG_SRC.find(html)?.groupValues?.getOrNull(1) ?: return null
        return decodeHtml(match).takeIf { it.startsWith("http://") || it.startsWith("https://") }
    }

    private fun resolveLeadImage(articleUrl: String): String? = runCatching {
        val connection = (URL(articleUrl).openConnection() as HttpURLConnection).apply {
            connectTimeout = 4_500
            readTimeout = 6_000
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "Mozilla/5.0 HandLauncher/1.0")
            setRequestProperty("Accept", "text/html,application/xhtml+xml")
        }
        val html = connection.inputStream.bufferedReader().use { reader ->
            val out = StringBuilder()
            val buffer = CharArray(8192)
            while (out.length < 220_000) {
                val read = reader.read(buffer)
                if (read <= 0) break
                out.append(buffer, 0, read.coerceAtMost(220_000 - out.length))
            }
            out.toString()
        }
        findLeadImageMeta(html)
    }.getOrNull()

    private fun findLeadImageMeta(html: String): String? {
        META_TAG.findAll(html).forEach { match ->
            val tag = match.value
            val attrs = ATTRIBUTE.findAll(tag).associate { attr ->
                attr.groupValues[1].lowercase(Locale.ROOT) to attr.groupValues[2]
            }
            val key = attrs["property"] ?: attrs["name"]
            if (key.equals("og:image", true) || key.equals("og:image:url", true) || key.equals("twitter:image", true) || key.equals("twitter:image:src", true)) {
                val value = attrs["content"]?.let(::decodeHtml)
                if (value != null && (value.startsWith("http://") || value.startsWith("https://"))) return value
            }
        }
        return null
    }

    private fun decodeHtml(value: String): String = Html.fromHtml(value, Html.FROM_HTML_MODE_LEGACY).toString().trim()

    private fun parseDate(raw: String): Long? = runCatching {
        ZonedDateTime.parse(raw, DateTimeFormatter.RFC_1123_DATE_TIME).toInstant().toEpochMilli()
    }.getOrNull()

    companion object {
        private const val FEED_URL = "https://news.google.com/rss?hl=en-LU&gl=LU&ceid=LU:en"
        private val IMG_SRC = Regex("""<img[^>]+src\s*=\s*["']([^"']+)["']""", RegexOption.IGNORE_CASE)
        private val META_TAG = Regex("""<meta\s+[^>]*>""", RegexOption.IGNORE_CASE)
        private val ATTRIBUTE = Regex("""([A-Za-z_:.-]+)\s*=\s*["']([^"']*)["']""")
    }
}
