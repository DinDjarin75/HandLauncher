package com.handlauncher.data

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.provider.CalendarContract
import androidx.core.content.ContextCompat

data class CalendarEventState(
    val title: String,
    val beginMillis: Long,
    val minutesUntil: Int,
)

class DeviceContextRepository(private val context: Context) {
    private val audioManager = context.getSystemService(AudioManager::class.java)

    fun connectedAudioDeviceNames(): Set<String> = runCatching {
        audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
            .asSequence()
            .filter { device ->
                device.type in setOf(
                    AudioDeviceInfo.TYPE_BLUETOOTH_A2DP,
                    AudioDeviceInfo.TYPE_BLUETOOTH_SCO,
                    AudioDeviceInfo.TYPE_BLE_HEADSET,
                    AudioDeviceInfo.TYPE_BLE_SPEAKER,
                    AudioDeviceInfo.TYPE_HEARING_AID,
                )
            }
            .mapNotNull { it.productName?.toString()?.takeIf(String::isNotBlank) }
            .toSet()
    }.getOrDefault(emptySet())

    fun hasCalendarPermission(): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_GRANTED

    fun nextCalendarEvent(): CalendarEventState? {
        if (!hasCalendarPermission()) return null
        val now = System.currentTimeMillis()
        val horizon = now + 7L * 24L * 60L * 60L * 1000L
        val builder = CalendarContract.Instances.CONTENT_URI.buildUpon()
        ContentUris.appendId(builder, now)
        ContentUris.appendId(builder, horizon)
        val projection = arrayOf(
            CalendarContract.Instances.BEGIN,
            CalendarContract.Instances.TITLE,
        )
        val selection = "${CalendarContract.Instances.ALL_DAY}=0"
        return runCatching {
            context.contentResolver.query(
                builder.build(),
                projection,
                selection,
                null,
                "${CalendarContract.Instances.BEGIN} ASC",
            )?.use { cursor ->
                if (!cursor.moveToFirst()) return@use null
                val begin = cursor.getLong(0)
                val title = cursor.getString(1)?.takeIf(String::isNotBlank) ?: "Calendar event"
                CalendarEventState(
                    title = title,
                    beginMillis = begin,
                    minutesUntil = ((begin - now) / 60_000L).toInt().coerceAtLeast(0),
                )
            }
        }.getOrNull()
    }

    fun nextCalendarEventInMinutes(): Int? = nextCalendarEvent()?.minutesUntil
}
