# Changelog

## 1.0.0-alpha01 — 2026-10-25
- Consolidated the launcher into one declarative, per-display-profile architecture.
- Added real Android HOME registration, app discovery and Home-role request.
- Added swipe-down Search/Command Layer and swipe-up categorized App Library.
- Added Android-category-aware automatic classification plus persisted user overrides.
- Added free-form Home editing, drag/resize, fine positioning, grid snapping and layout locking.
- Added Smart Object tap/swipe/long-press execution and editing.
- Added Home object palette for apps, Hand widgets, Android widgets, Smart Stacks, categories and commands.
- Added real `AppWidgetHost` placement/configuration/removal on the Home canvas.
- Added editable native Clock, Calendar, Weather and Battery widgets.
- Added multi-instance editable Smart Stacks with naming, reorder and contextual promotion rules.
- Added Jetpack Window fold/posture handling and independent external-display desktop layouts.
- Added user-editable Context Automation rules for battery, charging, time, display, audio device, Calendar and rain.
- Added actionable contextual command suggestions.
- Added Open-Meteo weather provider using a manual coarse location.
- Added local AI layout designer plus optional Gemini-backed constrained design generation.
- Added AI theme rendering for light/dark, transparency, corners and typography mood.
- Added Android-Keystore encryption for the optional Gemini key.
- Added JSON backup/restore including weather configuration while excluding AI credentials.
- Added current Android build configuration, JUnit core tests and a GitHub Actions APK build workflow.
- Added gesture arbitration so Home search/library swipes do not steal Smart Object gestures.

## Earlier development snapshots
0.1–0.3 established the initial launcher shell, persistence, AppWidget hosting, Fold profiles, Smart Objects and free-form editor. Those snapshots were folded into the 1.0 alpha source milestone above.
