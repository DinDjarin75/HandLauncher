package com.handlauncher.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import com.handlauncher.domain.AiThemeTokens

@Immutable
data class HandVisualTokens(
    val cornerRadiusDp: Int = 28,
    val surfaceAlpha: Float = 0.72f,
    val typographyMood: String = "clean",
)

val LocalHandVisualTokens = staticCompositionLocalOf { HandVisualTokens() }

@Composable
fun HandLauncherTheme(
    theme: AiThemeTokens? = null,
    darkTheme: Boolean = theme?.dark ?: true,
    content: @Composable () -> Unit,
) {
    val mood = theme?.typographyMood?.lowercase() ?: "clean"
    val visuals = HandVisualTokens(
        cornerRadiusDp = (theme?.cornerRadiusDp ?: 28).coerceIn(0, 48),
        surfaceAlpha = (1f - (theme?.transparencyPercent ?: 28).coerceIn(0, 85) / 100f).coerceIn(0.15f, 1f),
        typographyMood = mood,
    )
    val base = Typography()
    val typography = when (mood) {
        "bold" -> Typography(
            displayLarge = base.displayLarge.copy(fontWeight = FontWeight.Bold),
            displayMedium = base.displayMedium.copy(fontWeight = FontWeight.Bold),
            headlineLarge = base.headlineLarge.copy(fontWeight = FontWeight.Bold),
            titleLarge = base.titleLarge.copy(fontWeight = FontWeight.Bold),
        )
        "editorial" -> Typography(
            displayLarge = base.displayLarge.copy(fontFamily = FontFamily.Serif, fontWeight = FontWeight.Light),
            displayMedium = base.displayMedium.copy(fontFamily = FontFamily.Serif, fontWeight = FontWeight.Light),
            headlineLarge = base.headlineLarge.copy(fontFamily = FontFamily.Serif),
            titleLarge = base.titleLarge.copy(fontFamily = FontFamily.Serif),
        )
        "minimal" -> Typography(
            displayLarge = base.displayLarge.copy(fontWeight = FontWeight.Thin),
            displayMedium = base.displayMedium.copy(fontWeight = FontWeight.Thin),
            headlineLarge = base.headlineLarge.copy(fontWeight = FontWeight.Light),
            titleLarge = base.titleLarge.copy(fontWeight = FontWeight.Light),
        )
        else -> base
    }

    androidx.compose.runtime.CompositionLocalProvider(LocalHandVisualTokens provides visuals) {
        MaterialTheme(
            colorScheme = if (darkTheme) darkColorScheme() else lightColorScheme(),
            typography = typography,
            content = content,
        )
    }
}
