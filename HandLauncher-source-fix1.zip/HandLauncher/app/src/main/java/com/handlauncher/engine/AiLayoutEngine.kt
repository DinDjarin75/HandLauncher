package com.handlauncher.engine

import com.handlauncher.domain.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class LocalPrototypeAiLayoutProvider : AiLayoutProvider {
    override suspend fun generate(request: AiLayoutRequest): AiLayoutProposal = composeProposal(
        request = request,
        design = LocalDesignParser.parse(request.naturalLanguagePrompt),
        generatedBy = "Hand local designer",
        rationale = "Generated locally from your requested mood, density, ergonomics and target display profile.",
    )
}

/**
 * Real Gemini-backed generator. The model returns a constrained design plan; Hand itself
 * composes the declarative layout so the model never gets direct mutation authority.
 */
class GeminiAiLayoutProvider(
    private val apiKey: String,
    private val model: String,
    private val fallback: AiLayoutProvider = LocalPrototypeAiLayoutProvider(),
) : AiLayoutProvider {
    override suspend fun generate(request: AiLayoutRequest): AiLayoutProposal = withContext(Dispatchers.IO) {
        runCatching {
            val prompt = buildPrompt(request)
            val body = JSONObject()
                .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
                .put("generationConfig", JSONObject().put("responseMimeType", "application/json"))

            val encodedModel = URLEncoder.encode(model.trim(), Charsets.UTF_8.name()).replace("+", "%20")
            val connection = (URL("https://generativelanguage.googleapis.com/v1beta/models/$encodedModel:generateContent?key=$apiKey").openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 12_000
                readTimeout = 20_000
                doOutput = true
                setRequestProperty("Content-Type", "application/json")
            }
            connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val stream = if (connection.responseCode in 200..299) connection.inputStream else connection.errorStream
            val response = stream.bufferedReader().use { it.readText() }
            if (connection.responseCode !in 200..299) error("Gemini HTTP ${connection.responseCode}: ${response.take(240)}")
            val text = JSONObject(response)
                .getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts").getJSONObject(0)
                .getString("text")
            val design = parseRemoteDesign(JSONObject(stripCodeFence(text)), request)
            composeProposal(
                request = request,
                design = design,
                generatedBy = "Gemini · $model",
                rationale = "Gemini interpreted the design brief; Hand converted it into a constrained, editable layout proposal.",
            )
        }.getOrElse { error ->
            val local = fallback.generate(request)
            local.copy(warnings = local.warnings + "Gemini unavailable: ${error.message ?: "unknown error"}. Used local designer instead.")
        }
    }

    private fun buildPrompt(request: AiLayoutRequest): String {
        val appCatalog = request.availableApps.take(80).joinToString("\n") { "- ${it.label} | ${it.stableId} | ${it.categoryId}" }
        return """
You are the design planner for an Android launcher named Hand. Return JSON only.
The user asks: ${request.naturalLanguagePrompt}
Target display: ${request.targetProfile.name}
Available applications:
$appCatalog

Return exactly this JSON shape:
{
  "dark": true,
  "cornerRadiusDp": 28,
  "transparencyPercent": 18,
  "typographyMood": "clean",
  "oneHanded": false,
  "dense": false,
  "widgets": ["CLOCK","CALENDAR","WEATHER","BATTERY"],
  "appStableIds": ["package/activity"],
  "reason": "one concise sentence"
}
Rules: choose no more than 4 widgets and 12 apps. Only use listed appStableIds. Do not include markdown.
        """.trimIndent()
    }

    private fun parseRemoteDesign(obj: JSONObject, request: AiLayoutRequest): DesignPlan {
        val allowedApps = request.availableApps.associateBy { it.stableId }
        val widgetsArray = obj.optJSONArray("widgets") ?: JSONArray()
        val widgets = buildList {
            for (i in 0 until widgetsArray.length()) {
                runCatching { NativeWidgetKind.valueOf(widgetsArray.getString(i)) }.getOrNull()?.let(::add)
            }
        }.distinct().take(4)
        val appArray = obj.optJSONArray("appStableIds") ?: JSONArray()
        val apps = buildList {
            for (i in 0 until appArray.length()) allowedApps[appArray.getString(i)]?.let(::add)
        }.distinctBy { it.stableId }.take(12)
        return DesignPlan(
            dark = obj.optBoolean("dark", true),
            cornerRadius = obj.optInt("cornerRadiusDp", 28).coerceIn(0, 48),
            transparency = obj.optInt("transparencyPercent", 16).coerceIn(0, 70),
            typography = obj.optString("typographyMood", "clean").take(24),
            oneHanded = obj.optBoolean("oneHanded", false),
            dense = obj.optBoolean("dense", false),
            widgets = widgets.ifEmpty { request.preferredWidgets.take(3) },
            apps = apps,
            reason = obj.optString("reason", "Generated from the design brief."),
        )
    }

    private fun stripCodeFence(text: String): String = text.trim()
        .removePrefix("```json").removePrefix("```")
        .removeSuffix("```").trim()
}

private data class DesignPlan(
    val dark: Boolean,
    val cornerRadius: Int,
    val transparency: Int,
    val typography: String,
    val oneHanded: Boolean,
    val dense: Boolean,
    val widgets: Collection<NativeWidgetKind>,
    val apps: List<AppEntry>,
    val reason: String,
)

private object LocalDesignParser {
    fun parse(prompt: String): DesignPlan {
        val text = prompt.lowercase()
        return DesignPlan(
            dark = !text.contains("light"),
            cornerRadius = if (text.contains("sharp") || text.contains("square")) 8 else 28,
            transparency = if (text.contains("glass") || text.contains("transparent")) 35 else 12,
            typography = when {
                text.contains("minimal") -> "minimal"
                text.contains("bold") -> "bold"
                text.contains("editorial") -> "editorial"
                else -> "clean"
            },
            oneHanded = text.contains("one-handed") || text.contains("one handed") || text.contains("thumb"),
            dense = text.contains("dense") || text.contains("information") || text.contains("dashboard"),
            widgets = listOf(NativeWidgetKind.CLOCK, NativeWidgetKind.CALENDAR, NativeWidgetKind.WEATHER, NativeWidgetKind.BATTERY),
            apps = emptyList(),
            reason = "Parsed locally from the prompt.",
        )
    }
}

private fun composeProposal(
    request: AiLayoutRequest,
    design: DesignPlan,
    generatedBy: String,
    rationale: String,
): AiLayoutProposal {
    val columns = when (request.targetProfile) {
        LayoutProfile.EXTERNAL_DISPLAY -> 12
        LayoutProfile.INNER_FOLD -> 8
        LayoutProfile.PHONE_LANDSCAPE -> 8
        else -> 4
    }
    val rows = if (request.targetProfile == LayoutProfile.EXTERNAL_DISPLAY) 8 else 10
    val widgetHeight = if (design.dense) 0.13f else 0.17f
    val widgetGap = if (design.dense) 0.145f else 0.19f
    val startY = if (design.oneHanded) 0.26f else 0.05f
    val widgetList = design.widgets.take(if (request.targetProfile == LayoutProfile.EXTERNAL_DISPLAY) 4 else 3)

    val objects = buildList {
        var y = startY
        widgetList.forEach { kind ->
            add(
                SmartObject(
                    type = SmartObjectType.NATIVE_WIDGET,
                    title = kind.name.lowercase().replaceFirstChar { it.uppercase() },
                    rect = GridRect(0.05f, y, if (request.targetProfile == LayoutProfile.EXTERNAL_DISPLAY) 0.38f else 0.90f, widgetHeight),
                    payload = mapOf("widgetKind" to kind.name),
                )
            )
            y += widgetGap
        }

        val chosenApps = design.apps.ifEmpty { request.availableApps.take(if (columns >= 8) 10 else 8) }
        val gridStartX = if (request.targetProfile == LayoutProfile.EXTERNAL_DISPLAY) 0.48f else 0.05f
        val gridStartY = if (request.targetProfile == LayoutProfile.EXTERNAL_DISPLAY) 0.08f else (y + 0.02f).coerceAtMost(0.72f)
        val perRow = if (request.targetProfile == LayoutProfile.EXTERNAL_DISPLAY) 4 else if (columns >= 8) 5 else 4
        val cellW = if (request.targetProfile == LayoutProfile.EXTERNAL_DISPLAY) 0.11f else (0.88f / perRow)
        chosenApps.take(12).forEachIndexed { index, app ->
            val col = index % perRow
            val row = index / perRow
            add(
                SmartObject(
                    type = SmartObjectType.APP,
                    title = app.label,
                    rect = GridRect(gridStartX + col * cellW, gridStartY + row * 0.13f, cellW * 0.88f, 0.11f),
                    tags = app.tags,
                    actions = ObjectActions(
                        tap = SmartAction.LaunchApp(app.packageName, app.activityName),
                        swipeUp = SmartAction.OpenCollection(app.categoryId),
                        swipeDown = SmartAction.ShowSurface("search"),
                        longPress = SmartAction.ShowSurface("smart_object_editor"),
                    ),
                    payload = mapOf("appStableId" to app.stableId),
                )
            )
        }
    }

    return AiLayoutProposal(
        rationale = "$rationale ${design.reason}".trim(),
        layout = LauncherLayout(
            id = "ai-proposal",
            name = "AI proposal",
            profile = request.targetProfile,
            columns = columns,
            rows = rows,
            finePositioning = true,
            locked = false,
            pages = listOf(LayoutPage("home", "Home", objects)),
        ),
        theme = AiThemeTokens(
            dark = design.dark,
            cornerRadiusDp = design.cornerRadius,
            transparencyPercent = design.transparency,
            typographyMood = design.typography,
        ),
        generatedBy = generatedBy,
    )
}
