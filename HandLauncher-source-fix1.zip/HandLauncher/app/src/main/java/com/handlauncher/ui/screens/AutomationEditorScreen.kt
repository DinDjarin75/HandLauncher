package com.handlauncher.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.handlauncher.domain.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AutomationEditorScreen(
    rules: List<ContextRule>,
    editingRule: ContextRule?,
    calendarPermissionGranted: Boolean,
    connectedAudioNames: Set<String>,
    onCreate: () -> Unit,
    onEdit: (ContextRule) -> Unit,
    onToggle: (String, Boolean) -> Unit,
    onDelete: (String) -> Unit,
    onRuleName: (String) -> Unit,
    onRuleEnabled: (Boolean) -> Unit,
    onAddCondition: (ContextCondition) -> Unit,
    onUpdateCondition: (Int, ContextCondition) -> Unit,
    onRemoveCondition: (Int) -> Unit,
    onEffect: (ContextEffect) -> Unit,
    onSaveRule: () -> Unit,
    onCancelRule: () -> Unit,
    onRequestCalendarPermission: () -> Unit,
    onDismiss: () -> Unit,
) {
    BackHandler(onBack = if (editingRule != null) onCancelRule else onDismiss)
    if (editingRule != null) {
        RuleForm(
            rule = editingRule,
            calendarPermissionGranted = calendarPermissionGranted,
            connectedAudioNames = connectedAudioNames,
            onName = onRuleName,
            onEnabled = onRuleEnabled,
            onAddCondition = onAddCondition,
            onUpdateCondition = onUpdateCondition,
            onRemoveCondition = onRemoveCondition,
            onEffect = onEffect,
            onSave = onSaveRule,
            onCancel = onCancelRule,
            onRequestCalendarPermission = onRequestCalendarPermission,
        )
        return
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Context Automations") },
                navigationIcon = { IconButton(onClick = onDismiss) { Icon(Icons.Rounded.ArrowBack, "Back") } },
                actions = { IconButton(onClick = onCreate) { Icon(Icons.Rounded.Add, "New automation") } },
            )
        },
        floatingActionButton = { ExtendedFloatingActionButton(onClick = onCreate, icon = { Icon(Icons.Rounded.Add, null) }, text = { Text("Automation") }) },
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                Text(
                    "Rules are evaluated locally. Multiple conditions in one rule are ANDed; effects never permanently rearrange your saved layout.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            items(rules, key = { it.id }) { rule ->
                ElevatedCard(onClick = { onEdit(rule) }, modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(rule.name, style = MaterialTheme.typography.titleMedium)
                                Text(rule.conditions.joinToString(" · ") { it.describe() }, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Switch(checked = rule.enabled, onCheckedChange = { onToggle(rule.id, it) })
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            AssistChip(onClick = { onEdit(rule) }, label = { Text(rule.effect.describe()) }, leadingIcon = { Icon(Icons.Rounded.Bolt, null) })
                            Spacer(Modifier.weight(1f))
                            if (rule.userCreated) IconButton(onClick = { onDelete(rule.id) }) { Icon(Icons.Rounded.DeleteOutline, "Delete") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RuleForm(
    rule: ContextRule,
    calendarPermissionGranted: Boolean,
    connectedAudioNames: Set<String>,
    onName: (String) -> Unit,
    onEnabled: (Boolean) -> Unit,
    onAddCondition: (ContextCondition) -> Unit,
    onUpdateCondition: (Int, ContextCondition) -> Unit,
    onRemoveCondition: (Int) -> Unit,
    onEffect: (ContextEffect) -> Unit,
    onSave: () -> Unit,
    onCancel: () -> Unit,
    onRequestCalendarPermission: () -> Unit,
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Automation rule") },
                navigationIcon = { IconButton(onClick = onCancel) { Icon(Icons.Rounded.Close, "Cancel") } },
                actions = { TextButton(onClick = onSave) { Text("Save") } },
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            item {
                OutlinedTextField(value = rule.name, onValueChange = onName, label = { Text("Rule name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            }
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Enabled", modifier = Modifier.weight(1f))
                    Switch(checked = rule.enabled, onCheckedChange = onEnabled)
                }
            }
            item { Text("When all of these are true", style = MaterialTheme.typography.titleMedium) }
            items(rule.conditions.size, key = { "condition_$it" }) { index ->
                ConditionEditor(index, rule.conditions[index], onUpdateCondition, onRemoveCondition)
            }
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Add condition", style = MaterialTheme.typography.labelLarge)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        AssistChip(onClick = { onAddCondition(ContextCondition.BatteryBelow(20)) }, label = { Text("Battery") })
                        AssistChip(onClick = { onAddCondition(ContextCondition.TimeBetween(8, 18)) }, label = { Text("Time") })
                        AssistChip(onClick = { onAddCondition(ContextCondition.ChargingIs(true)) }, label = { Text("Charging") })
                    }
                    Row(
                        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        AssistChip(onClick = { onAddCondition(ContextCondition.ProfileIs(LayoutProfile.INNER_FOLD)) }, label = { Text("Display") })
                        AssistChip(onClick = { onAddCondition(ContextCondition.BluetoothConnected(connectedAudioNames.firstOrNull().orEmpty())) }, label = { Text("Audio device") })
                        AssistChip(onClick = {
                            if (calendarPermissionGranted) onAddCondition(ContextCondition.EventWithin(30)) else onRequestCalendarPermission()
                        }, label = { Text(if (calendarPermissionGranted) "Calendar" else "Enable Calendar") })
                        AssistChip(onClick = { onAddCondition(ContextCondition.RainWithin(60)) }, label = { Text("Rain") })
                    }
                }
            }
            item { HorizontalDivider() }
            item { Text("Then", style = MaterialTheme.typography.titleMedium) }
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Current: ${rule.effect.describe()}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        AssistChip(onClick = { onEffect(ContextEffect.PromoteWidget(NativeWidgetKind.CALENDAR)) }, label = { Text("Calendar") })
                        AssistChip(onClick = { onEffect(ContextEffect.PromoteWidget(NativeWidgetKind.WEATHER)) }, label = { Text("Weather") })
                        AssistChip(onClick = { onEffect(ContextEffect.PromoteWidget(NativeWidgetKind.BATTERY)) }, label = { Text("Battery") })
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        AssistChip(onClick = { onEffect(ContextEffect.SuggestCommand("Search", "search")) }, label = { Text("Suggest Search") })
                        AssistChip(onClick = { onEffect(ContextEffect.SuggestCommand("Apps", "library")) }, label = { Text("Suggest Apps") })
                    }
                }
            }
            item { Button(onClick = onSave, modifier = Modifier.fillMaxWidth()) { Text("Save automation") } }
        }
    }
}

@Composable
private fun ConditionEditor(
    index: Int,
    condition: ContextCondition,
    onUpdate: (Int, ContextCondition) -> Unit,
    onRemove: (Int) -> Unit,
) {
    ElevatedCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(condition.describe(), style = MaterialTheme.typography.labelLarge, modifier = Modifier.weight(1f))
                IconButton(onClick = { onRemove(index) }) { Icon(Icons.Rounded.RemoveCircleOutline, "Remove") }
            }
            when (condition) {
                is ContextCondition.BatteryBelow -> NumberField(condition.percent, "Percent") { onUpdate(index, condition.copy(percent = it.coerceIn(1, 100))) }
                is ContextCondition.ChargingIs -> Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Require charging", modifier = Modifier.weight(1f)); Switch(condition.charging, { onUpdate(index, condition.copy(charging = it)) })
                }
                is ContextCondition.TimeBetween -> Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(Modifier.weight(1f)) { NumberField(condition.startHour, "Start hour") { onUpdate(index, condition.copy(startHour = it.coerceIn(0, 23))) } }
                    Box(Modifier.weight(1f)) { NumberField(condition.endHourExclusive, "End hour") { onUpdate(index, condition.copy(endHourExclusive = it.coerceIn(0, 24))) } }
                }
                is ContextCondition.ProfileIs -> {
                    Row(
                        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(5.dp),
                    ) {
                        LayoutProfile.entries.forEach { profile ->
                            FilterChip(selected = condition.profile == profile, onClick = { onUpdate(index, condition.copy(profile = profile)) }, label = { Text(profile.name.take(5)) })
                        }
                    }
                }
                is ContextCondition.BluetoothConnected -> OutlinedTextField(
                    value = condition.nameContains,
                    onValueChange = { onUpdate(index, condition.copy(nameContains = it)) },
                    label = { Text("Device name contains") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                )
                is ContextCondition.EventWithin -> NumberField(condition.minutes, "Minutes before event") { onUpdate(index, condition.copy(minutes = it.coerceIn(1, 1440))) }
                is ContextCondition.RainWithin -> NumberField(condition.minutes, "Minutes before rain") { onUpdate(index, condition.copy(minutes = it.coerceIn(1, 1440))) }
            }
        }
    }
}

@Composable
private fun NumberField(value: Int, label: String, onValue: (Int) -> Unit) {
    OutlinedTextField(
        value = value.toString(),
        onValueChange = { it.filter(Char::isDigit).toIntOrNull()?.let(onValue) },
        label = { Text(label) },
        singleLine = true,
        modifier = Modifier.fillMaxWidth(),
    )
}

private fun ContextCondition.describe(): String = when (this) {
    is ContextCondition.BatteryBelow -> "Battery below $percent%"
    is ContextCondition.ChargingIs -> if (charging) "Phone is charging" else "Phone is not charging"
    is ContextCondition.TimeBetween -> "Time $startHour:00–$endHourExclusive:00"
    is ContextCondition.ProfileIs -> "Display ${profile.name.replace('_', ' ').lowercase()}"
    is ContextCondition.BluetoothConnected -> "Audio device contains ‘$nameContains’"
    is ContextCondition.EventWithin -> "Calendar event within $minutes min"
    is ContextCondition.RainWithin -> "Rain within $minutes min"
}

private fun ContextEffect.describe(): String = when (this) {
    is ContextEffect.PromoteWidget -> "Promote ${kind.name.lowercase()}"
    is ContextEffect.SuggestCommand -> "Suggest $title"
    is ContextEffect.SurfaceObject -> "Surface Home object"
}
