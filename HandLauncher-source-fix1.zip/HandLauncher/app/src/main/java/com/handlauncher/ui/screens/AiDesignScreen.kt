package com.handlauncher.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.handlauncher.domain.AiLayoutProposal

@Composable
fun AiDesignScreen(
    prompt: String,
    proposal: AiLayoutProposal?,
    onPromptChange: (String) -> Unit,
    onGenerate: () -> Unit,
    onApply: () -> Unit,
    onDismiss: () -> Unit,
) {
    BackHandler(onBack = onDismiss)
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        LazyColumn(
            modifier = Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding(),
            contentPadding = PaddingValues(18.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            item {
                Row(Modifier.fillMaxWidth()) {
                    Text("AI Design", style = MaterialTheme.typography.headlineMedium, modifier = Modifier.weight(1f))
                    IconButton(onClick = onDismiss) { Icon(Icons.Rounded.Close, "Close") }
                }
            }
            item {
                Text(
                    "Describe a layout or theme. Generation produces a preview proposal only; it never silently overwrites your home screen.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            item {
                OutlinedTextField(
                    value = prompt,
                    onValueChange = onPromptChange,
                    minLines = 3,
                    label = { Text("Describe your ideal home screen") },
                    placeholder = { Text("Dark glass layout, one-handed, calendar + weather + media…") },
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            item {
                Button(onClick = onGenerate, enabled = prompt.isNotBlank()) {
                    Icon(Icons.Rounded.AutoAwesome, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Generate proposal")
                }
            }
            if (proposal != null) {
                item {
                    ElevatedCard(Modifier.fillMaxWidth(), shape = RoundedCornerShape(28.dp)) {
                        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text(proposal.layout.name, style = MaterialTheme.typography.titleLarge)
                            Text(proposal.rationale)
                            AssistChip(onClick = {}, label = { Text(proposal.generatedBy) })
                            proposal.warnings.forEach { warning ->
                                Text(warning, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                            }
                            HorizontalDivider()
                            Text("Profile: ${proposal.layout.profile}")
                            Text("Grid: ${proposal.layout.columns} × ${proposal.layout.rows} · Fine positioning ${if (proposal.layout.finePositioning) "on" else "off"}")
                            Text("Theme: ${if (proposal.theme.dark) "dark" else "light"} · ${proposal.theme.typographyMood} · ${proposal.theme.transparencyPercent}% transparency")
                            Text("Objects proposed: ${proposal.layout.pages.sumOf { it.objects.size }}")
                            Button(onClick = onApply) { Text("Apply this layout") }
                        }
                    }
                }
            }
        }
    }
}
