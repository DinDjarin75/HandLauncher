package com.handlauncher.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.handlauncher.domain.AppCategory
import com.handlauncher.domain.AppEntry
import com.handlauncher.ui.components.AppIcon

@Composable
fun CategoryEditorScreen(
    apps: List<AppEntry>,
    categories: List<AppCategory>,
    selectedCategoryId: String,
    onSelectCategory: (String) -> Unit,
    onRenameCategory: (String, String) -> Unit,
    onCreateCategory: (String) -> Unit,
    onAssignApp: (AppEntry, String) -> Unit,
    onDismiss: () -> Unit,
) {
    BackHandler(onBack = onDismiss)
    val selected = categories.firstOrNull { it.id == selectedCategoryId } ?: categories.firstOrNull()
    var rename by remember(selected?.id, selected?.name) { mutableStateOf(selected?.name.orEmpty()) }
    var showNewCategory by remember { mutableStateOf(false) }
    var newCategoryName by remember { mutableStateOf("") }

    Surface(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("Edit categories", style = MaterialTheme.typography.headlineMedium, modifier = Modifier.weight(1f))
                IconButton(onClick = { showNewCategory = true }) { Icon(Icons.Rounded.Add, "New category") }
                IconButton(onClick = onDismiss) { Icon(Icons.Rounded.Close, "Close") }
            }

            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 14.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                categories.forEach { category ->
                    FilterChip(
                        selected = category.id == selectedCategoryId,
                        onClick = { onSelectCategory(category.id) },
                        label = { Text(category.name) },
                    )
                }
            }

            if (selected != null) {
                Row(
                    Modifier.fillMaxWidth().padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    OutlinedTextField(
                        value = rename,
                        onValueChange = { rename = it },
                        label = { Text("Category name") },
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                    )
                    Button(onClick = { onRenameCategory(selected.id, rename) }, enabled = rename.isNotBlank()) {
                        Text("Save")
                    }
                }

                Text(
                    "Choose which apps belong to ${selected.name}. An app has one primary visual category in V1; tags remain independent underneath.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 18.dp, vertical = 4.dp),
                )

                LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(vertical = 8.dp)) {
                    items(apps, key = { it.stableId }) { app ->
                        ListItem(
                            headlineContent = { Text(app.label) },
                            supportingContent = { Text(app.tags.joinToString(" · ")) },
                            leadingContent = {
                                AppIcon(app, onClick = {}, compact = true, modifier = Modifier.width(58.dp))
                            },
                            trailingContent = {
                                RadioButton(
                                    selected = app.categoryId == selected.id,
                                    onClick = { onAssignApp(app, selected.id) },
                                )
                            },
                        )
                    }
                }
            }
        }
    }

    if (showNewCategory) {
        AlertDialog(
            onDismissRequest = { showNewCategory = false },
            title = { Text("New category") },
            text = {
                OutlinedTextField(
                    value = newCategoryName,
                    onValueChange = { newCategoryName = it },
                    label = { Text("Name") },
                    singleLine = true,
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        onCreateCategory(newCategoryName)
                        newCategoryName = ""
                        showNewCategory = false
                    },
                    enabled = newCategoryName.isNotBlank(),
                ) { Text("Create") }
            },
            dismissButton = { TextButton(onClick = { showNewCategory = false }) { Text("Cancel") } },
        )
    }
}
