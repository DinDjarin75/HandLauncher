package com.handlauncher.ui.screens

import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.handlauncher.data.BatteryState
import com.handlauncher.data.WeatherState
import com.handlauncher.domain.*
import com.handlauncher.platform.AndroidWidgetHostController
import com.handlauncher.ui.components.AppIcon
import com.handlauncher.ui.components.DeclarativeLayoutCanvas
import com.handlauncher.ui.components.SmartWidgetStack
import kotlin.math.abs

@Composable
fun FeedPage(onOpenGoogle: () -> Unit = {}, modifier: Modifier = Modifier) {
    Box(modifier = modifier.fillMaxSize().padding(20.dp).statusBarsPadding(), contentAlignment = Alignment.Center) {
        ElevatedCard(shape = RoundedCornerShape(30.dp)) {
            Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Icon(Icons.Rounded.Newspaper, null, modifier = Modifier.size(36.dp))
                Text("Google Discover", style = MaterialTheme.typography.headlineSmall)
                Text(
                    "Hand keeps the left page reserved for Google Discover. Google does not expose a public embedding API, so the private companion bridge remains isolated from the launcher core.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Button(onClick = onOpenGoogle) { Text("Open Google feed") }
                AssistChip(onClick = {}, label = { Text("Embedded bridge · platform-gated") })
            }
        }
    }
}

@Composable
fun PhoneHomePage(
    apps: List<AppEntry>,
    smartObjectOverrides: Map<String, SmartObject>,
    smartStacks: Map<String, SmartStackDefinition>,
    battery: BatteryState,
    weather: WeatherState,
    contextDecision: ContextDecision,
    connectedDeviceNames: Set<String>,
    nextEventInMinutes: Int?,
    nextEventTitle: String?,
    nextEventStartMillis: Long?,
    profile: LayoutProfile,
    activeLayout: LauncherLayout?,
    editMode: Boolean,
    isHomeRoleHeld: Boolean,
    requestHomeRole: () -> Unit,
    onLaunch: (AppEntry) -> Unit,
    onEditSmartObject: (AppEntry) -> Unit,
    onSearch: () -> Unit,
    onLibrary: () -> Unit,
    onAiDesign: () -> Unit,
    onAutomations: () -> Unit,
    onSettings: () -> Unit,
    onRunCommand: (String) -> Unit,
    onAddObject: () -> Unit,
    onEnterEditMode: () -> Unit,
    onExitEditMode: () -> Unit,
    onToggleLock: () -> Unit,
    onToggleFinePositioning: () -> Unit,
    onObjectGesture: (SmartObject, GestureSlot) -> Unit,
    onObjectRectChange: (String, GridRect, Boolean) -> Unit,
    onRemoveObject: (SmartObject) -> Unit,
    onEditObject: (SmartObject) -> Unit,
    widgetHostController: AndroidWidgetHostController,
    modifier: Modifier = Modifier,
) {
    var verticalDrag by remember { mutableFloatStateOf(0f) }

    Box(
        modifier = modifier.fillMaxSize().then(
            if (!editMode && activeLayout == null) Modifier.pointerInput(Unit) {
                detectVerticalDragGestures(
                    onVerticalDrag = { _, amount -> verticalDrag += amount },
                    onDragEnd = {
                        if (abs(verticalDrag) > 90f) {
                            if (verticalDrag > 0) onSearch() else onLibrary()
                        }
                        verticalDrag = 0f
                    },
                )
            } else Modifier
        )
    ) {
        Column(
            modifier = Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 14.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("HAND", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                    Text(
                        profile.name.replace('_', ' ').lowercase().replaceFirstChar { it.uppercase() } + (activeLayout?.name?.let { " · $it" } ?: ""),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                if (editMode) {
                    FilledTonalIconButton(onClick = onAddObject) { Icon(Icons.Rounded.Add, "Add object") }
                    FilledTonalIconButton(onClick = onToggleFinePositioning) { Icon(if (activeLayout?.finePositioning == true) Icons.Rounded.OpenWith else Icons.Rounded.Grid4x4, "Positioning") }
                    FilledTonalIconButton(onClick = onToggleLock) { Icon(Icons.Rounded.Lock, "Lock") }
                    Button(onClick = onExitEditMode) { Text("Done") }
                } else {
                    IconButton(onClick = onAutomations) { Icon(Icons.Rounded.Bolt, "Automations") }
                    IconButton(onClick = onSettings) { Icon(Icons.Rounded.Settings, "Settings") }
                    FilledTonalIconButton(onClick = onEnterEditMode) { Icon(Icons.Rounded.Edit, "Edit Home") }
                    FilledTonalIconButton(onClick = onAiDesign) { Icon(Icons.Rounded.AutoAwesome, "AI Design") }
                }
            }

            if (!isHomeRoleHeld && !editMode) {
                ElevatedCard(shape = RoundedCornerShape(24.dp)) {
                    Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Icon(Icons.Rounded.Home, null)
                        Column(Modifier.weight(1f)) {
                            Text("Make Hand your Home", fontWeight = FontWeight.SemiBold)
                            Text("Android recognizes this build as a real launcher.", style = MaterialTheme.typography.bodySmall)
                        }
                        Button(onClick = requestHomeRole) { Text("Set") }
                    }
                }
            }

            if (!editMode) {
                contextDecision.effects.filterIsInstance<ContextEffect.SuggestCommand>().firstOrNull()?.let { suggestion ->
                    ElevatedCard(onClick = { onRunCommand(suggestion.command) }, shape = RoundedCornerShape(22.dp)) {
                        Row(
                            Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            Icon(Icons.Rounded.AutoAwesome, null)
                            Column(Modifier.weight(1f)) {
                                Text(suggestion.title, style = MaterialTheme.typography.labelLarge)
                                Text("Context suggestion", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Icon(Icons.Rounded.ChevronRight, null)
                        }
                    }
                }
            }

            if (activeLayout != null) {
                DeclarativeLayoutCanvas(
                    layout = activeLayout,
                    apps = apps,
                    battery = battery,
                    weather = weather,
                    contextDecision = contextDecision,
                    connectedDeviceNames = connectedDeviceNames,
                    nextEventInMinutes = nextEventInMinutes,
                    nextEventTitle = nextEventTitle,
                    nextEventStartMillis = nextEventStartMillis,
                    smartStacks = smartStacks,
                    editMode = editMode,
                    onGesture = onObjectGesture,
                    onRectChange = onObjectRectChange,
                    onRemoveObject = onRemoveObject,
                    onEditObject = onEditObject,
                    onBackgroundSwipeDown = onSearch,
                    onBackgroundSwipeUp = onLibrary,
                    widgetHostController = widgetHostController,
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                )
            } else {
                SmartWidgetStack(
                    battery = battery,
                    contextDecision = contextDecision,
                    modifier = Modifier.height(205.dp),
                    definition = smartStacks.values.firstOrNull(),
                    connectedDeviceNames = connectedDeviceNames,
                    nextEventInMinutes = nextEventInMinutes,
                    nextEventTitle = nextEventTitle,
                    nextEventStartMillis = nextEventStartMillis,
                    weather = weather,
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Favorites", style = MaterialTheme.typography.labelLarge, modifier = Modifier.weight(1f))
                    Text("Edit creates your free-form canvas", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                LazyVerticalGrid(columns = GridCells.Fixed(4), modifier = Modifier.weight(1f), userScrollEnabled = false) {
                    items(apps.take(8), key = { it.stableId }) { app ->
                        AppIcon(app, { onLaunch(app) }, displayLabel = smartObjectOverrides[app.stableId]?.title ?: app.label, onLongClick = { onEditSmartObject(app) })
                    }
                }
            }

            Text(
                if (editMode) {
                    if (activeLayout?.finePositioning == true) "Fine positioning · Add inserts real objects onto this canvas" else "Grid snapping · Add inserts real objects onto this canvas"
                } else "↓ Search    ·    ↑ Categories",
                modifier = Modifier.align(Alignment.CenterHorizontally),
                style = MaterialTheme.typography.labelSmall,
                color = if (editMode) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
fun ExtraHomePage(
    contextDecision: ContextDecision,
    battery: BatteryState,
    weather: WeatherState,
    onAiDesign: () -> Unit,
    onAutomations: () -> Unit,
    onSettings: () -> Unit,
    profile: LayoutProfile,
) {
    Column(
        Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Text("Workspace", style = MaterialTheme.typography.headlineMedium)
        Text(profile.name.replace('_', ' '), color = MaterialTheme.colorScheme.onSurfaceVariant)
        ElevatedCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Live context", style = MaterialTheme.typography.titleMedium)
                Text("Phone battery · ${battery.percent}%${if (battery.charging) " · charging" else ""}")
                Text("${weather.location.label} · ${weather.temperatureC?.let { "${kotlin.math.round(it).toInt()}°" } ?: "—°"} · ${weather.condition}")
                if (contextDecision.effects.isEmpty()) Text("No contextual rules are active right now.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                contextDecision.effects.forEach { effect ->
                    Text(
                        when (effect) {
                            is ContextEffect.PromoteWidget -> "Promoting ${effect.kind.name.lowercase()} in eligible Smart Stacks"
                            is ContextEffect.SuggestCommand -> "Suggestion · ${effect.title}"
                            is ContextEffect.SurfaceObject -> "Surfacing object · ${effect.objectId}"
                        }
                    )
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = onAiDesign) { Icon(Icons.Rounded.AutoAwesome, null); Spacer(Modifier.width(6.dp)); Text("AI Design") }
            OutlinedButton(onClick = onAutomations) { Icon(Icons.Rounded.Bolt, null); Spacer(Modifier.width(6.dp)); Text("Automations") }
        }
        OutlinedButton(onClick = onSettings) { Icon(Icons.Rounded.Settings, null); Spacer(Modifier.width(6.dp)); Text("Settings") }
    }
}

@Composable
fun DesktopHomePage(
    apps: List<AppEntry>,
    smartObjectOverrides: Map<String, SmartObject>,
    smartStacks: Map<String, SmartStackDefinition>,
    battery: BatteryState,
    weather: WeatherState,
    contextDecision: ContextDecision,
    connectedDeviceNames: Set<String>,
    nextEventInMinutes: Int?,
    nextEventTitle: String?,
    nextEventStartMillis: Long?,
    activeLayout: LauncherLayout?,
    editMode: Boolean,
    onLaunch: (AppEntry) -> Unit,
    onEditSmartObject: (AppEntry) -> Unit,
    onSearch: () -> Unit,
    onAiDesign: () -> Unit,
    onAutomations: () -> Unit,
    onSettings: () -> Unit,
    onAddObject: () -> Unit,
    onEnterEditMode: () -> Unit,
    onExitEditMode: () -> Unit,
    onToggleLock: () -> Unit,
    onToggleFinePositioning: () -> Unit,
    onObjectGesture: (SmartObject, GestureSlot) -> Unit,
    onObjectRectChange: (String, GridRect, Boolean) -> Unit,
    onRemoveObject: (SmartObject) -> Unit,
    onEditObject: (SmartObject) -> Unit,
    widgetHostController: AndroidWidgetHostController,
) {
    Row(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(14.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        Surface(modifier = Modifier.width(250.dp).fillMaxHeight(), shape = RoundedCornerShape(28.dp), tonalElevation = 3.dp) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("HAND DESKTOP", style = MaterialTheme.typography.titleLarge)
                activeLayout?.let { Text(it.name, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                NavigationDrawerItem(label = { Text("Search") }, selected = false, icon = { Icon(Icons.Rounded.Search, null) }, onClick = onSearch)
                NavigationDrawerItem(label = { Text("AI Design") }, selected = false, icon = { Icon(Icons.Rounded.AutoAwesome, null) }, onClick = onAiDesign)
                NavigationDrawerItem(label = { Text("Automations") }, selected = false, icon = { Icon(Icons.Rounded.Bolt, null) }, onClick = onAutomations)
                NavigationDrawerItem(label = { Text("Settings") }, selected = false, icon = { Icon(Icons.Rounded.Settings, null) }, onClick = onSettings)
                HorizontalDivider()
                if (editMode) {
                    Button(onClick = onAddObject, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Rounded.Add, null); Spacer(Modifier.width(6.dp)); Text("Add object") }
                    Button(onClick = onExitEditMode, modifier = Modifier.fillMaxWidth()) { Text("Done editing") }
                    FilledTonalButton(onClick = onToggleFinePositioning, modifier = Modifier.fillMaxWidth()) { Text(if (activeLayout?.finePositioning == true) "Fine positioning" else "Grid snapping") }
                    FilledTonalButton(onClick = onToggleLock, modifier = Modifier.fillMaxWidth()) { Text("Lock layout") }
                } else {
                    Button(onClick = onEnterEditMode, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Rounded.Edit, null); Spacer(Modifier.width(8.dp)); Text("Edit layout") }
                    if (activeLayout?.locked == true) TextButton(onClick = onToggleLock, modifier = Modifier.fillMaxWidth()) { Text("Unlock layout") }
                }
                Spacer(Modifier.weight(1f))
                Text("Battery ${battery.percent}%", style = MaterialTheme.typography.labelMedium)
                Text("Independent external-display profile", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
            }
        }

        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            if (activeLayout != null) {
                DeclarativeLayoutCanvas(
                    layout = activeLayout,
                    apps = apps,
                    battery = battery,
                    weather = weather,
                    contextDecision = contextDecision,
                    connectedDeviceNames = connectedDeviceNames,
                    nextEventInMinutes = nextEventInMinutes,
                    nextEventTitle = nextEventTitle,
                    nextEventStartMillis = nextEventStartMillis,
                    smartStacks = smartStacks,
                    editMode = editMode,
                    onGesture = onObjectGesture,
                    onRectChange = onObjectRectChange,
                    onRemoveObject = onRemoveObject,
                    onEditObject = onEditObject,
                    widgetHostController = widgetHostController,
                    modifier = Modifier.fillMaxSize(),
                )
            } else {
                SmartWidgetStack(
                    battery = battery,
                    contextDecision = contextDecision,
                    modifier = Modifier.height(190.dp),
                    definition = smartStacks.values.firstOrNull(),
                    connectedDeviceNames = connectedDeviceNames,
                    nextEventInMinutes = nextEventInMinutes,
                    nextEventTitle = nextEventTitle,
                    nextEventStartMillis = nextEventStartMillis,
                    weather = weather,
                )
                Text("Apps", style = MaterialTheme.typography.titleLarge)
                LazyVerticalGrid(columns = GridCells.Adaptive(100.dp), modifier = Modifier.fillMaxSize()) {
                    items(apps, key = { it.stableId }) { app ->
                        AppIcon(app, { onLaunch(app) }, displayLabel = smartObjectOverrides[app.stableId]?.title ?: app.label, onLongClick = { onEditSmartObject(app) })
                    }
                }
            }
        }
    }
}
