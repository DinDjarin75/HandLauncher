# Hand Launcher

**Hand** is a fold-first, category-first Android HOME launcher built around a simple premise: cannibalize the strongest interaction ideas from modern launchers, but keep the user's authored Home layout in control.

## Core gestures
- **Swipe down on empty Home** → universal Search / Command Layer
- **Swipe up on empty Home** → categorized App Library
- **Swipe toward the left page** → Google Discover provider surface/fallback
- **Swipe toward the right page** → contextual Workspace
- **Smart Object gestures** → configurable secondary actions

## What makes Hand different
- No conventional bottom app drawer: apps are auto-classified into editable categories.
- Independent cover / unfolded Fold / portrait / landscape / external-display layouts.
- Free-form Home editing with fine positioning or grid snapping.
- Native Hand widgets and real Android widgets on the same declarative canvas.
- Multiple editable Smart Stacks with contextual promotion that never rewrites stack order.
- Context Automation using battery, charging, time, display, audio devices, Calendar and rain.
- AI layout/theme generation with an offline local designer and optional Gemini provider.
- Smart Objects unify apps, categories, widgets, stacks and commands under one gesture/action model.
- JSON backup/restore; AI credentials stay out of backups.

## Build
See [`BUILDING.md`](BUILDING.md). A GitHub Actions workflow is included to run tests and produce `app-debug.apk` as a workflow artifact.

## Current status
This repository is **1.0.0-alpha01** source. The product loop is implemented, but the chat runtime used to generate it does not contain an Android SDK/Gradle distribution, so no locally assembled APK is claimed. See [`PROJECT_STATUS.md`](PROJECT_STATUS.md) for implemented features and platform-gated limitations.
