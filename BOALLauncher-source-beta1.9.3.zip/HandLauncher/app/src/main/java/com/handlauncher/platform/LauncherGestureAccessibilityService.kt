package com.handlauncher.platform

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.ArrayDeque

enum class SystemQuickSetting(val aliases: List<String>) {
    MOBILE_DATA(listOf("mobile data", "mobile network")),
    BLUETOOTH(listOf("bluetooth")),
    WIFI(listOf("wi-fi", "wifi")),
    HOTSPOT(listOf("mobile hotspot", "hotspot")),
}

/**
 * BOAL's explicit system-gesture / connectivity bridge.
 *
 * Window retrieval is restricted in XML to com.android.systemui. BOAL only
 * inspects that tree after an explicit connectivity-tile tap, clicks the
 * matching Quick Settings tile on the user's behalf, then closes the panel.
 */
class LauncherGestureAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var pendingToggle: SystemQuickSetting? = null
    private var attemptCount = 0

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (pendingToggle != null) scheduleAttempt(45L)
    }

    override fun onInterrupt() = Unit

    override fun onUnbind(intent: Intent?): Boolean {
        if (instance === this) instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    private fun requestToggle(target: SystemQuickSetting): Boolean {
        pendingToggle = target
        attemptCount = 0
        val opened = performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
        if (!opened) {
            pendingToggle = null
            return false
        }
        scheduleAttempt(120L)
        return true
    }

    private fun scheduleAttempt(delayMs: Long) {
        handler.removeCallbacks(attemptRunnable)
        handler.postDelayed(attemptRunnable, delayMs)
    }

    private val attemptRunnable = Runnable { attemptPendingToggle() }

    private fun attemptPendingToggle() {
        val target = pendingToggle ?: return
        attemptCount += 1
        val root = rootInActiveWindow
        val clickable = root?.let { findClickableTarget(it, target) }
        if (clickable?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true) {
            pendingToggle = null
            handler.postDelayed({ performGlobalAction(GLOBAL_ACTION_BACK) }, 260L)
            return
        }

        // Give SystemUI time to finish expanding. If BOAL still cannot find the
        // requested tile, leave Quick Settings open as a graceful manual fallback.
        if (attemptCount < 7) scheduleAttempt(140L) else pendingToggle = null
    }

    private fun findClickableTarget(root: AccessibilityNodeInfo, target: SystemQuickSetting): AccessibilityNodeInfo? {
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        while (queue.isNotEmpty()) {
            val node = queue.removeFirst()
            val label = buildString {
                node.text?.let { append(it).append(' ') }
                node.contentDescription?.let { append(it) }
            }.lowercase()
            if (target.aliases.any { alias -> label.contains(alias) }) {
                var candidate: AccessibilityNodeInfo? = node
                repeat(5) {
                    if (candidate?.isClickable == true) return candidate
                    candidate = candidate?.parent
                }
            }
            for (index in 0 until node.childCount) node.getChild(index)?.let(queue::add)
        }
        return null
    }

    companion object {
        @Volatile private var instance: LauncherGestureAccessibilityService? = null

        fun openNotifications(): Boolean =
            instance?.performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS) == true

        fun openQuickSettings(): Boolean =
            instance?.performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS) == true

        fun toggleQuickSetting(target: SystemQuickSetting): Boolean =
            instance?.requestToggle(target) == true
    }
}
