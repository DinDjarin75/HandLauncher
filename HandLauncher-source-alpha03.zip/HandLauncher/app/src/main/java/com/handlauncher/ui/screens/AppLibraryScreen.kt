package com.handlauncher.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Velocity
import androidx.compose.ui.unit.dp
import com.handlauncher.domain.AppCategory
import com.handlauncher.domain.AppEntry
import com.handlauncher.ui.components.AppIcon
import kotlin.math.abs

@Composable
fun AppLibraryScreen(
    apps: List<AppEntry>,
    categories: List<AppCategory>,
    selectedCategoryId: String,
    onSelectCategory: (String) -> Unit,
    onLaunch: (AppEntry) -> Unit,
    onEditCategories: () -> Unit,
    onDismiss: () -> Unit,
) {
    BackHandler(onBack = onDismiss)
    val selectedCategory = categories.firstOrNull { it.id == selectedCategoryId }
    val visibleApps = apps.filter { it.categoryId == selectedCategoryId }
    val gridState = rememberLazyGridState()
    val dismissThreshold = with(LocalDensity.current) { 84.dp.toPx() }
    var downwardPull by remember(selectedCategoryId) { mutableFloatStateOf(0f) }

    val nestedConnection = remember(selectedCategoryId, dismissThreshold) {
        object : NestedScrollConnection {
            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                if (!gridState.canScrollBackward && available.y > 0f) {
                    downwardPull += available.y
                } else if (available.y < 0f) {
                    downwardPull = 0f
                }
                return Offset.Zero
            }

            override suspend fun onPreFling(available: Velocity): Velocity {
                if (!gridState.canScrollBackward && (downwardPull >= dismissThreshold || available.y > 1500f)) {
                    downwardPull = 0f
                    onDismiss()
                } else {
                    downwardPull = 0f
                }
                return Velocity.Zero
            }
        }
    }

    val transparency = selectedCategory?.backgroundTransparencyPercent ?: 38
    val backgroundAlpha = (1f - transparency.coerceIn(0, 90) / 100f).coerceIn(0.10f, 1f)

    Surface(
        Modifier.fillMaxSize().nestedScroll(nestedConnection),
        color = MaterialTheme.colorScheme.background.copy(alpha = backgroundAlpha),
    ) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(top = 8.dp)) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(selectedCategory?.name ?: "Apps", style = MaterialTheme.typography.headlineMedium, modifier = Modifier.weight(1f))
                IconButton(onClick = onEditCategories) { Icon(Icons.Rounded.Tune, contentDescription = "Edit categories") }
                IconButton(onClick = onDismiss) { Icon(Icons.Rounded.Close, contentDescription = "Home") }
            }

            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 14.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                categories.forEach { category ->
                    FilterChip(
                        selected = category.id == selectedCategoryId,
                        onClick = { onSelectCategory(category.id) },
                        label = { Text(category.name) },
                    )
                }
            }

            Spacer(Modifier.height(12.dp))
            LazyVerticalGrid(
                state = gridState,
                columns = GridCells.Adaptive(78.dp),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                modifier = Modifier.fillMaxSize(),
            ) {
                items(visibleApps, key = { it.stableId }) { app ->
                    AppIcon(app, onClick = { onLaunch(app) })
                }
            }
        }
    }
}
