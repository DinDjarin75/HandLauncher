package com.handlauncher.data

import android.content.Context
import android.util.Xml
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.xmlpull.v1.XmlPullParser
import java.net.HttpURLConnection
import java.net.URL
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

data class NewsHeadline(
    val title: String,
    val url: String,
    val source: String = "",
    val publishedAtMillis: Long? = null,
)

data class NewsState(
    val headlines: List<NewsHeadline> = emptyList(),
    val available: Boolean = false,
    val lastUpdatedMillis: Long? = null,
    val message: String? = null,
)

/**
 * Lightweight, local-first headline provider for the briefing surface.
 * The first alpha uses a Luxembourg-localized Google News RSS endpoint so no API key
 * or tracking SDK is required. The provider boundary can later expose user-selected
 * regional/topic feeds without changing the briefing UI.
 */
class NewsRepository(@Suppress("UNUSED_PARAMETER") context: Context) {
    suspend fun refresh(): NewsState = withContext(Dispatchers.IO) {
        runCatching {
            val connection = (URL(FEED_URL).openConnection() as HttpURLConnection).apply {
                connectTimeout = 8_000
                readTimeout = 10_000
                requestMethod = "GET"
                setRequestProperty("User-Agent", "HandLauncher/1.0")
            }
            connection.inputStream.buffered().use { input ->
                val parser = Xml.newPullParser().apply {
                    setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
                    setInput(input, null)
                }
                val items = parse(parser).take(10)
                NewsState(
                    headlines = items,
                    available = items.isNotEmpty(),
                    lastUpdatedMillis = System.currentTimeMillis(),
                    message = if (items.isEmpty()) "No headlines available" else null,
                )
            }
        }.getOrElse {
            NewsState(message = "Headlines unavailable")
        }
    }

    private fun parse(parser: XmlPullParser): List<NewsHeadline> {
        val results = mutableListOf<NewsHeadline>()
        var event = parser.eventType
        var inItem = false
        var currentTag: String? = null
        var title = ""
        var link = ""
        var source = ""
        var published: Long? = null

        while (event != XmlPullParser.END_DOCUMENT && results.size < 12) {
            when (event) {
                XmlPullParser.START_TAG -> {
                    currentTag = parser.name
                    if (parser.name.equals("item", ignoreCase = true)) {
                        inItem = true
                        title = ""
                        link = ""
                        source = ""
                        published = null
                    }
                }
                XmlPullParser.TEXT -> if (inItem) {
                    val value = parser.text?.trim().orEmpty()
                    if (value.isNotBlank()) {
                        when (currentTag?.lowercase(Locale.ROOT)) {
                            "title" -> title += value
                            "link" -> link += value
                            "source" -> source += value
                            "pubdate" -> published = parseDate(value)
                        }
                    }
                }
                XmlPullParser.END_TAG -> {
                    if (parser.name.equals("item", ignoreCase = true)) {
                        if (title.isNotBlank() && link.isNotBlank()) {
                            results += NewsHeadline(
                                title = title.trim(),
                                url = link.trim(),
                                source = source.trim(),
                                publishedAtMillis = published,
                            )
                        }
                        inItem = false
                    }
                    currentTag = null
                }
            }
            event = parser.next()
        }
        return results
    }

    private fun parseDate(raw: String): Long? = runCatching {
        ZonedDateTime.parse(raw, DateTimeFormatter.RFC_1123_DATE_TIME).toInstant().toEpochMilli()
    }.getOrNull()

    companion object {
        private const val FEED_URL = "https://news.google.com/rss?hl=en-LU&gl=LU&ceid=LU:en"
    }
}
