# Changelog

## 1.0.0-alpha03 — Contrast + Briefing
- Adaptive wallpaper readability now samples the upper wallpaper instead of relying only on global wallpaper hints.
- Direct app labels keep an opposite-color shadow for readability across mixed bright/dark wallpaper regions.
- Smart Stacks now navigate horizontally: swipe left for next, swipe right for previous.
- Smart Stacks wrap continuously at both ends and support automatic looping; contextual promotion temporarily pauses looping without losing the user's position.
- Stack editor exposes the auto-loop toggle and horizontal ordering controls.
- Left page rebuilt as a personal briefing surface with greeting, current weather, four-day forecast, phone battery, next Calendar event, contextual suggestions and live headlines.
- Headline feed uses a Luxembourg-localized RSS provider with no API key and keeps Google Discover as an optional shortcut.

## 1.0.0-alpha02 — UX refinement
- Smoother, density-aware vertical gestures with resisted motion feedback.
- Swipe down from the top of an App Library category returns Home.
- Per-category background transparency slider and Solid/Tinted/Glass/Clear presets.
- Wallpaper-first theming: AI transparency styles cards/widgets instead of veiling the wallpaper.
- Native Hand Feed replaces the Google Discover placeholder while retaining a Discover shortcut.
- More reliable Samsung/Android default-Home selector.
- Reduced persistent help/tutorial text on primary launcher surfaces.

## 1.0.0-alpha01 — 2026-10-25
- Consolidated the launcher into one declarative, per-display-profile architecture.
- Added real Android HOME registration, app discovery and Home-role request.
- Added swipe-down Search/Command Layer and swipe-up categorized App Library.
- Added Android-category-aware automatic classification plus persisted user overrides.
- Added free-form Home editing, drag/resize, fine positioning, grid snapping and layout locking.
- Added Smart Object tap/swipe/long-press execution and editing.
- Added Home object palette for apps, Hand widgets, Android widgets, Smart Stacks, categories and commands.
- Added real `AppWidgetHost` placement/configuration/removal on the Home canvas.
- Added editable native Clock, Calendar, Weather and Battery widgets.
- Added multi-instance editable Smart Stacks with naming, reorder and contextual promotion rules.
- Added Jetpack Window fold/posture handling and independent external-display desktop layouts.
- Added user-editable Context Automation rules for battery, charging, time, display, audio device, Calendar and rain.
- Added actionable contextual command suggestions.
- Added Open-Meteo weather provider using a manual coarse location.
- Added local AI layout designer plus optional Gemini-backed constrained design generation.
- Added AI theme rendering for light/dark, transparency, corners and typography mood.
- Added Android-Keystore encryption for the optional Gemini key.
- Added JSON backup/restore including weather configuration while excluding AI credentials.
- Added current Android build configuration, JUnit core tests and a GitHub Actions APK build workflow.
- Added gesture arbitration so Home search/library swipes do not steal Smart Object gestures.

## Earlier development snapshots
0.1–0.3 established the initial launcher shell, persistence, AppWidget hosting, Fold profiles, Smart Objects and free-form editor. Those snapshots were folded into the 1.0 alpha source milestone above.
