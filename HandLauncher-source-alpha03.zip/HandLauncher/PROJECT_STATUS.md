# Hand Launcher — Project Status

## Current source milestone
**1.0.0-alpha03 — 25 October 2026**

Hand is a real Android HOME launcher project, not a visual mock-up. Its permanent state is declarative and profile-specific so phone, Fold, landscape and external-display layouts can evolve independently while sharing the same object, search, context and AI engines.

## Implemented in the alpha

### Launcher / navigation
- Android HOME role registration and system role request.
- Installed-app discovery through `LauncherApps` and launch support.
- Refresh after returning Home so installs/removals/updates are reflected.
- Swipe down on empty Home canvas → Search.
- Swipe up on empty Home canvas → category-first App Library.
- Gesture arbitration prevents a Home swipe from stealing a Smart Object's own vertical gesture.
- Left page is a native personal briefing with weather, forecast, Calendar, battery, context suggestions and live headlines; Google Discover remains an optional shortcut.
- Right Workspace surface for context/status.

### Category-first App Library
- No conventional bottom drawer.
- Initial category classification uses Android publisher categories first, then Hand heuristics.
- Editable category names.
- User-created categories.
- Manual app reassignment; user decisions override automatic sorting.
- Searchable independent tags under the visual category model.

### Universal Search / Command Layer
- App search by label, package, tags and category.
- Quick launcher commands for App Library, AI Design, Automations, Add and Settings.
- Results are local-first and open apps directly.

### Declarative Home editor
- Explicit Edit Mode so ordinary use cannot accidentally rearrange Home.
- Drag and resize objects.
- Fine positioning or grid snapping.
- Layout lock/unlock.
- Normalized geometry survives different display sizes.
- Add palette supports apps, Hand widgets, Android widgets, Smart Stacks, category objects and commands.
- Remove/edit controls are part of Edit Mode.

### Smart Objects
- Shared model for apps, folders/category objects, native widgets, Android widgets, Smart Stacks, shortcuts and commands.
- Per-object tap, swipe-up, swipe-down and long-press action slots.
- Per-app Smart Object label/action editor.
- Smart Object actions execute directly from Home.

### Hand-native widgets
- Digital clock with minimal/standard/detailed variants, optional date and seconds.
- Calendar/date widget with event-aware state when Calendar access is granted.
- Weather widget backed by Open-Meteo using a user-selected coarse location (no continuous location permission required).
- Battery widget with live phone state plus connected audio-device awareness; accessory percentages are displayed only where Android/device providers make them available.
- Native widget appearance editor.

### Smart Stacks
- Multiple independently persisted Smart Stacks.
- Editable stack names.
- Add/remove native widgets.
- Reorder stack contents.
- Manual horizontal paging (left/right), wrap-around navigation and optional automatic looping.
- Context-aware promotion toggle.
- Per-widget permission to be contextually promoted.
- Context promotion never changes the saved order.

### Android widgets
- Real `AppWidgetHost`.
- System widget picker and provider configuration flow.
- Durable widget IDs.
- Third-party widgets can be placed directly on the free-form Home canvas and resized.
- Widget size options update as the canvas object changes size.
- Removing a hosted widget deallocates its ID.

### Fold / orientation / desktop
Independent profiles:
- cover display
- unfolded / inner Fold
- portrait phone
- landscape phone
- external display

Resolution uses window dimensions plus Jetpack Window `FoldingFeature` data. External-display mode uses the same declarative editor but a dedicated desktop shell/navigation rail.

### Context Automation
User-editable rules can combine:
- battery threshold
- charging state
- time window, including overnight ranges
- display profile
- connected audio-device name
- upcoming Calendar event
- incoming rain

Current effects:
- promote an eligible Smart Stack widget
- surface a contextual command suggestion
- data model for temporary Smart Object surfacing

Rules are persisted and evaluated without rewriting permanent layout state.

### AI layout + theme generation
- Local deterministic designer works without a cloud account/key.
- Optional Gemini-backed design provider.
- Gemini returns only a constrained JSON design plan; Hand composes the actual layout itself.
- Preview before Apply.
- AI layouts persist independently by display profile.
- AI themes currently affect dark/light mode, transparency, widget corner radius and typography mood.
- Gemini key is encrypted with Android Keystore and excluded from backups.
- Default cloud model setting: `gemini-3.8-flash` (editable in Settings).

### Backup / restore
JSON backup includes:
- categories and assignments
- layouts for every profile
- Smart Objects
- Smart Stacks
- hosted-widget ID state
- automations
- AI-generated theme state
- coarse weather location

AI credentials are intentionally excluded.

### Reproducible build path
- Current AGP / Compose project files.
- GitHub Actions workflow runs unit tests, builds the debug APK and publishes it as an artifact.
- `BUILDING.md` documents Android Studio and cloud-build paths.

## Local validation completed in this runtime
- Balanced Kotlin source structure check across the project.
- Platform-independent domain/search/context sources compile with local `kotlinc`.
- Core search and context behavior has dedicated JUnit tests in the project.

## Platform-gated / not honestly claimable as complete

### Google Discover
Google does not provide a normal public third-party launcher API for embedding the Pixel/Google Discover surface. Hand therefore owns the left-page experience with its native briefing surface and retains a Google-app shortcut. A companion bridge can still be added later without coupling the launcher core to undocumented behavior.

### Accessory battery percentages
Android does not expose one universal public API that reliably returns phone + watch + earbuds + case battery levels across manufacturers. Hand shows what it can obtain without inventing values; provider-specific integrations can be layered in later.

### APK assembly in this chat runtime
This runtime has JDK/Kotlin but no Android SDK, Android platform jar or Gradle distribution, and binary downloads are unavailable. Therefore an APK cannot be truthfully claimed as locally assembled here. The included GitHub workflow/Android Studio project is the reproducible build route.
