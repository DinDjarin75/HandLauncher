# Validation report — Hand Launcher 1.0.0-alpha03

Date: 25 October 2026

Completed in the current runtime:
- Android manifest and resource XML parsed successfully.
- GitHub Actions workflow YAML parsed successfully.
- Kotlin delimiter/structure scan completed across project sources.
- Android-independent domain, Search and Context engine sources compiled successfully with local `kotlinc`.
- Core JUnit tests are included for search ranking and contextual rule behavior; the cloud build workflow runs them before APK assembly.
- Source checked for embedded Gemini/API credentials; none are included.

Not possible in this runtime:
- Android/Compose compilation and APK assembly, because no Android SDK/platform jar or Gradle distribution is installed and binary downloads are unavailable.

The included GitHub Actions workflow provides the reproducible clean build path: Android SDK 37 + Java 17 + Gradle 9.6 -> unit tests -> `:app:assembleDebug` -> uploaded `app-debug.apk` artifact.
