package com.handlauncher

import android.Manifest
import android.app.role.RoleManager
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.content.ContentUris
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.net.Uri
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.core.view.WindowCompat
import androidx.window.layout.WindowInfoTracker
import com.handlauncher.platform.AndroidWidgetHostController
import com.handlauncher.platform.DisplayProfileDetector
import com.handlauncher.ui.LauncherRoot
import com.handlauncher.ui.theme.HandLauncherTheme
import com.handlauncher.ui.theme.resolveWallpaperDarkPalette
import kotlinx.coroutines.flow.collectLatest

class MainActivity : ComponentActivity() {
    private val viewModel: LauncherViewModel by viewModels()
    private lateinit var widgetHostController: AndroidWidgetHostController
    private var pendingWidgetId: Int? = null

    private val calendarPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        viewModel.onCalendarPermissionResult()
    }

    private val createBackup = registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) runCatching {
            contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(viewModel.exportBackupJson()) }
        }
    }

    private val restoreBackup = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) runCatching {
            val raw = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: return@runCatching
            viewModel.importBackupJson(raw)
        }
    }

    private val configureWidget = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val fallback = pendingWidgetId ?: return@registerForActivityResult
        val id = AndroidWidgetHostController.widgetIdFromResult(result.data, fallback)
        if (AndroidWidgetHostController.resultSucceeded(result.resultCode)) viewModel.addAndroidWidget(id)
        else widgetHostController.deleteId(id)
        pendingWidgetId = null
    }

    private val pickWidget = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val fallback = pendingWidgetId ?: return@registerForActivityResult
        val id = AndroidWidgetHostController.widgetIdFromResult(result.data, fallback)
        if (!AndroidWidgetHostController.resultSucceeded(result.resultCode)) {
            widgetHostController.deleteId(id)
            pendingWidgetId = null
            return@registerForActivityResult
        }
        val configureIntent = widgetHostController.createConfigureIntent(id)
        if (configureIntent != null) configureWidget.launch(configureIntent)
        else {
            viewModel.addAndroidWidget(id)
            pendingWidgetId = null
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        widgetHostController = AndroidWidgetHostController(this)

        setContent {
            val state by viewModel.state.collectAsStateWithLifecycle()
            val detector = DisplayProfileDetector(this)

            LaunchedEffect(Unit) {
                viewModel.setProfile(detector.resolve(this@MainActivity))
                WindowInfoTracker.getOrCreate(this@MainActivity)
                    .windowLayoutInfo(this@MainActivity)
                    .collectLatest { info -> viewModel.setProfile(detector.resolve(this@MainActivity, info)) }
            }

            val darkTheme = resolveWallpaperDarkPalette(this@MainActivity, state.activeTheme?.dark ?: true)
            SideEffect {
                WindowCompat.getInsetsController(window, window.decorView).apply {
                    isAppearanceLightStatusBars = !darkTheme
                    isAppearanceLightNavigationBars = !darkTheme
                }
            }

            HandLauncherTheme(theme = state.activeTheme) {
                LauncherRoot(
                    state = state,
                    viewModel = viewModel,
                    requestHomeRole = ::requestHomeRole,
                    isHomeRoleHeld = isHomeRoleHeld(),
                    widgetHostController = widgetHostController,
                    onAddAndroidWidget = ::beginWidgetPick,
                    onRemoveAndroidWidget = { id ->
                        widgetHostController.deleteId(id)
                        viewModel.removeAndroidWidget(id)
                    },
                    onRequestCalendarPermission = { calendarPermission.launch(Manifest.permission.READ_CALENDAR) },
                    onExportBackup = { createBackup.launch("hand-launcher-backup.json") },
                    onImportBackup = { restoreBackup.launch(arrayOf("application/json", "text/plain")) },
                    onOpenGoogleFeed = ::openGoogleFeed,
                    onOpenExternalUrl = ::openExternalUrl,
                    onOpenClock = ::openClock,
                    onOpenCalendar = ::openCalendarEvent,
                    onOpenCalendarApp = ::openCalendarApp,
                    onOpenWeather = ::openWeather,
                    onOpenBattery = ::openBattery,
                    onOpenMedia = ::openMedia,
                    onOpenMediaAccess = ::openMediaAccess,
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Keep categories/search current after installs, removals and app updates.
        viewModel.refreshApps()
    }

    override fun onStart() {
        super.onStart()
        runCatching { widgetHostController.startListening() }
    }

    override fun onStop() {
        runCatching { widgetHostController.stopListening() }
        super.onStop()
    }

    private fun beginWidgetPick() {
        val id = widgetHostController.allocateId()
        pendingWidgetId = id
        pickWidget.launch(widgetHostController.createSystemPickerIntent(id))
    }

    private fun isHomeRoleHeld(): Boolean {
        val manager = getSystemService(RoleManager::class.java)
        return manager.isRoleAvailable(RoleManager.ROLE_HOME) && manager.isRoleHeld(RoleManager.ROLE_HOME)
    }

    private fun requestHomeRole() {
        // Samsung/One UI is more reliable when the launcher opens Android's actual
        // default-Home picker instead of depending only on the ROLE_HOME dialog.
        val homeSettings = Intent(Settings.ACTION_HOME_SETTINGS)
        if (homeSettings.resolveActivity(packageManager) != null) {
            startActivity(homeSettings)
            return
        }

        val manager = getSystemService(RoleManager::class.java)
        if (manager.isRoleAvailable(RoleManager.ROLE_HOME) && !manager.isRoleHeld(RoleManager.ROLE_HOME)) {
            runCatching { startActivity(manager.createRequestRoleIntent(RoleManager.ROLE_HOME)) }
        }
    }

    private fun openGoogleFeed() {
        val launch = packageManager.getLaunchIntentForPackage("com.google.android.googlequicksearchbox")
        if (launch != null) startActivity(launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun safeStartActivity(intent: Intent): Boolean = runCatching {
        val resolved = intent.resolveActivity(packageManager) ?: return@runCatching false
        intent.component = resolved
        startActivity(intent)
        true
    }.getOrDefault(false)

    private fun openClock() {
        // Use Android's public alarm contract first. Some Samsung builds advertise
        // a packaged SHOW_ALARMS handler that is not safe to invoke directly.
        val alarms = Intent(AlarmClock.ACTION_SHOW_ALARMS)
            .addCategory(Intent.CATEGORY_DEFAULT)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (safeStartActivity(alarms)) return

        // If no app exposes SHOW_ALARMS, open the installed Clock app itself.
        listOf("com.sec.android.app.clockpackage", "com.google.android.deskclock").forEach { packageName ->
            packageManager.getLaunchIntentForPackage(packageName)?.let { launch ->
                if (safeStartActivity(launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))) return
            }
        }
    }

    private fun openCalendarApp() {
        val samsungCalendar = packageManager.getLaunchIntentForPackage("com.samsung.android.calendar")
        if (samsungCalendar != null && safeStartActivity(samsungCalendar.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))) return

        val generic = Intent(
            Intent.ACTION_VIEW,
            CalendarContract.CONTENT_URI.buildUpon()
                .appendPath("time")
                .appendPath(System.currentTimeMillis().toString())
                .build(),
        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        safeStartActivity(generic)
    }

    private fun openCalendarEvent() {
        val event = viewModel.state.value.nextCalendarEvent
        val intent = if (event != null) {
            Intent(Intent.ACTION_VIEW).apply {
                data = ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI, event.eventId)
                putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, event.beginMillis)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
        } else {
            Intent(
                Intent.ACTION_VIEW,
                CalendarContract.CONTENT_URI.buildUpon()
                    .appendPath("time")
                    .appendPath(System.currentTimeMillis().toString())
                    .build(),
            ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        if (!safeStartActivity(intent)) openCalendarApp()
    }

    private fun openWeather() {
        val samsungWeather = packageManager.getLaunchIntentForPackage("com.sec.android.daemonapp")
        if (samsungWeather != null) {
            runCatching { startActivity(samsungWeather.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }.onSuccess { return }
        }
        val label = viewModel.state.value.weather.location.label.ifBlank { "Luxembourg" }
        openExternalUrl("https://www.google.com/search?q=" + Uri.encode("weather $label"))
    }

    private fun openBattery() {
        val primary = Intent(Intent.ACTION_POWER_USAGE_SUMMARY)
            .setPackage("com.android.settings")
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (safeStartActivity(primary)) return

        val generic = Intent(Intent.ACTION_POWER_USAGE_SUMMARY).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (safeStartActivity(generic)) return

        safeStartActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun openMedia() {
        val media = viewModel.state.value.media
        if (media.needsAccess) {
            openMediaAccess()
            return
        }
        val packageName = media.packageName ?: return
        packageManager.getLaunchIntentForPackage(packageName)?.let { launch ->
            runCatching { startActivity(launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        }
    }

    private fun openMediaAccess() {
        runCatching { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
    }

    private fun openExternalUrl(url: String) {
        runCatching {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }
}
