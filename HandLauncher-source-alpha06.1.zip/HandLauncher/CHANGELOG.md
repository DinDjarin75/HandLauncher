# Changelog

## 1.0.0-alpha06.1

- Hotfix external widget destinations so Clock and Calendar event taps cannot crash the launcher.
- Restore the generic Android SHOW_ALARMS contract with safe Clock-app fallback.
- Restore the alpha05 calendar-event launch behavior with guarded Calendar fallback.
- Replace Google News wrapper feeds with merged direct publisher RSS feeds that expose article imagery.
- Prefer image-bearing stories while preserving recency and resolve missing images from publisher OpenGraph/content.

## 1.0.0-alpha06

- Anchored the default Smart Stack directly below the status-bar safe area on Home.
- Consolidated Automations, Settings, Edit and AI controls into one widget-matched glass capsule positioned below the Smart Stack at the right edge.
- Persisted the last viewed permanent Smart Stack widget per display profile and stack, including across launcher restarts.
- Removed Smart Stack page/navigation indicators.
- Corrected Clock navigation to prefer the device alarm list (including Samsung Clock) instead of Date & Time settings.
- Corrected Battery navigation to open the top-level Battery settings screen rather than Battery Saver.
- Split Calendar interactions: the CALENDAR header opens the Calendar app while the event row opens that exact event.
- Added shared native weather graphics to the Smart Stack weather widget and Brief current/forecast weather surfaces.

## 1.0.0-alpha05

- Added direct left/right paging between App Library categories with synchronized category chips.
- Smart Stack auto-loop is decoupled from generic context rules; Clock, Weather and Battery are permanent core widgets.
- Added contextual media player for active music/podcast sessions, including artwork, metadata, play/pause, previous/next and app launch.
- Made native Smart Stack widgets actionable: Clock opens alarms, Calendar opens the relevant event/day, Weather opens weather, Battery opens battery settings.
- Added whole-Brief automatic refresh every 30 minutes and manual full-page refresh.
- Added collapsible Headlines, Entertainment, Tech and LEGO sections, each with five latest stories and identical glass/card treatment.
- Improved article-image resolution and image loading fallbacks while preserving the 20/80 image/text card layout.
- Removed workshop/technical labels from everyday UI and migrated legacy auto-seeded Home app objects away.

## 1.0.0-alpha04

- Unified Brief modules and native widgets on the same translucent glass surface.
- Finished high-contrast foreground treatment for wallpaper-facing launcher UI and native widget content.
- Removed arbitrary installed-app population from a fresh Home; users add apps intentionally.
- Added 20/80 image/text headline cards with lead-image discovery from feed media and article OpenGraph/Twitter metadata.
- Humanized calendar timing (for example, Tomorrow · 15:35 instead of large minute counts).

## 1.0.0-alpha03 — Contrast + Briefing
- Adaptive wallpaper readability now samples the upper wallpaper instead of relying only on global wallpaper hints.
- Direct app labels keep an opposite-color shadow for readability across mixed bright/dark wallpaper regions.
- Smart Stacks now navigate horizontally: swipe left for next, swipe right for previous.
- Smart Stacks wrap continuously at both ends and support automatic looping; contextual promotion temporarily pauses looping without losing the user's position.
- Stack editor exposes the auto-loop toggle and horizontal ordering controls.
- Left page rebuilt as a personal briefing surface with greeting, current weather, four-day forecast, phone battery, next Calendar event, contextual suggestions and live headlines.
- Headline feed uses a Luxembourg-localized RSS provider with no API key and keeps Google Discover as an optional shortcut.

## 1.0.0-alpha02 — UX refinement
- Smoother, density-aware vertical gestures with resisted motion feedback.
- Swipe down from the top of an App Library category returns Home.
- Per-category background transparency slider and Solid/Tinted/Glass/Clear presets.
- Wallpaper-first theming: AI transparency styles cards/widgets instead of veiling the wallpaper.
- Native Hand Feed replaces the Google Discover placeholder while retaining a Discover shortcut.
- More reliable Samsung/Android default-Home selector.
- Reduced persistent help/tutorial text on primary launcher surfaces.

## 1.0.0-alpha01 — 2026-10-25
- Consolidated the launcher into one declarative, per-display-profile architecture.
- Added real Android HOME registration, app discovery and Home-role request.
- Added swipe-down Search/Command Layer and swipe-up categorized App Library.
- Added Android-category-aware automatic classification plus persisted user overrides.
- Added free-form Home editing, drag/resize, fine positioning, grid snapping and layout locking.
- Added Smart Object tap/swipe/long-press execution and editing.
- Added Home object palette for apps, Hand widgets, Android widgets, Smart Stacks, categories and commands.
- Added real `AppWidgetHost` placement/configuration/removal on the Home canvas.
- Added editable native Clock, Calendar, Weather and Battery widgets.
- Added multi-instance editable Smart Stacks with naming, reorder and contextual promotion rules.
- Added Jetpack Window fold/posture handling and independent external-display desktop layouts.
- Added user-editable Context Automation rules for battery, charging, time, display, audio device, Calendar and rain.
- Added actionable contextual command suggestions.
- Added Open-Meteo weather provider using a manual coarse location.
- Added local AI layout designer plus optional Gemini-backed constrained design generation.
- Added AI theme rendering for light/dark, transparency, corners and typography mood.
- Added Android-Keystore encryption for the optional Gemini key.
- Added JSON backup/restore including weather configuration while excluding AI credentials.
- Added current Android build configuration, JUnit core tests and a GitHub Actions APK build workflow.
- Added gesture arbitration so Home search/library swipes do not steal Smart Object gestures.

## Earlier development snapshots
0.1–0.3 established the initial launcher shell, persistence, AppWidget hosting, Fold profiles, Smart Objects and free-form editor. Those snapshots were folded into the 1.0 alpha source milestone above.
