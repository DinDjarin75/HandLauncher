# Building Hand Launcher

## Android Studio

1. Open this folder as a Gradle project in a current Android Studio release.
2. Use JDK 17.
3. Allow Gradle to sync and download Android SDK 36 / Build Tools required by AGP 9.4.
4. Build **app > assembleDebug** or use **Build > Build APK(s)**.
5. The debug APK is produced at `app/build/outputs/apk/debug/app-debug.apk`.

## GitHub Actions

The included `.github/workflows/build-apk.yml` performs a clean debug build with Java 17 and Gradle 9.6 and publishes `hand-launcher-debug-apk` as a workflow artifact.

## First launch

Install the APK, open Hand Launcher once, then use **Hand settings > Set Hand as Home**. Android will show the system Home-app chooser/role request.

## Gemini design provider

The launcher works without a cloud AI key using its local layout designer. To enable Gemini-backed layout/theme generation, enter your own Gemini API key in **Hand settings > AI designer**. The key is encrypted using Android Keystore and excluded from Hand's JSON backups.
