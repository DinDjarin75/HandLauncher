# Validation report — BOAL Launcher 1.0.0-beta1.5-fix2

Date: 26 October 2026

Completed in the current runtime:
- Notification capture/filter path diffed against beta1.4; no capture regression was introduced by beta1.5.
- Root cause identified as notification-listener access being able to disappear across fresh debug-APK installs while the launcher previously failed silently.
- Added `notificationAccessGranted` state sourced from Android's `NotificationManager.isNotificationListenerAccessGranted`.
- Home now renders an explicit recovery capsule with an Enable action when access is missing.
- When access exists but the listener service is not connected, BOAL explicitly requests a NotificationListenerService rebind.
- Notification click path moved out of NotificationListenerService and into the visible MainActivity; the original notification content/full-screen PendingIntent is retained in the in-memory model.
- Android 14+ PendingIntent dispatch supplies ActivityOptions pending-intent background-start mode; Android 16 uses ALLOW_IF_VISIBLE while API 34-35 uses the legacy ALLOWED mode.
- Notification row uses one full-width click target with the dedicated dismiss button nested as its own control; successful opens cancel the mirrored notification.
- Added persistent GitHub Actions cache for `~/.android/debug.keystore`, with key generation only on the first cache miss.
- Beta1.5-fix2 version code/name verified (`25` / `1.0.0-beta1.5-fix2`).
- Android manifest/resource XML parse successfully.
- Source manifest regenerated from the packaged beta1.5-fix2 tree.

Important migration note:
- Because beta1.5-fix1 was built before stable signing-key persistence existed, beta1.5-fix2 establishes a new stable debug signing identity. One final uninstall/install may be required. After that, subsequent builds using the cached `boal-debug-keystore-v1` key should update in place and retain notification/media listener grants.

Authoritative Android/Compose validation remains GitHub Actions: Java 17 + Android 36 + Gradle 9.6 -> unit tests -> `:app:assembleDebug` -> APK artifact.
