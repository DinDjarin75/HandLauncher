# Validation report — BOAL Launcher 1.0.0-alpha07

Date: 26 October 2026

Completed in the current runtime:
- Android manifest and resource XML parsed successfully.
- Kotlin delimiter/structure checks completed across modified launcher sources.
- Alpha07 version code/name verified.
- Notification listener declares notification/media access and filters non-clearable, ongoing, foreground-service and group-summary entries.
- Notification capsule is conditionally composed only when eligible notifications exist.
- Standard icon-pack appfilter.xml resolver and package-visibility queries are included.
- Source scan found no embedded API keys or signing material.

GitHub Actions run #30 reached Kotlin compilation and identified one variance-only type mismatch in the notification listener (`Array<out StatusBarNotification>` vs invariant `Array<StatusBarNotification>`). The listener helper has been corrected to accept the platform-provided covariant array; no feature behavior changed.

Authoritative Android/Compose validation remains GitHub Actions: Java 17 + Android 36 + Gradle 9.6 -> unit tests -> :app:assembleDebug -> APK artifact.
