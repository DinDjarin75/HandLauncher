package com.handlauncher.data

import com.handlauncher.platform.LauncherNotificationListener
import kotlinx.coroutines.flow.StateFlow

data class LauncherNotification(
    val key: String,
    val packageName: String,
    val title: String,
    val text: String,
    val postTime: Long,
)

class NotificationRepository {
    val notifications: StateFlow<List<LauncherNotification>> = LauncherNotificationListener.notifications

    fun dismiss(key: String) = LauncherNotificationListener.dismiss(key)
    fun open(key: String) = LauncherNotificationListener.open(key)
}
