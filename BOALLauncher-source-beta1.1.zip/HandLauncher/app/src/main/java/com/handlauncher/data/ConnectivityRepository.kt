package com.handlauncher.data

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.telephony.TelephonyManager

/** Snapshot used by the native Connectivity Smart Stack card.
 * All platform reads are defensive: OEMs and Android privacy policy may redact
 * a field; the launcher degrades the individual value rather than the card.
 */
data class ConnectivityState(
    val wifiConnected: Boolean = false,
    val wifiName: String = "Wi-Fi",
    val wifiSpeedMbps: Int? = null,
    val mobileType: String = "Mobile",
    val operatorName: String = "Mobile network",
    val mobileSignalLevel: Int? = null,
    val bluetoothDeviceNames: Set<String> = emptySet(),
)

class ConnectivityRepository(private val context: Context) {
    private val connectivity = context.getSystemService(ConnectivityManager::class.java)
    private val wifi = context.applicationContext.getSystemService(WifiManager::class.java)
    private val telephony = context.getSystemService(TelephonyManager::class.java)

    fun snapshot(bluetoothDeviceNames: Set<String>): ConnectivityState {
        val activeCaps = runCatching {
            connectivity.activeNetwork?.let(connectivity::getNetworkCapabilities)
        }.getOrNull()

        val wifiConnected = activeCaps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
        val wifiInfo = activeCaps?.transportInfo as? WifiInfo
        val legacyWifiInfo = runCatching { wifi.connectionInfo }.getOrNull()
        val rawSsid = wifiInfo?.ssid ?: legacyWifiInfo?.ssid
        val wifiName = rawSsid
            ?.removeSurrounding("\"")
            ?.takeUnless { it.isBlank() || it.equals(WifiManager.UNKNOWN_SSID, true) || it == "<unknown ssid>" }
            ?: if (wifiConnected) "Connected Wi-Fi" else "Not connected"

        val linkSpeed = sequenceOf(
            wifiInfo?.linkSpeed,
            legacyWifiInfo?.linkSpeed,
            activeCaps?.linkDownstreamBandwidthKbps?.takeIf { it > 0 }?.div(1000),
        ).filterNotNull().firstOrNull { it > 0 }

        val networkType = runCatching { telephony.dataNetworkType }.getOrDefault(TelephonyManager.NETWORK_TYPE_UNKNOWN)
        val mobileType = mobileGeneration(networkType)
        val operator = runCatching { telephony.networkOperatorName }
            .getOrNull()
            ?.takeIf { it.isNotBlank() }
            ?: "Mobile network"

        val telephonyLevel = runCatching { telephony.signalStrength?.level }.getOrNull()
        val activeCellLevel = if (activeCaps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true) {
            signalDbmToLevel(activeCaps.signalStrength)
        } else null

        return ConnectivityState(
            wifiConnected = wifiConnected,
            wifiName = wifiName,
            wifiSpeedMbps = linkSpeed,
            mobileType = mobileType,
            operatorName = operator,
            mobileSignalLevel = telephonyLevel?.coerceIn(0, 4) ?: activeCellLevel,
            bluetoothDeviceNames = bluetoothDeviceNames,
        )
    }

    private fun signalDbmToLevel(dbm: Int): Int? {
        if (dbm == NetworkCapabilities.SIGNAL_STRENGTH_UNSPECIFIED) return null
        return when {
            dbm >= -85 -> 4
            dbm >= -95 -> 3
            dbm >= -105 -> 2
            dbm >= -115 -> 1
            else -> 0
        }
    }

    private fun mobileGeneration(type: Int): String = when (type) {
        TelephonyManager.NETWORK_TYPE_NR -> "5G"
        TelephonyManager.NETWORK_TYPE_LTE -> "4G"
        TelephonyManager.NETWORK_TYPE_HSPAP,
        TelephonyManager.NETWORK_TYPE_HSPA,
        TelephonyManager.NETWORK_TYPE_HSUPA,
        TelephonyManager.NETWORK_TYPE_HSDPA,
        TelephonyManager.NETWORK_TYPE_UMTS -> "3G"
        TelephonyManager.NETWORK_TYPE_EDGE,
        TelephonyManager.NETWORK_TYPE_GPRS,
        TelephonyManager.NETWORK_TYPE_CDMA,
        TelephonyManager.NETWORK_TYPE_1xRTT -> "2G"
        else -> "Mobile"
    }
}
