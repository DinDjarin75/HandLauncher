package com.handlauncher.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Velocity
import androidx.compose.ui.unit.dp
import com.handlauncher.domain.AppCategory
import com.handlauncher.domain.AppEntry
import com.handlauncher.ui.components.AppIcon
import kotlinx.coroutines.launch

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppLibraryScreen(
    apps: List<AppEntry>,
    categories: List<AppCategory>,
    selectedCategoryId: String,
    onSelectCategory: (String) -> Unit,
    onLaunch: (AppEntry) -> Unit,
    onEditCategories: () -> Unit,
    onDismiss: () -> Unit,
) {
    BackHandler(onBack = onDismiss)
    if (categories.isEmpty()) return

    val initial = categories.indexOfFirst { it.id == selectedCategoryId }.coerceAtLeast(0)
    val pagerState = rememberPagerState(initialPage = initial, pageCount = { categories.size })
    val scope = rememberCoroutineScope()
    val dismissThreshold = with(LocalDensity.current) { 84.dp.toPx() }
    val currentCategory = categories.getOrNull(pagerState.currentPage) ?: categories.first()
    val backgroundAlpha = (1f - currentCategory.backgroundTransparencyPercent.coerceIn(0, 90) / 100f).coerceIn(0.10f, 1f)

    LaunchedEffect(selectedCategoryId, categories) {
        val target = categories.indexOfFirst { it.id == selectedCategoryId }
        if (target >= 0 && target != pagerState.currentPage && !pagerState.isScrollInProgress) pagerState.scrollToPage(target)
    }
    LaunchedEffect(pagerState) {
        snapshotFlow { pagerState.currentPage }.collect { page ->
            categories.getOrNull(page)?.id?.let(onSelectCategory)
        }
    }

    Surface(
        Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background.copy(alpha = backgroundAlpha),
        contentColor = Color.White,
    ) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(top = 8.dp)) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(currentCategory.name, style = MaterialTheme.typography.headlineMedium, modifier = Modifier.weight(1f))
                IconButton(onClick = onEditCategories) { Icon(Icons.Rounded.Tune, contentDescription = "Edit categories") }
                IconButton(onClick = onDismiss) { Icon(Icons.Rounded.Close, contentDescription = "Home") }
            }

            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 14.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                categories.forEachIndexed { index, category ->
                    FilterChip(
                        selected = index == pagerState.currentPage,
                        onClick = { scope.launch { pagerState.animateScrollToPage(index) } },
                        label = { Text(category.name) },
                    )
                }
            }

            Spacer(Modifier.height(12.dp))
            HorizontalPager(
                state = pagerState,
                modifier = Modifier.fillMaxSize(),
                beyondViewportPageCount = 1,
            ) { page ->
                val category = categories[page]
                val visibleApps = remember(apps, category.id) { apps.filter { it.categoryId == category.id } }
                val gridState = rememberLazyGridState()
                var downwardPull by remember(category.id) { mutableFloatStateOf(0f) }
                val nestedConnection = remember(category.id, dismissThreshold, gridState) {
                    object : NestedScrollConnection {
                        override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                            if (!gridState.canScrollBackward && available.y > 0f) downwardPull += available.y
                            else if (available.y < 0f) downwardPull = 0f
                            return Offset.Zero
                        }
                        override suspend fun onPreFling(available: Velocity): Velocity {
                            if (!gridState.canScrollBackward && (downwardPull >= dismissThreshold || available.y > 1500f)) onDismiss()
                            downwardPull = 0f
                            return Velocity.Zero
                        }
                    }
                }

                LazyVerticalGrid(
                    state = gridState,
                    columns = GridCells.Adaptive(78.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier.fillMaxSize().nestedScroll(nestedConnection),
                ) {
                    items(visibleApps, key = { it.stableId }) { app -> AppIcon(app, onClick = { onLaunch(app) }) }
                }
            }
        }
    }
}
