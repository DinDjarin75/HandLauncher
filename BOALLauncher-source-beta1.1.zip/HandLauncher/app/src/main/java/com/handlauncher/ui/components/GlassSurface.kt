package com.handlauncher.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.unit.dp
import com.handlauncher.ui.theme.LocalHandVisualTokens

/**
 * Shared translucent surface for Hand's own UI: native widgets, Brief modules,
 * contextual cards and headline rows. Keeping one primitive prevents the left
 * briefing page from drifting visually away from the built-in widgets.
 */
@Composable
fun HandGlassSurface(
    modifier: Modifier = Modifier,
    cornerRadiusDp: Int? = null,
    contentPadding: PaddingValues = PaddingValues(18.dp),
    content: @Composable BoxScope.() -> Unit,
) {
    val visuals = LocalHandVisualTokens.current
    val baseSurface = MaterialTheme.colorScheme.surface
    val foreground = if (baseSurface.luminance() < 0.45f) Color.White else Color(0xFF111015)
    val shape = RoundedCornerShape((cornerRadiusDp ?: visuals.cornerRadiusDp).dp)

    CompositionLocalProvider(LocalContentColor provides foreground) {
        Box(
            modifier = modifier
                .background(baseSurface.copy(alpha = visuals.surfaceAlpha), shape)
                .padding(contentPadding),
            content = content,
        )
    }
}
