package com.handlauncher.data

import android.app.NotificationManager
import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import com.handlauncher.platform.LauncherNotificationListener

/** Current external media session used by the contextual Smart Stack player. */
data class MediaPlaybackState(
    val active: Boolean = false,
    val playing: Boolean = false,
    val title: String = "",
    val subtitle: String = "",
    val packageName: String? = null,
    val artwork: Bitmap? = null,
    val needsAccess: Boolean = false,
)

class MediaSessionRepository(private val context: Context) {
    private val sessionManager = context.getSystemService(MediaSessionManager::class.java)
    private val audioManager = context.getSystemService(AudioManager::class.java)
    private val listener = ComponentName(context, LauncherNotificationListener::class.java)
    @Volatile private var currentController: MediaController? = null

    fun hasAccess(): Boolean {
        val manager = context.getSystemService(NotificationManager::class.java)
        return manager.isNotificationListenerAccessGranted(listener)
    }

    fun snapshot(): MediaPlaybackState {
        if (!hasAccess()) {
            return if (audioManager.isMusicActive) MediaPlaybackState(
                active = true,
                playing = true,
                title = "Media playing",
                subtitle = "Tap to enable controls",
                needsAccess = true,
            ) else MediaPlaybackState()
        }
        val controllers = runCatching { sessionManager.getActiveSessions(listener) }.getOrDefault(emptyList())
        val preferred = controllers.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: controllers.firstOrNull { controller ->
                controller.playbackState?.state in setOf(
                    PlaybackState.STATE_PAUSED,
                    PlaybackState.STATE_BUFFERING,
                    PlaybackState.STATE_CONNECTING,
                )
            }
        currentController = preferred
        if (preferred == null) {
            return MediaPlaybackState(active = false, playing = audioManager.isMusicActive)
        }
        val metadata = preferred.metadata
        val state = preferred.playbackState
        val title = metadata?.getText(MediaMetadata.METADATA_KEY_TITLE)?.toString().orEmpty()
            .ifBlank { metadata?.getText(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)?.toString().orEmpty() }
        val artist = metadata?.getText(MediaMetadata.METADATA_KEY_ARTIST)?.toString().orEmpty()
        val albumArtist = metadata?.getText(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)?.toString().orEmpty()
        val album = metadata?.getText(MediaMetadata.METADATA_KEY_ALBUM)?.toString().orEmpty()
        val subtitle = listOf(artist.ifBlank { albumArtist }, album).filter(String::isNotBlank).distinct().joinToString(" · ")
        val artwork = metadata?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: metadata?.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: metadata?.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
        return MediaPlaybackState(
            active = state?.state in setOf(
                PlaybackState.STATE_PLAYING,
                PlaybackState.STATE_PAUSED,
                PlaybackState.STATE_BUFFERING,
                PlaybackState.STATE_CONNECTING,
            ),
            playing = state?.state == PlaybackState.STATE_PLAYING,
            title = title.ifBlank { "Now playing" },
            subtitle = subtitle,
            packageName = preferred.packageName,
            artwork = artwork,
        )
    }

    fun playPause() {
        val controller = currentController ?: return
        if (controller.playbackState?.state == PlaybackState.STATE_PLAYING) controller.transportControls.pause()
        else controller.transportControls.play()
    }

    fun next() { currentController?.transportControls?.skipToNext() }
    fun previous() { currentController?.transportControls?.skipToPrevious() }
}
