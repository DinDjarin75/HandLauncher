package com.handlauncher.ui.components

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.handlauncher.data.BatteryState
import com.handlauncher.data.MediaPlaybackState
import com.handlauncher.data.ConnectivityState
import com.handlauncher.data.WeatherState
import com.handlauncher.domain.*
import kotlinx.coroutines.delay
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import kotlin.math.abs

@Composable
private fun WidgetSurface(
    modifier: Modifier = Modifier,
    compactPadding: Boolean = false,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    val clickModifier = if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier
    HandGlassSurface(
        modifier = modifier.fillMaxWidth().then(clickModifier),
        contentPadding = PaddingValues(if (compactPadding) 12.dp else 18.dp),
    ) { Column(content = content) }
}

@Composable
fun ClockWidget(
    modifier: Modifier = Modifier,
    variant: String = "standard",
    showSeconds: Boolean = false,
    showDate: Boolean = true,
    onClick: (() -> Unit)? = null,
) {
    var now by remember { mutableStateOf(LocalTime.now()) }
    LaunchedEffect(showSeconds) {
        while (true) {
            now = LocalTime.now()
            delay(if (showSeconds) 1000 else 15_000)
        }
    }
    WidgetSurface(modifier, compactPadding = variant == "minimal", onClick = onClick) {
        if (variant != "minimal") {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Rounded.Schedule, null)
                Text("CLOCK", style = MaterialTheme.typography.labelMedium)
            }
            Spacer(Modifier.height(6.dp))
        }
        Text(
            now.format(DateTimeFormatter.ofPattern(if (showSeconds) "HH:mm:ss" else "HH:mm")),
            style = if (variant == "minimal") MaterialTheme.typography.displaySmall else MaterialTheme.typography.displayMedium,
            fontWeight = FontWeight.Light,
        )
        if (showDate) Text(LocalDate.now().format(DateTimeFormatter.ofPattern(if (variant == "detailed") "EEEE, d MMMM yyyy" else "EEEE, d MMMM")))
    }
}

@Composable
fun CalendarWidget(
    modifier: Modifier = Modifier,
    variant: String = "standard",
    nextEventInMinutes: Int? = null,
    nextEventTitle: String? = null,
    nextEventStartMillis: Long? = null,
    onOpenCalendar: (() -> Unit)? = null,
    onOpenEvent: (() -> Unit)? = null,
) {
    val today = LocalDate.now()
    WidgetSurface(modifier, compactPadding = variant == "minimal") {
        if (variant != "minimal") {
            Row(
                modifier = Modifier.then(if (onOpenCalendar != null) Modifier.clickable(onClick = onOpenCalendar) else Modifier),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Icon(Icons.Rounded.CalendarMonth, null)
                Text("CALENDAR", style = MaterialTheme.typography.labelMedium)
            }
            Spacer(Modifier.height(8.dp))
        }
        Column(
            modifier = Modifier.then(if (variant == "minimal" && onOpenCalendar != null) Modifier.clickable(onClick = onOpenCalendar) else Modifier)
        ) {
            Text(today.dayOfMonth.toString(), style = MaterialTheme.typography.displaySmall)
            Text(today.format(DateTimeFormatter.ofPattern("EEEE · MMMM yyyy")))
        }
        if (nextEventInMinutes != null) {
            Spacer(Modifier.height(4.dp))
            val timing = humanEventTime(nextEventStartMillis, nextEventInMinutes)
            Column(
                modifier = Modifier.then(if (onOpenEvent != null) Modifier.clickable(onClick = onOpenEvent) else Modifier)
            ) {
                Text(
                    nextEventTitle.orEmpty().ifBlank { "Next event" },
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.primary,
                    maxLines = if (variant == "detailed") 2 else 1,
                )
                timing?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = LocalContentColor.current.copy(alpha = 0.78f)) }
            }
        } else if (variant == "detailed") {
            Text("Nothing upcoming", style = MaterialTheme.typography.bodySmall, color = LocalContentColor.current.copy(alpha = 0.76f))
        }
    }
}

@Composable
fun WeatherWidget(
    weather: WeatherState,
    modifier: Modifier = Modifier,
    variant: String = "standard",
    onClick: (() -> Unit)? = null,
) {
    WidgetSurface(modifier, compactPadding = variant == "minimal", onClick = onClick) {
        if (variant != "minimal") {
            Text(weather.location.label.uppercase(), style = MaterialTheme.typography.labelMedium)
            Spacer(Modifier.height(6.dp))
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            WeatherGraphic(weather.condition, Modifier.size(if (variant == "minimal") 50.dp else 64.dp))
            Column(Modifier.weight(1f)) {
                Text(weather.temperatureC?.let { "${kotlin.math.round(it).toInt()}°" } ?: "—°", style = MaterialTheme.typography.displaySmall)
                Text(weather.condition)
                if (variant == "detailed" && weather.rainExpectedInMinutes != null) {
                    Text("Rain possible in ~${weather.rainExpectedInMinutes} min", style = MaterialTheme.typography.bodySmall, color = LocalContentColor.current.copy(alpha = 0.76f))
                }
            }
        }
        if (variant != "minimal" && weather.dailyForecast.isNotEmpty()) {
            Spacer(Modifier.height(10.dp))
            HorizontalDivider(color = LocalContentColor.current.copy(alpha = 0.16f))
            Spacer(Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top,
            ) {
                weather.dailyForecast.take(5).forEach { day ->
                    Column(
                        modifier = Modifier.weight(1f),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(2.dp),
                    ) {
                        Text(day.dayLabel, style = MaterialTheme.typography.labelSmall, maxLines = 1)
                        WeatherGraphic(day.condition, Modifier.size(24.dp))
                        Text(
                            listOfNotNull(
                                day.highC?.let { "${kotlin.math.round(it).toInt()}°" },
                                day.lowC?.let { "${kotlin.math.round(it).toInt()}°" },
                            ).joinToString("/").ifBlank { "—" },
                            style = MaterialTheme.typography.labelSmall,
                            maxLines = 1,
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun BatteryWidget(
    battery: BatteryState,
    modifier: Modifier = Modifier,
    variant: String = "standard",
    connectedDeviceNames: Set<String> = emptySet(),
    showDevices: Boolean = true,
    onClick: (() -> Unit)? = null,
) {
    WidgetSurface(modifier, compactPadding = variant == "minimal", onClick = onClick) {
        if (variant != "minimal") {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Rounded.BatteryFull, null)
                Text("BATTERY", style = MaterialTheme.typography.labelMedium)
            }
            Spacer(Modifier.height(8.dp))
        }
        Text("${battery.percent}%", style = MaterialTheme.typography.displaySmall)
        Text(if (battery.charging) "Phone · charging" else "Phone")
        if (showDevices && connectedDeviceNames.isNotEmpty()) {
            connectedDeviceNames.take(if (variant == "detailed") 4 else 2).forEach { name ->
                Text("Connected · $name", style = MaterialTheme.typography.bodySmall, color = LocalContentColor.current.copy(alpha = 0.76f))
            }
        }
    }
}

@Composable
fun ConnectivityWidget(
    connectivity: ConnectivityState,
    modifier: Modifier = Modifier,
) {
    WidgetSurface(modifier = modifier) {
        Text("CONNECTIVITY", style = MaterialTheme.typography.labelMedium)
        Spacer(Modifier.height(8.dp))

        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Icon(Icons.Rounded.Wifi, contentDescription = null, modifier = Modifier.size(25.dp))
            Column(Modifier.weight(1f)) {
                Text(connectivity.wifiName, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    connectivity.wifiSpeedMbps?.let { "$it Mbps" } ?: if (connectivity.wifiConnected) "Connected" else "Wi-Fi off",
                    style = MaterialTheme.typography.bodySmall,
                    color = LocalContentColor.current.copy(alpha = 0.72f),
                )
            }
        }

        Spacer(Modifier.height(9.dp))
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Box(
                modifier = Modifier.width(30.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(connectivity.mobileType, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
            }
            Column(Modifier.weight(1f)) {
                Text(connectivity.operatorName, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(connectivity.mobileType, style = MaterialTheme.typography.bodySmall, color = LocalContentColor.current.copy(alpha = 0.72f))
            }
            SignalBars(connectivity.mobileSignalLevel)
        }

        Spacer(Modifier.height(9.dp))
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Icon(Icons.Rounded.Bluetooth, contentDescription = null, modifier = Modifier.size(25.dp))
            Column(Modifier.weight(1f)) {
                Text("Bluetooth", style = MaterialTheme.typography.titleSmall)
                Text(
                    connectivity.bluetoothDeviceNames.take(3).joinToString(" · ").ifBlank { "No connected devices" },
                    style = MaterialTheme.typography.bodySmall,
                    color = LocalContentColor.current.copy(alpha = 0.72f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}

@Composable
private fun SignalBars(level: Int?) {
    Row(
        modifier = Modifier.height(24.dp),
        verticalAlignment = Alignment.Bottom,
        horizontalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        repeat(4) { index ->
            val active = level != null && index < level
            Box(
                Modifier
                    .width(4.dp)
                    .height((7 + index * 4).dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(LocalContentColor.current.copy(alpha = if (active) 0.92f else 0.20f))
            )
        }
    }
}

@Composable
fun MediaWidget(
    media: MediaPlaybackState,
    modifier: Modifier = Modifier,
    onOpen: () -> Unit,
    onPlayPause: () -> Unit,
    onPrevious: () -> Unit,
    onNext: () -> Unit,
) {
    WidgetSurface(modifier = modifier, onClick = onOpen) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            if (media.artwork != null) {
                Image(
                    bitmap = media.artwork.asImageBitmap(),
                    contentDescription = null,
                    modifier = Modifier.size(78.dp).clip(RoundedCornerShape(18.dp)),
                    contentScale = ContentScale.Crop,
                )
            } else {
                Box(
                    Modifier.size(78.dp).background(LocalContentColor.current.copy(alpha = 0.10f), RoundedCornerShape(18.dp)),
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Rounded.GraphicEq, null, modifier = Modifier.size(36.dp)) }
            }
            Column(Modifier.weight(1f)) {
                Text(media.title.ifBlank { "Now playing" }, style = MaterialTheme.typography.titleMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                if (media.subtitle.isNotBlank()) Text(media.subtitle, color = LocalContentColor.current.copy(alpha = 0.72f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onPrevious) { Icon(Icons.Rounded.SkipPrevious, "Previous") }
                    IconButton(onClick = onPlayPause) { Icon(if (media.playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, if (media.playing) "Pause" else "Play") }
                    IconButton(onClick = onNext) { Icon(Icons.Rounded.SkipNext, "Next") }
                }
            }
        }
    }
}

@Composable
fun SmartWidgetStack(
    battery: BatteryState,
    contextDecision: ContextDecision,
    modifier: Modifier = Modifier,
    definition: SmartStackDefinition? = null,
    connectedDeviceNames: Set<String> = emptySet(),
    nextEventInMinutes: Int? = null,
    nextEventTitle: String? = null,
    nextEventStartMillis: Long? = null,
    weather: WeatherState = WeatherState(),
    media: MediaPlaybackState = MediaPlaybackState(),
    connectivity: ConnectivityState = ConnectivityState(),
    initialPermanentIndex: Int = 0,
    onPermanentIndexChanged: (Int) -> Unit = {},
    autoAdvanceAllowed: Boolean = true,
    onOpenClock: () -> Unit = {},
    onOpenCalendar: () -> Unit = {},
    onOpenCalendarEvent: () -> Unit = {},
    onOpenWeather: () -> Unit = {},
    onOpenBattery: () -> Unit = {},
    onOpenMedia: () -> Unit = {},
    onMediaPlayPause: () -> Unit = {},
    onMediaPrevious: () -> Unit = {},
    onMediaNext: () -> Unit = {},
) {
    // Permanent cards are always user-driven. Media is the only contextual card:
    // it joins the same circular swipe loop while playback is active and disappears
    // when playback ends. There is deliberately no timer-based auto-advance.
    val configured = definition?.items.orEmpty().map { it.widgetKind }
        .filterNot { it in setOf(NativeWidgetKind.MEDIA, NativeWidgetKind.CONTEXT, NativeWidgetKind.NEWS, NativeWidgetKind.CONNECTIVITY) }
    val permanent = remember(configured) {
        buildList {
            addAll(configured)
            listOf(NativeWidgetKind.CLOCK, NativeWidgetKind.WEATHER, NativeWidgetKind.BATTERY).forEach { if (it !in this) add(it) }
            if (isEmpty()) add(NativeWidgetKind.CALENDAR)
            add(NativeWidgetKind.CONNECTIVITY)
        }.distinct()
    }
    val memoryKey = "${definition?.id ?: "inline"}:${permanent.joinToString { it.name }}"
    var lastPermanentIndex by remember(memoryKey) {
        mutableIntStateOf(initialPermanentIndex.coerceIn(0, permanent.lastIndex.coerceAtLeast(0)))
    }
    var currentKind by remember(memoryKey) {
        mutableStateOf(permanent.getOrElse(lastPermanentIndex) { NativeWidgetKind.CLOCK })
    }
    var mediaPromotionHandled by remember(memoryKey) { mutableStateOf(false) }
    var direction by remember { mutableIntStateOf(1) }
    var drag by remember { mutableFloatStateOf(0f) }
    val swipeThreshold = with(LocalDensity.current) { 52.dp.toPx() }
    val activeCards = remember(permanent, media.active) {
        if (media.active) permanent + NativeWidgetKind.MEDIA else permanent
    }

    LaunchedEffect(media.active, permanent) {
        if (media.active && !mediaPromotionHandled) {
            // Promote the active media session once, including when BOAL opens mid-session.
            // Once the user swipes away, it remains in the loop but never steals focus again.
            direction = 1
            currentKind = NativeWidgetKind.MEDIA
            mediaPromotionHandled = true
        } else if (!media.active) {
            if (currentKind == NativeWidgetKind.MEDIA) {
                currentKind = permanent.getOrElse(lastPermanentIndex) { NativeWidgetKind.CLOCK }
            }
            mediaPromotionHandled = false
        }
    }

    val activeKind = if (currentKind in activeCards) {
        currentKind
    } else {
        permanent.getOrElse(lastPermanentIndex) { NativeWidgetKind.CLOCK }
    }

    LaunchedEffect(activeKind, permanent) {
        val permanentIndex = permanent.indexOf(activeKind)
        if (permanentIndex >= 0 && permanentIndex != lastPermanentIndex) {
            lastPermanentIndex = permanentIndex
            onPermanentIndexChanged(permanentIndex)
        }
    }

    Box(
        modifier = modifier.pointerInput(activeCards, swipeThreshold) {
            detectHorizontalDragGestures(
                onHorizontalDrag = { _, amount -> drag += amount },
                onDragEnd = {
                    if (activeCards.size > 1 && abs(drag) > swipeThreshold) {
                        direction = if (drag < 0f) 1 else -1
                        val current = activeCards.indexOf(activeKind).coerceAtLeast(0)
                        val next = if (direction > 0) {
                            (current + 1) % activeCards.size
                        } else {
                            (current - 1 + activeCards.size) % activeCards.size
                        }
                        currentKind = activeCards[next]
                    }
                    drag = 0f
                },
                onDragCancel = { drag = 0f },
            )
        }
    ) {
        AnimatedContent(
            targetState = activeKind,
            transitionSpec = {
                val slideIn = slideInHorizontally { width -> if (direction > 0) width / 3 else -width / 3 } + fadeIn()
                val slideOut = slideOutHorizontally { width -> if (direction > 0) -width / 3 else width / 3 } + fadeOut()
                slideIn togetherWith slideOut
            },
            label = "smart-stack-horizontal",
        ) { kind ->
            when (kind) {
                NativeWidgetKind.CLOCK -> ClockWidget(modifier = Modifier.fillMaxSize(), onClick = onOpenClock)
                NativeWidgetKind.CALENDAR -> CalendarWidget(
                    modifier = Modifier.fillMaxSize(),
                    nextEventInMinutes = nextEventInMinutes,
                    nextEventTitle = nextEventTitle,
                    nextEventStartMillis = nextEventStartMillis,
                    onOpenCalendar = onOpenCalendar,
                    onOpenEvent = onOpenCalendarEvent,
                )
                NativeWidgetKind.WEATHER -> WeatherWidget(weather, modifier = Modifier.fillMaxSize(), onClick = onOpenWeather)
                NativeWidgetKind.BATTERY -> BatteryWidget(battery, modifier = Modifier.fillMaxSize(), connectedDeviceNames = connectedDeviceNames, onClick = onOpenBattery)
                NativeWidgetKind.CONNECTIVITY -> ConnectivityWidget(connectivity, modifier = Modifier.fillMaxSize())
                NativeWidgetKind.MEDIA -> MediaWidget(media, modifier = Modifier.fillMaxSize(), onOpen = onOpenMedia, onPlayPause = onMediaPlayPause, onPrevious = onMediaPrevious, onNext = onMediaNext)
                NativeWidgetKind.CONTEXT, NativeWidgetKind.NEWS -> ClockWidget(modifier = Modifier.fillMaxSize(), onClick = onOpenClock)
            }
        }
    }
}
