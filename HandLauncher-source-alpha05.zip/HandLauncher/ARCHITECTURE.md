# Hand Launcher architecture

## Non-negotiable product rule
Context and AI may **surface, promote, suggest or propose**. They never silently rewrite the user's permanent authored layout.

## Five engines

### 1. Layout Engine
Declarative `LauncherLayout` objects use normalized geometry and independent profiles for cover, inner Fold, portrait, landscape and external display. The same canvas renderer is used across phone and desktop shells.

### 2. Smart Object Engine
Every placed item is represented as a `SmartObject`: app, collection/folder, Hand widget, Android widget, Smart Stack, shortcut or command. Each object can own tap, swipe-up, swipe-down and long-press actions.

### 3. Search / Command Engine
Swipe-down Search is local-first. Apps are indexed by label, tags, category and package, while launcher commands share the same surface. This can later accept contacts/files/settings providers without changing the Home interaction.

### 4. Context Engine
`ContextSnapshot` is evaluated against persisted rules. Context effects are ephemeral; they can promote stack content or suggest actions without mutating `LauncherLayout`.

### 5. AI Design Engine
AI receives an `AiLayoutRequest`. Cloud AI, when enabled, returns a constrained JSON design plan rather than executable launcher state. Hand validates app IDs/widget kinds and composes an editable `AiLayoutProposal`, which requires explicit Apply.

## Categories and tags
A visual category gives the App Library a simple navigable structure. Tags remain independent metadata used for search and future multi-collection views. Automatic categorization is initialization only; persisted user assignments always win.

## Widget architecture
Hand widgets share launcher theme tokens and context data. Android widgets are hosted through `AppWidgetHost` and placed as regular declarative objects on the same canvas. Smart Stack membership is persisted independently of stack geometry.

## Fold and external displays
Profiles are independent by default. Jetpack Window posture information distinguishes folding state; an external display gets an independent desktop profile and shell rather than a stretched phone grid.

## AI theme tokens
`AiThemeTokens` currently control:
- dark/light scheme
- surface transparency
- corner radius
- typography mood

The token model is deliberately separate from geometry so a layout can be re-themed without moving objects.

## Security / privacy
- Gemini credentials are encrypted using Android Keystore.
- AI keys are excluded from exported launcher backups.
- Weather uses a manually selected coarse location rather than continuous background location.
- Search/category/context state is local launcher data.

## Discover boundary
Google Discover is isolated behind a feed-provider boundary. The core launcher does not depend on undocumented Google behavior. The current fallback opens the Google app; a separate companion integration can be added without coupling it to the Home engine.
