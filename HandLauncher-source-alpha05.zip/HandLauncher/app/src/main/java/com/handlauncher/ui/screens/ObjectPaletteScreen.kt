package com.handlauncher.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.handlauncher.domain.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ObjectPaletteScreen(
    apps: List<AppEntry>,
    categories: List<AppCategory>,
    onAddApp: (AppEntry) -> Unit,
    onAddNativeWidget: (NativeWidgetKind) -> Unit,
    onAddAndroidWidget: () -> Unit,
    onAddSmartStack: () -> Unit,
    onAddCategory: (AppCategory) -> Unit,
    onAddCommand: (String, String) -> Unit,
    onDismiss: () -> Unit,
) {
    BackHandler(onBack = onDismiss)
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Add to Home") },
                navigationIcon = { IconButton(onClick = onDismiss) { Icon(Icons.Rounded.Close, "Close") } },
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item { SectionTitle("Widgets") }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PaletteButton("Clock", Icons.Rounded.Schedule, Modifier.weight(1f)) { onAddNativeWidget(NativeWidgetKind.CLOCK) }
                    PaletteButton("Calendar", Icons.Rounded.CalendarMonth, Modifier.weight(1f)) { onAddNativeWidget(NativeWidgetKind.CALENDAR) }
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PaletteButton("Weather", Icons.Rounded.Cloud, Modifier.weight(1f)) { onAddNativeWidget(NativeWidgetKind.WEATHER) }
                    PaletteButton("Battery", Icons.Rounded.BatteryFull, Modifier.weight(1f)) { onAddNativeWidget(NativeWidgetKind.BATTERY) }
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PaletteButton("Smart Stack", Icons.Rounded.Layers, Modifier.weight(1f), onAddSmartStack)
                    PaletteButton("Android widget", Icons.Rounded.Widgets, Modifier.weight(1f), onAddAndroidWidget)
                }
            }

            item { SectionTitle("Commands") }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AssistChip(onClick = { onAddCommand("Search", "search") }, label = { Text("Search") }, leadingIcon = { Icon(Icons.Rounded.Search, null) })
                    AssistChip(onClick = { onAddCommand("Apps", "library") }, label = { Text("Apps") }, leadingIcon = { Icon(Icons.Rounded.Apps, null) })
                    AssistChip(onClick = { onAddCommand("AI Design", "ai") }, label = { Text("AI Design") }, leadingIcon = { Icon(Icons.Rounded.AutoAwesome, null) })
                }
            }

            item { SectionTitle("Category objects") }
            items(categories, key = { "category_${it.id}" }) { category ->
                ListItem(
                    headlineContent = { Text(category.name) },
                    supportingContent = { Text("Tap opens this category") },
                    leadingContent = { Icon(Icons.Rounded.Folder, null) },
                    modifier = Modifier.clickable { onAddCategory(category) },
                )
            }

            item { SectionTitle("Apps") }
            items(apps, key = { it.stableId }) { app ->
                ListItem(
                    headlineContent = { Text(app.label) },
                    supportingContent = { Text(app.categoryId.replace('_', ' ')) },
                    leadingContent = { Icon(Icons.Rounded.Apps, null) },
                    trailingContent = { Icon(Icons.Rounded.Add, null) },
                    modifier = Modifier.clickable { onAddApp(app) },
                )
            }
        }
    }
}

@Composable
private fun PaletteButton(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier, onClick: () -> Unit) {
    ElevatedCard(onClick = onClick, modifier = modifier) {
        Column(Modifier.fillMaxWidth().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(icon, null)
            Text(label, style = MaterialTheme.typography.labelLarge)
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 8.dp, bottom = 2.dp))
}
