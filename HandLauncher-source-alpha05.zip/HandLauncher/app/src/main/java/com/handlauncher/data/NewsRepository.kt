package com.handlauncher.data

import android.content.Context
import android.text.Html
import android.util.Xml
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import org.xmlpull.v1.XmlPullParser
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

data class NewsHeadline(
    val title: String,
    val url: String,
    val source: String = "",
    val publishedAtMillis: Long? = null,
    val imageUrl: String? = null,
)

data class NewsState(
    val headlines: List<NewsHeadline> = emptyList(),
    val entertainment: List<NewsHeadline> = emptyList(),
    val tech: List<NewsHeadline> = emptyList(),
    val lego: List<NewsHeadline> = emptyList(),
    val available: Boolean = false,
    val lastUpdatedMillis: Long? = null,
    val message: String? = null,
)

/** Key-free briefing news provider. */
class NewsRepository(@Suppress("UNUSED_PARAMETER") context: Context) {
    private val resolvedImageCache = ConcurrentHashMap<String, String>()

    suspend fun refresh(): NewsState = withContext(Dispatchers.IO) {
        runCatching {
            coroutineScope {
                val headlineJob = async { loadFeed(TOP_FEED, 5) }
                val entertainmentJob = async { loadFeed(searchFeed("entertainment OR movies OR television OR music"), 5) }
                val techJob = async { loadFeed(searchFeed("technology OR gadgets OR software OR AI"), 5) }
                val legoJob = async { loadFeed(searchFeed("LEGO"), 5) }
                val headlines = headlineJob.await()
                val entertainment = entertainmentJob.await()
                val tech = techJob.await()
                val lego = legoJob.await()
                NewsState(
                    headlines = headlines,
                    entertainment = entertainment,
                    tech = tech,
                    lego = lego,
                    available = listOf(headlines, entertainment, tech, lego).any { it.isNotEmpty() },
                    lastUpdatedMillis = System.currentTimeMillis(),
                    message = if (listOf(headlines, entertainment, tech, lego).all { it.isEmpty() }) "News unavailable" else null,
                )
            }
        }.getOrElse { NewsState(message = "News unavailable") }
    }

    private suspend fun loadFeed(feedUrl: String, limit: Int): List<NewsHeadline> {
        val parsed = runCatching {
            val connection = open(feedUrl, 8_000, 10_000)
            connection.inputStream.buffered().use { input ->
                val parser = Xml.newPullParser().apply {
                    setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
                    setInput(input, null)
                }
                parse(parser)
            }
        }.getOrDefault(emptyList())
            .sortedWith(compareByDescending<NewsHeadline> { it.publishedAtMillis ?: 0L })
            .take(limit)

        return coroutineScope {
            parsed.map { headline ->
                async {
                    if (!headline.imageUrl.isNullOrBlank()) headline
                    else headline.copy(
                        imageUrl = resolvedImageCache[headline.url]
                            ?: resolveLeadImage(headline.url)?.also { resolvedImageCache[headline.url] = it }
                    )
                }
            }.awaitAll()
        }
    }

    private fun parse(parser: XmlPullParser): List<NewsHeadline> {
        val results = mutableListOf<NewsHeadline>()
        var event = parser.eventType
        var inItem = false
        var currentTag: String? = null
        var title = ""
        var link = ""
        var source = ""
        var description = ""
        var published: Long? = null
        var imageUrl: String? = null

        while (event != XmlPullParser.END_DOCUMENT && results.size < 18) {
            when (event) {
                XmlPullParser.START_TAG -> {
                    currentTag = parser.name
                    if (parser.name.equals("item", ignoreCase = true)) {
                        inItem = true
                        title = ""; link = ""; source = ""; description = ""; published = null; imageUrl = null
                    } else if (inItem) {
                        val tag = parser.name.lowercase(Locale.ROOT)
                        if (tag in setOf("media:content", "media:thumbnail", "thumbnail", "content")) {
                            imageUrl = parser.getAttributeValue(null, "url") ?: imageUrl
                        } else if (tag == "enclosure") {
                            val type = parser.getAttributeValue(null, "type").orEmpty()
                            if (type.startsWith("image/")) imageUrl = parser.getAttributeValue(null, "url") ?: imageUrl
                        }
                    }
                }
                XmlPullParser.TEXT -> if (inItem) {
                    val raw = parser.text.orEmpty()
                    val value = raw.trim()
                    if (value.isNotBlank()) {
                        when (currentTag?.lowercase(Locale.ROOT)) {
                            "title" -> title += value
                            "link" -> link += value
                            "source" -> source += value
                            "description" -> description += raw
                            "pubdate", "published" -> published = parseDate(value)
                        }
                    }
                }
                XmlPullParser.END_TAG -> {
                    if (parser.name.equals("item", ignoreCase = true)) {
                        if (title.isNotBlank() && link.isNotBlank()) {
                            results += NewsHeadline(
                                title = title.trim(),
                                url = link.trim(),
                                source = source.trim(),
                                publishedAtMillis = published,
                                imageUrl = imageUrl ?: firstImageInHtml(description),
                            )
                        }
                        inItem = false
                    }
                    currentTag = null
                }
            }
            event = parser.next()
        }
        return results
    }

    private fun resolveLeadImage(articleUrl: String): String? = runCatching {
        val first = fetchHtml(articleUrl) ?: return@runCatching null
        findLeadImageMeta(first.html)?.let { return@runCatching it }

        // Google News RSS links sometimes land on an intermediary page. If so,
        // follow the first credible publisher URL and read that page's hero metadata.
        if (runCatching { URL(first.finalUrl).host.contains("google.") }.getOrDefault(false)) {
            val publisherUrl = externalPublisherLink(first.html)
            if (publisherUrl != null) {
                val publisher = fetchHtml(publisherUrl)
                findLeadImageMeta(publisher?.html.orEmpty())?.let { return@runCatching it }
            }
        }
        null
    }.getOrNull()

    private data class HtmlPage(val finalUrl: String, val html: String)

    private fun fetchHtml(url: String): HtmlPage? = runCatching {
        val connection = open(url, 5_500, 7_500).apply {
            setRequestProperty("Accept", "text/html,application/xhtml+xml")
        }
        val html = connection.inputStream.bufferedReader().use { reader ->
            val out = StringBuilder()
            val buffer = CharArray(8192)
            while (out.length < 300_000) {
                val read = reader.read(buffer)
                if (read <= 0) break
                out.append(buffer, 0, read.coerceAtMost(300_000 - out.length))
            }
            out.toString()
        }
        HtmlPage(connection.url.toString(), html)
    }.getOrNull()

    private fun open(url: String, connectMs: Int, readMs: Int): HttpURLConnection =
        (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = connectMs
            readTimeout = readMs
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 16) AppleWebKit/537.36 Chrome/140 Mobile Safari/537.36")
            setRequestProperty("Accept-Language", "en-GB,en;q=0.9")
        }

    private fun firstImageInHtml(html: String): String? =
        IMG_SRC.find(html)?.groupValues?.getOrNull(1)?.let(::decodeHtml)
            ?.takeIf { it.startsWith("http://") || it.startsWith("https://") }

    private fun findLeadImageMeta(html: String): String? {
        META_TAG.findAll(html).forEach { match ->
            val attrs = ATTRIBUTE.findAll(match.value).associate { attr ->
                attr.groupValues[1].lowercase(Locale.ROOT) to attr.groupValues[2]
            }
            val key = attrs["property"] ?: attrs["name"]
            if (key.equals("og:image", true) || key.equals("og:image:url", true) || key.equals("twitter:image", true) || key.equals("twitter:image:src", true)) {
                val value = attrs["content"]?.let(::decodeHtml)
                if (value != null && (value.startsWith("http://") || value.startsWith("https://"))) return value
            }
        }
        return null
    }

    private fun externalPublisherLink(html: String): String? = HREF.findAll(html)
        .mapNotNull { it.groupValues.getOrNull(1)?.let(::decodeHtml) }
        .firstOrNull { candidate ->
            candidate.startsWith("https://") && runCatching {
                val host = URL(candidate).host.lowercase(Locale.ROOT)
                host.isNotBlank() && !host.contains("google.") && !host.contains("gstatic.") && !host.contains("youtube.")
            }.getOrDefault(false)
        }

    private fun decodeHtml(value: String): String = Html.fromHtml(value, Html.FROM_HTML_MODE_LEGACY).toString().trim()

    private fun parseDate(raw: String): Long? = runCatching {
        ZonedDateTime.parse(raw, DateTimeFormatter.RFC_1123_DATE_TIME).toInstant().toEpochMilli()
    }.getOrNull()

    companion object {
        private const val TOP_FEED = "https://news.google.com/rss?hl=en-LU&gl=LU&ceid=LU:en"
        private fun searchFeed(query: String): String =
            "https://news.google.com/rss/search?q=${URLEncoder.encode(query, StandardCharsets.UTF_8.toString())}&hl=en-LU&gl=LU&ceid=LU:en"
        private val IMG_SRC = Regex("""<img[^>]+src\s*=\s*[\"']([^\"']+)[\"']""", RegexOption.IGNORE_CASE)
        private val META_TAG = Regex("""<meta\s+[^>]*>""", RegexOption.IGNORE_CASE)
        private val ATTRIBUTE = Regex("""([A-Za-z_:.-]+)\s*=\s*[\"']([^\"']*)[\"']""")
        private val HREF = Regex("""href\s*=\s*[\"']([^\"']+)[\"']""", RegexOption.IGNORE_CASE)
    }
}
