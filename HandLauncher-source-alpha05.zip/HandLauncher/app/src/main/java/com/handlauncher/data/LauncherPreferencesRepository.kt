package com.handlauncher.data

import android.content.Context
import com.handlauncher.domain.*
import com.handlauncher.engine.ContextEngine
import org.json.JSONArray
import org.json.JSONObject

/** Persists declarative launcher state rather than rendered UI. */
class LauncherPreferencesRepository(context: Context) {
    private val prefs = context.getSharedPreferences("hand_launcher_state", Context.MODE_PRIVATE)

    fun loadCategories(): List<AppCategory> {
        val raw = prefs.getString(KEY_CATEGORIES, null) ?: return DefaultCategories.all
        return runCatching {
            val array = JSONArray(raw)
            buildList {
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    add(
                        AppCategory(
                            id = obj.getString("id"),
                            name = obj.getString("name"),
                            iconKey = obj.optString("iconKey", "grid"),
                            sortOrder = obj.optInt("sortOrder", i),
                            userCreated = obj.optBoolean("userCreated", false),
                            backgroundTransparencyPercent = obj.optInt("backgroundTransparencyPercent", 38).coerceIn(0, 90),
                        )
                    )
                }
            }.sortedBy { it.sortOrder }
        }.getOrElse { DefaultCategories.all }
    }

    fun saveCategories(categories: List<AppCategory>) {
        val array = JSONArray()
        categories.sortedBy { it.sortOrder }.forEach { category ->
            array.put(
                JSONObject()
                    .put("id", category.id)
                    .put("name", category.name)
                    .put("iconKey", category.iconKey)
                    .put("sortOrder", category.sortOrder)
                    .put("userCreated", category.userCreated)
                    .put("backgroundTransparencyPercent", category.backgroundTransparencyPercent.coerceIn(0, 90))
            )
        }
        prefs.edit().putString(KEY_CATEGORIES, array.toString()).apply()
    }

    fun loadCategoryAssignments(): Map<String, String> {
        val raw = prefs.getString(KEY_CATEGORY_ASSIGNMENTS, null) ?: return emptyMap()
        return runCatching {
            val obj = JSONObject(raw)
            buildMap { obj.keys().forEach { key -> put(key, obj.getString(key)) } }
        }.getOrDefault(emptyMap())
    }

    fun saveCategoryAssignments(assignments: Map<String, String>) {
        val obj = JSONObject()
        assignments.forEach { (appId, categoryId) -> obj.put(appId, categoryId) }
        prefs.edit().putString(KEY_CATEGORY_ASSIGNMENTS, obj.toString()).apply()
    }

    fun saveLayout(layout: LauncherLayout) {
        prefs.edit().putString(layoutKey(layout.profile), layout.toJson().toString()).apply()
    }

    fun loadLayout(profile: LayoutProfile): LauncherLayout? {
        val raw = prefs.getString(layoutKey(profile), null) ?: return null
        return runCatching { launcherLayoutFromJson(JSONObject(raw)) }.getOrNull()
    }

    fun saveSmartObject(appStableId: String, smartObject: SmartObject) {
        prefs.edit().putString(smartObjectKey(appStableId), smartObject.toJson().toString()).apply()
    }

    fun loadSmartObject(appStableId: String): SmartObject? {
        val raw = prefs.getString(smartObjectKey(appStableId), null) ?: return null
        return runCatching { smartObjectFromJson(JSONObject(raw)) }.getOrNull()
    }

    fun saveTheme(profile: LayoutProfile, theme: AiThemeTokens) {
        val obj = JSONObject()
            .put("dark", theme.dark)
            .put("cornerRadiusDp", theme.cornerRadiusDp)
            .put("transparencyPercent", theme.transparencyPercent)
            .put("typographyMood", theme.typographyMood)
        prefs.edit().putString(themeKey(profile), obj.toString()).apply()
    }

    fun loadTheme(profile: LayoutProfile): AiThemeTokens? {
        val raw = prefs.getString(themeKey(profile), null) ?: return null
        return runCatching {
            val obj = JSONObject(raw)
            AiThemeTokens(
                dark = obj.optBoolean("dark", true),
                cornerRadiusDp = obj.optInt("cornerRadiusDp", 28),
                transparencyPercent = obj.optInt("transparencyPercent", 10),
                typographyMood = obj.optString("typographyMood", "clean"),
            )
        }.getOrNull()
    }

    fun saveSmartStack(definition: SmartStackDefinition) {
        val obj = JSONObject()
            .put("id", definition.id)
            .put("name", definition.name)
            .put("smartRotationEnabled", definition.smartRotationEnabled)
            .put("autoLoopEnabled", definition.autoLoopEnabled)
            .put("items", JSONArray().also { array ->
                definition.items.forEach { item ->
                    array.put(
                        JSONObject()
                            .put("widgetKind", item.widgetKind.name)
                            .put("allowAutomaticPromotion", item.allowAutomaticPromotion)
                    )
                }
            })
        prefs.edit().putString(smartStackKey(definition.id), obj.toString()).apply()
    }

    fun loadSmartStack(id: String): SmartStackDefinition? {
        val raw = prefs.getString(smartStackKey(id), null) ?: return null
        return runCatching {
            val obj = JSONObject(raw)
            val itemsJson = obj.optJSONArray("items") ?: JSONArray()
            val items = buildList {
                for (i in 0 until itemsJson.length()) {
                    val item = itemsJson.getJSONObject(i)
                    val kind = runCatching { NativeWidgetKind.valueOf(item.getString("widgetKind")) }.getOrNull() ?: continue
                    add(StackItem(kind, item.optBoolean("allowAutomaticPromotion", true)))
                }
            }
            SmartStackDefinition(
                id = obj.getString("id"),
                name = obj.optString("name", "Smart Stack"),
                items = items,
                smartRotationEnabled = obj.optBoolean("smartRotationEnabled", true),
                autoLoopEnabled = obj.optBoolean("autoLoopEnabled", true),
            )
        }.getOrNull()
    }

    fun saveAndroidWidgetIds(ids: Set<Int>) {
        prefs.edit().putStringSet(KEY_ANDROID_WIDGET_IDS, ids.map(Int::toString).toSet()).apply()
    }

    fun loadAndroidWidgetIds(): Set<Int> =
        prefs.getStringSet(KEY_ANDROID_WIDGET_IDS, emptySet()).orEmpty().mapNotNull(String::toIntOrNull).toSet()

    fun saveAutomationRules(rules: List<ContextRule>) {
        val array = JSONArray()
        rules.forEach { array.put(it.toJson()) }
        prefs.edit().putString(KEY_AUTOMATION_RULES, array.toString()).apply()
    }

    fun loadAutomationRules(): List<ContextRule> {
        val raw = prefs.getString(KEY_AUTOMATION_RULES, null) ?: return ContextEngine.defaultRules()
        return runCatching {
            val array = JSONArray(raw)
            buildList {
                for (i in 0 until array.length()) add(contextRuleFromJson(array.getJSONObject(i)))
            }
        }.getOrElse { ContextEngine.defaultRules() }
    }

    /** API keys live in a separate encrypted store and are intentionally excluded. */
    fun exportBackup(): String {
        val values = JSONObject()
        prefs.all.forEach { (key, value) ->
            when (value) {
                is String -> values.put(key, JSONObject().put("type", "string").put("value", value))
                is Set<*> -> values.put(
                    key,
                    JSONObject().put("type", "string_set").put("value", JSONArray(value.filterIsInstance<String>()))
                )
                is Boolean -> values.put(key, JSONObject().put("type", "boolean").put("value", value))
                is Int -> values.put(key, JSONObject().put("type", "int").put("value", value))
                is Long -> values.put(key, JSONObject().put("type", "long").put("value", value))
                is Float -> values.put(key, JSONObject().put("type", "float").put("value", value.toDouble()))
            }
        }
        return JSONObject()
            .put("product", "Hand Launcher")
            .put("schemaVersion", 1)
            .put("values", values)
            .toString(2)
    }

    fun importBackup(raw: String): Boolean = runCatching {
        val root = JSONObject(raw)
        require(root.optString("product") == "Hand Launcher") { "Not a Hand Launcher backup" }
        val values = root.getJSONObject("values")
        val editor = prefs.edit().clear()
        values.keys().forEach { key ->
            val wrapped = values.getJSONObject(key)
            when (wrapped.getString("type")) {
                "string" -> editor.putString(key, wrapped.optString("value"))
                "string_set" -> {
                    val array = wrapped.getJSONArray("value")
                    val set = buildSet { for (i in 0 until array.length()) add(array.getString(i)) }
                    editor.putStringSet(key, set)
                }
                "boolean" -> editor.putBoolean(key, wrapped.optBoolean("value"))
                "int" -> editor.putInt(key, wrapped.optInt("value"))
                "long" -> editor.putLong(key, wrapped.optLong("value"))
                "float" -> editor.putFloat(key, wrapped.optDouble("value").toFloat())
            }
        }
        editor.commit()
    }.getOrDefault(false)

    private fun layoutKey(profile: LayoutProfile) = "layout_${profile.name}"
    private fun themeKey(profile: LayoutProfile) = "theme_${profile.name}"
    private fun smartObjectKey(appStableId: String) = "smart_object_$appStableId"
    private fun smartStackKey(id: String) = "smart_stack_$id"

    companion object {
        private const val KEY_CATEGORIES = "categories"
        private const val KEY_CATEGORY_ASSIGNMENTS = "category_assignments"
        private const val KEY_ANDROID_WIDGET_IDS = "android_widget_ids"
        private const val KEY_AUTOMATION_RULES = "automation_rules"
    }
}

private fun LauncherLayout.toJson(): JSONObject = JSONObject()
    .put("id", id)
    .put("name", name)
    .put("profile", profile.name)
    .put("columns", columns)
    .put("rows", rows)
    .put("finePositioning", finePositioning)
    .put("locked", locked)
    .put("pages", JSONArray().also { pagesArray ->
        pages.forEach { page ->
            pagesArray.put(
                JSONObject()
                    .put("id", page.id)
                    .put("title", page.title)
                    .put("objects", JSONArray().also { objectsArray -> page.objects.forEach { objectsArray.put(it.toJson()) } })
            )
        }
    })

private fun launcherLayoutFromJson(obj: JSONObject): LauncherLayout {
    val pagesJson = obj.getJSONArray("pages")
    val pages = buildList {
        for (i in 0 until pagesJson.length()) {
            val pageJson = pagesJson.getJSONObject(i)
            val objectsJson = pageJson.getJSONArray("objects")
            val objects = buildList {
                for (j in 0 until objectsJson.length()) add(smartObjectFromJson(objectsJson.getJSONObject(j)))
            }
            add(LayoutPage(pageJson.getString("id"), pageJson.getString("title"), objects))
        }
    }
    return LauncherLayout(
        id = obj.getString("id"),
        name = obj.getString("name"),
        profile = LayoutProfile.valueOf(obj.getString("profile")),
        columns = obj.getInt("columns"),
        rows = obj.getInt("rows"),
        finePositioning = obj.optBoolean("finePositioning", false),
        locked = obj.optBoolean("locked", false),
        pages = pages,
    )
}

private fun SmartObject.toJson(): JSONObject = JSONObject()
    .put("id", id)
    .put("type", type.name)
    .put("title", title)
    .put("rect", JSONObject()
        .put("x", rect.x.toDouble())
        .put("y", rect.y.toDouble())
        .put("width", rect.width.toDouble())
        .put("height", rect.height.toDouble()))
    .put("tags", JSONArray(tags.toList()))
    .put("actions", actions.toJson())
    .put("payload", JSONObject(payload))
    .put("contextualPromotionAllowed", contextualPromotionAllowed)

private fun smartObjectFromJson(obj: JSONObject): SmartObject {
    val rect = obj.getJSONObject("rect")
    val tagsArray = obj.optJSONArray("tags") ?: JSONArray()
    val tags = buildSet { for (i in 0 until tagsArray.length()) add(tagsArray.getString(i)) }
    val payloadObj = obj.optJSONObject("payload") ?: JSONObject()
    val payload = buildMap { payloadObj.keys().forEach { key -> put(key, payloadObj.getString(key)) } }
    return SmartObject(
        id = obj.getString("id"),
        type = SmartObjectType.valueOf(obj.getString("type")),
        title = obj.getString("title"),
        rect = GridRect(
            x = rect.getDouble("x").toFloat(),
            y = rect.getDouble("y").toFloat(),
            width = rect.getDouble("width").toFloat(),
            height = rect.getDouble("height").toFloat(),
        ),
        tags = tags,
        actions = objectActionsFromJson(obj.optJSONObject("actions") ?: JSONObject()),
        payload = payload,
        contextualPromotionAllowed = obj.optBoolean("contextualPromotionAllowed", true),
    )
}

private fun ObjectActions.toJson(): JSONObject = JSONObject()
    .put("tap", tap.toJson())
    .put("swipeUp", swipeUp.toJson())
    .put("swipeDown", swipeDown.toJson())
    .put("longPress", longPress.toJson())

private fun objectActionsFromJson(obj: JSONObject): ObjectActions = ObjectActions(
    tap = smartActionFromJson(obj.optJSONObject("tap")),
    swipeUp = smartActionFromJson(obj.optJSONObject("swipeUp")),
    swipeDown = smartActionFromJson(obj.optJSONObject("swipeDown")),
    longPress = smartActionFromJson(obj.optJSONObject("longPress")),
)

private fun SmartAction.toJson(): JSONObject = when (this) {
    is SmartAction.LaunchApp -> JSONObject().put("type", "launch_app").put("package", packageName).put("activity", activityName)
    is SmartAction.OpenCollection -> JSONObject().put("type", "open_collection").put("id", collectionId)
    is SmartAction.ShowSurface -> JSONObject().put("type", "show_surface").put("id", surfaceId)
    is SmartAction.RunCommand -> JSONObject().put("type", "run_command").put("command", command)
    SmartAction.None -> JSONObject().put("type", "none")
}

private fun smartActionFromJson(obj: JSONObject?): SmartAction {
    if (obj == null) return SmartAction.None
    return when (obj.optString("type", "none")) {
        "launch_app" -> SmartAction.LaunchApp(obj.optString("package"), obj.optString("activity"))
        "open_collection" -> SmartAction.OpenCollection(obj.optString("id"))
        "show_surface" -> SmartAction.ShowSurface(obj.optString("id"))
        "run_command" -> SmartAction.RunCommand(obj.optString("command"))
        else -> SmartAction.None
    }
}

private fun ContextRule.toJson(): JSONObject = JSONObject()
    .put("id", id)
    .put("name", name)
    .put("enabled", enabled)
    .put("userCreated", userCreated)
    .put("conditions", JSONArray().also { array -> conditions.forEach { array.put(it.toJson()) } })
    .put("effect", effect.toJson())

private fun ContextCondition.toJson(): JSONObject = when (this) {
    is ContextCondition.BatteryBelow -> JSONObject().put("type", "battery_below").put("percent", percent)
    is ContextCondition.ChargingIs -> JSONObject().put("type", "charging_is").put("charging", charging)
    is ContextCondition.TimeBetween -> JSONObject().put("type", "time_between").put("start", startHour).put("end", endHourExclusive)
    is ContextCondition.ProfileIs -> JSONObject().put("type", "profile_is").put("profile", profile.name)
    is ContextCondition.BluetoothConnected -> JSONObject().put("type", "bluetooth_connected").put("name", nameContains)
    is ContextCondition.EventWithin -> JSONObject().put("type", "event_within").put("minutes", minutes)
    is ContextCondition.RainWithin -> JSONObject().put("type", "rain_within").put("minutes", minutes)
}

private fun ContextEffect.toJson(): JSONObject = when (this) {
    is ContextEffect.PromoteWidget -> JSONObject().put("type", "promote_widget").put("kind", kind.name)
    is ContextEffect.SuggestCommand -> JSONObject().put("type", "suggest_command").put("title", title).put("command", command)
    is ContextEffect.SurfaceObject -> JSONObject().put("type", "surface_object").put("objectId", objectId)
}

private fun contextRuleFromJson(obj: JSONObject): ContextRule {
    val conditionsJson = obj.optJSONArray("conditions") ?: JSONArray()
    val conditions = buildList {
        for (i in 0 until conditionsJson.length()) contextConditionFromJson(conditionsJson.getJSONObject(i))?.let(::add)
    }
    return ContextRule(
        id = obj.getString("id"),
        name = obj.optString("name", "Automation"),
        enabled = obj.optBoolean("enabled", true),
        conditions = conditions,
        effect = contextEffectFromJson(obj.optJSONObject("effect") ?: JSONObject()),
        userCreated = obj.optBoolean("userCreated", false),
    )
}

private fun contextConditionFromJson(obj: JSONObject): ContextCondition? = when (obj.optString("type")) {
    "battery_below" -> ContextCondition.BatteryBelow(obj.optInt("percent", 20))
    "charging_is" -> ContextCondition.ChargingIs(obj.optBoolean("charging", true))
    "time_between" -> ContextCondition.TimeBetween(obj.optInt("start", 8), obj.optInt("end", 18))
    "profile_is" -> runCatching { ContextCondition.ProfileIs(LayoutProfile.valueOf(obj.getString("profile"))) }.getOrNull()
    "bluetooth_connected" -> ContextCondition.BluetoothConnected(obj.optString("name"))
    "event_within" -> ContextCondition.EventWithin(obj.optInt("minutes", 30))
    "rain_within" -> ContextCondition.RainWithin(obj.optInt("minutes", 45))
    else -> null
}

private fun contextEffectFromJson(obj: JSONObject): ContextEffect = when (obj.optString("type")) {
    "promote_widget" -> runCatching { ContextEffect.PromoteWidget(NativeWidgetKind.valueOf(obj.getString("kind"))) }
        .getOrDefault(ContextEffect.PromoteWidget(NativeWidgetKind.CLOCK))
    "suggest_command" -> ContextEffect.SuggestCommand(obj.optString("title", "Command"), obj.optString("command"))
    "surface_object" -> ContextEffect.SurfaceObject(obj.optString("objectId"))
    else -> ContextEffect.PromoteWidget(NativeWidgetKind.CLOCK)
}
