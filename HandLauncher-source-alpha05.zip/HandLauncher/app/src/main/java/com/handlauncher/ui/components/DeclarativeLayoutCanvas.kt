package com.handlauncher.ui.components

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.handlauncher.data.BatteryState
import com.handlauncher.data.MediaPlaybackState
import com.handlauncher.data.WeatherState
import com.handlauncher.domain.*
import com.handlauncher.platform.AndroidWidgetHostController
import com.handlauncher.ui.theme.LocalHandVisualTokens
import kotlin.math.abs
import kotlin.math.roundToInt

@Composable
fun DeclarativeLayoutCanvas(
    layout: LauncherLayout,
    apps: List<AppEntry>,
    battery: BatteryState,
    weather: WeatherState,
    media: MediaPlaybackState,
    contextDecision: ContextDecision,
    connectedDeviceNames: Set<String>,
    nextEventInMinutes: Int?,
    nextEventTitle: String? = null,
    nextEventStartMillis: Long? = null,
    smartStacks: Map<String, SmartStackDefinition>,
    editMode: Boolean,
    onGesture: (SmartObject, GestureSlot) -> Unit,
    onRectChange: (String, GridRect, Boolean) -> Unit,
    onRemoveObject: (SmartObject) -> Unit,
    onEditObject: (SmartObject) -> Unit,
    onOpenClock: () -> Unit = {},
    onOpenCalendar: () -> Unit = {},
    onOpenWeather: () -> Unit = {},
    onOpenBattery: () -> Unit = {},
    onOpenMedia: () -> Unit = {},
    onMediaPlayPause: () -> Unit = {},
    onMediaPrevious: () -> Unit = {},
    onMediaNext: () -> Unit = {},
    onBackgroundSwipeDown: (() -> Unit)? = null,
    onBackgroundSwipeUp: (() -> Unit)? = null,
    widgetHostController: AndroidWidgetHostController? = null,
    modifier: Modifier = Modifier,
) {
    val page = layout.pages.firstOrNull()
    if (page == null) {
        Box(modifier, contentAlignment = Alignment.Center) { Text("Empty layout", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        return
    }

    var canvasSize by remember { mutableStateOf(IntSize.Zero) }
    var backgroundGestureActive by remember { mutableStateOf(false) }
    var backgroundDrag by remember { mutableFloatStateOf(0f) }
    val density = LocalDensity.current
    val backgroundGestureThreshold = with(density) { 96.dp.toPx() }
    val maxGestureTravel = with(density) { 24.dp.toPx() }
    val backgroundTranslation by animateFloatAsState(
        targetValue = if (backgroundGestureActive) (backgroundDrag * 0.14f).coerceIn(-maxGestureTravel, maxGestureTravel) else 0f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "canvasGestureTranslation",
    )
    Box(
        modifier = modifier
            .graphicsLayer { translationY = backgroundTranslation }
            .onSizeChanged { canvasSize = it }
            .then(
                if (!editMode && (onBackgroundSwipeDown != null || onBackgroundSwipeUp != null)) {
                    Modifier.pointerInput(page.objects, canvasSize) {
                        detectVerticalDragGestures(
                            onDragStart = { offset ->
                                val width = canvasSize.width.coerceAtLeast(1).toFloat()
                                val height = canvasSize.height.coerceAtLeast(1).toFloat()
                                val x = offset.x / width
                                val y = offset.y / height
                                backgroundGestureActive = page.objects.none { obj ->
                                    x >= obj.rect.x && x <= obj.rect.x + obj.rect.width &&
                                        y >= obj.rect.y && y <= obj.rect.y + obj.rect.height
                                }
                                backgroundDrag = 0f
                            },
                            onVerticalDrag = { change, amount ->
                                if (backgroundGestureActive) {
                                    backgroundDrag += amount
                                    change.consume()
                                }
                            },
                            onDragEnd = {
                                if (backgroundGestureActive && abs(backgroundDrag) > backgroundGestureThreshold) {
                                    if (backgroundDrag > 0f) onBackgroundSwipeDown?.invoke() else onBackgroundSwipeUp?.invoke()
                                }
                                backgroundGestureActive = false
                                backgroundDrag = 0f
                            },
                            onDragCancel = {
                                backgroundGestureActive = false
                                backgroundDrag = 0f
                            },
                        )
                    }
                } else Modifier
            )
            .then(
                if (editMode) Modifier.border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.35f), RoundedCornerShape(22.dp))
                else Modifier
            )
    ) {
        if (editMode && !layout.finePositioning) GridGuide(layout.columns, layout.rows, Modifier.fillMaxSize())

        page.objects.forEach { obj ->
            val widthPx = canvasSize.width.coerceAtLeast(1)
            val heightPx = canvasSize.height.coerceAtLeast(1)
            val objectModifier = Modifier
                .offset {
                    IntOffset((widthPx * obj.rect.x).roundToInt(), (heightPx * obj.rect.y).roundToInt())
                }
                .width(with(density) { (widthPx * obj.rect.width).toDp() })
                .height(with(density) { (heightPx * obj.rect.height).toDp() })

            EditableObjectFrame(
                obj = obj,
                editMode = editMode,
                childConsumesGestures = obj.type == SmartObjectType.ANDROID_WIDGET,
                canvasSize = canvasSize,
                onGesture = onGesture,
                onRectChange = onRectChange,
                onRemove = { onRemoveObject(obj) },
                onEdit = { onEditObject(obj) },
                modifier = objectModifier,
            ) {
                when (obj.type) {
                    SmartObjectType.NATIVE_WIDGET -> {
                        val variant = obj.payload["variant"] ?: "standard"
                        when (runCatching { NativeWidgetKind.valueOf(obj.payload["widgetKind"].orEmpty()) }.getOrNull()) {
                            NativeWidgetKind.CLOCK -> ClockWidget(
                                Modifier.fillMaxSize(),
                                variant = variant,
                                showSeconds = obj.payload["showSeconds"] == "true",
                                showDate = obj.payload["showDate"] != "false",
                                onClick = onOpenClock,
                            )
                            NativeWidgetKind.CALENDAR -> CalendarWidget(Modifier.fillMaxSize(), variant, nextEventInMinutes, nextEventTitle, nextEventStartMillis, onOpenCalendar)
                            NativeWidgetKind.WEATHER -> WeatherWidget(weather, Modifier.fillMaxSize(), variant, onOpenWeather)
                            NativeWidgetKind.BATTERY -> BatteryWidget(
                                battery,
                                Modifier.fillMaxSize(),
                                variant,
                                connectedDeviceNames,
                                obj.payload["showDevices"] != "false",
                                onOpenBattery,
                            )
                            NativeWidgetKind.MEDIA -> MediaWidget(media, Modifier.fillMaxSize(), onOpenMedia, onMediaPlayPause, onMediaPrevious, onMediaNext)
                            NativeWidgetKind.CONTEXT -> SmartWidgetStack(
                                battery = battery,
                                contextDecision = contextDecision,
                                modifier = Modifier.fillMaxSize(),
                                connectedDeviceNames = connectedDeviceNames,
                                nextEventInMinutes = nextEventInMinutes,
                                nextEventTitle = nextEventTitle,
                                nextEventStartMillis = nextEventStartMillis,
                                weather = weather,
                                media = media,
                                onOpenClock = onOpenClock,
                                onOpenCalendar = onOpenCalendar,
                                onOpenWeather = onOpenWeather,
                                onOpenBattery = onOpenBattery,
                                onOpenMedia = onOpenMedia,
                                onMediaPlayPause = onMediaPlayPause,
                                onMediaPrevious = onMediaPrevious,
                                onMediaNext = onMediaNext,
                            )
                            else -> ClockWidget(Modifier.fillMaxSize(), variant, onClick = onOpenClock)
                        }
                    }

                    SmartObjectType.SMART_STACK -> SmartWidgetStack(
                        battery = battery,
                        contextDecision = contextDecision,
                        modifier = Modifier.fillMaxSize(),
                        definition = obj.payload["stackId"]?.let(smartStacks::get),
                        connectedDeviceNames = connectedDeviceNames,
                        nextEventInMinutes = nextEventInMinutes,
                        nextEventTitle = nextEventTitle,
                        nextEventStartMillis = nextEventStartMillis,
                        weather = weather,
                        media = media,
                        onOpenClock = onOpenClock,
                        onOpenCalendar = onOpenCalendar,
                        onOpenWeather = onOpenWeather,
                        onOpenBattery = onOpenBattery,
                        onOpenMedia = onOpenMedia,
                        onMediaPlayPause = onMediaPlayPause,
                        onMediaPrevious = onMediaPrevious,
                        onMediaNext = onMediaNext,
                    )

                    SmartObjectType.APP -> {
                        val app = apps.firstOrNull { it.stableId == obj.payload["appStableId"] }
                        if (app != null) AppIcon(
                            app = app,
                            displayLabel = obj.title,
                            onClick = {},
                            onLongClick = null,
                            interactionEnabled = false,
                            modifier = Modifier.fillMaxSize(),
                        )
                    }

                    SmartObjectType.ANDROID_WIDGET -> {
                        val id = obj.payload["appWidgetId"]?.toIntOrNull()
                        if (id != null && widgetHostController != null) {
                            AndroidHostedWidget(id, widgetHostController, Modifier.fillMaxSize())
                        } else ObjectPlaceholder(obj.title, Icons.Rounded.Widgets)
                    }

                    SmartObjectType.FOLDER -> ObjectPlaceholder(obj.title, Icons.Rounded.Folder)
                    SmartObjectType.COMMAND -> ObjectPlaceholder(obj.title, Icons.Rounded.Bolt)
                    SmartObjectType.SHORTCUT -> ObjectPlaceholder(obj.title, Icons.Rounded.TouchApp)
                }
            }
        }
    }
}

@Composable
private fun ObjectPlaceholder(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    val visuals = LocalHandVisualTokens.current
    Column(
        Modifier.fillMaxSize().background(
            MaterialTheme.colorScheme.surface.copy(alpha = visuals.surfaceAlpha),
            RoundedCornerShape(visuals.cornerRadiusDp.dp),
        ).padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Icon(icon, null)
        Text(title, style = MaterialTheme.typography.labelMedium, maxLines = 2)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun EditableObjectFrame(
    obj: SmartObject,
    editMode: Boolean,
    childConsumesGestures: Boolean,
    canvasSize: IntSize,
    onGesture: (SmartObject, GestureSlot) -> Unit,
    onRectChange: (String, GridRect, Boolean) -> Unit,
    onRemove: () -> Unit,
    onEdit: () -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit,
) {
    val latestRect by rememberUpdatedState(obj.rect)
    var verticalGesture by remember { mutableFloatStateOf(0f) }

    Box(
        modifier = modifier.then(
            if (editMode) {
                Modifier
                    .border(1.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(18.dp))
                    .pointerInput(obj.id, canvasSize) {
                        detectDragGestures(
                            onDrag = { change, amount ->
                                change.consume()
                                if (canvasSize.width > 0 && canvasSize.height > 0) {
                                    val rect = latestRect
                                    onRectChange(obj.id, rect.copy(x = rect.x + amount.x / canvasSize.width, y = rect.y + amount.y / canvasSize.height), false)
                                }
                            },
                            onDragEnd = { onRectChange(obj.id, latestRect, true) },
                        )
                    }
            } else if (!childConsumesGestures) {
                Modifier
                    .combinedClickable(
                        onClick = { onGesture(obj, GestureSlot.TAP) },
                        onLongClick = { onGesture(obj, GestureSlot.LONG_PRESS) },
                    )
                    .pointerInput(obj.id) {
                        detectVerticalDragGestures(
                            onVerticalDrag = { _, amount -> verticalGesture += amount },
                            onDragEnd = {
                                if (abs(verticalGesture) > 42f) onGesture(obj, if (verticalGesture < 0) GestureSlot.SWIPE_UP else GestureSlot.SWIPE_DOWN)
                                verticalGesture = 0f
                            },
                        )
                    }
            } else Modifier
        )
    ) {
        content()
        if (editMode) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .size(34.dp)
                    .background(MaterialTheme.colorScheme.secondaryContainer, RoundedCornerShape(12.dp))
                    .combinedClickable(onClick = onEdit, onLongClick = null),
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Rounded.Edit, contentDescription = "Edit object") }

            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .size(34.dp)
                    .background(MaterialTheme.colorScheme.errorContainer, RoundedCornerShape(12.dp))
                    .combinedClickable(onClick = onRemove, onLongClick = null),
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Rounded.Close, contentDescription = "Remove") }

            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .size(34.dp)
                    .background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(12.dp))
                    .pointerInput(obj.id, canvasSize) {
                        detectDragGestures(
                            onDrag = { change, amount ->
                                change.consume()
                                if (canvasSize.width > 0 && canvasSize.height > 0) {
                                    val rect = latestRect
                                    onRectChange(obj.id, rect.copy(width = rect.width + amount.x / canvasSize.width, height = rect.height + amount.y / canvasSize.height), false)
                                }
                            },
                            onDragEnd = { onRectChange(obj.id, latestRect, true) },
                        )
                    },
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Rounded.DragHandle, contentDescription = "Resize") }
        }
    }
}

@Composable
private fun GridGuide(columns: Int, rows: Int, modifier: Modifier = Modifier) {
    BoxWithConstraints(modifier) {
        for (column in 1 until columns) {
            Box(Modifier.offset(x = maxWidth * (column.toFloat() / columns)).width(1.dp).fillMaxHeight().background(MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.18f)))
        }
        for (row in 1 until rows) {
            Box(Modifier.offset(y = maxHeight * (row.toFloat() / rows)).height(1.dp).fillMaxWidth().background(MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.18f)))
        }
        Text("$columns × $rows grid", modifier = Modifier.align(Alignment.BottomStart).padding(8.dp), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
