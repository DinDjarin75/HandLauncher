package com.handlauncher.ui.theme

import android.app.WallpaperColors
import android.graphics.Bitmap
import android.graphics.Canvas
import androidx.core.graphics.ColorUtils
import android.app.WallpaperManager
import android.content.Context
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import com.handlauncher.domain.AiThemeTokens

@Immutable
data class HandVisualTokens(
    val cornerRadiusDp: Int = 28,
    val surfaceAlpha: Float = 0.72f,
    val typographyMood: String = "clean",
)

val LocalHandVisualTokens = staticCompositionLocalOf { HandVisualTokens() }

/**
 * Returns true when Hand should use a dark Material palette (light foreground).
 * Transparent launcher surfaces sit directly over the wallpaper, so foreground
 * contrast follows a small sample of the upper wallpaper rather than trusting the
 * AI theme's requested light/dark mode.
 */
fun resolveWallpaperDarkPalette(context: Context, fallbackDark: Boolean = true): Boolean {
    // WallpaperColors describes the whole image and can choose dark text for a mixed
    // wallpaper even when the launcher header sits over a dark area. Sample a tiny
    // rendering of the upper wallpaper instead; app labels also carry an opposite
    // shadow for local contrast changes lower on the screen.
    val sampled = runCatching {
        val drawable = WallpaperManager.getInstance(context).drawable ?: return@runCatching null
        val bitmap = Bitmap.createBitmap(48, 48, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        drawable.setBounds(0, 0, bitmap.width, bitmap.height)
        drawable.draw(canvas)

        var luminanceSum = 0.0
        var darkPixels = 0
        var samples = 0
        val maxY = (bitmap.height * 0.72f).toInt().coerceAtLeast(1)
        for (y in 0 until maxY step 2) {
            for (x in 0 until bitmap.width step 2) {
                val luminance = ColorUtils.calculateLuminance(bitmap.getPixel(x, y))
                luminanceSum += luminance
                if (luminance < 0.45) darkPixels++
                samples++
            }
        }
        bitmap.recycle()
        if (samples == 0) null else {
            val average = luminanceSum / samples
            val darkShare = darkPixels.toDouble() / samples
            average < 0.54 || darkShare >= 0.55
        }
    }.getOrNull()
    if (sampled != null) return sampled

    return runCatching {
        val colors = WallpaperManager.getInstance(context)
            .getWallpaperColors(WallpaperManager.FLAG_SYSTEM)
            ?: return@runCatching fallbackDark
        val supportsDarkText = colors.colorHints and WallpaperColors.HINT_SUPPORTS_DARK_TEXT != 0
        !supportsDarkText
    }.getOrDefault(fallbackDark)
}

@Composable
fun HandLauncherTheme(
    theme: AiThemeTokens? = null,
    darkTheme: Boolean = theme?.dark ?: true,
    content: @Composable () -> Unit,
) {
    val context = LocalContext.current
    val wallpaperDarkPalette = remember(context, darkTheme) {
        resolveWallpaperDarkPalette(context, darkTheme)
    }

    val mood = theme?.typographyMood?.lowercase() ?: "clean"
    val visuals = HandVisualTokens(
        cornerRadiusDp = (theme?.cornerRadiusDp ?: 28).coerceIn(0, 48),
        surfaceAlpha = (1f - (theme?.transparencyPercent ?: 28).coerceIn(0, 85) / 100f).coerceIn(0.15f, 1f),
        typographyMood = mood,
    )
    val base = Typography()
    val typography = when (mood) {
        "bold" -> Typography(
            displayLarge = base.displayLarge.copy(fontWeight = FontWeight.Bold),
            displayMedium = base.displayMedium.copy(fontWeight = FontWeight.Bold),
            headlineLarge = base.headlineLarge.copy(fontWeight = FontWeight.Bold),
            titleLarge = base.titleLarge.copy(fontWeight = FontWeight.Bold),
        )
        "editorial" -> Typography(
            displayLarge = base.displayLarge.copy(fontFamily = FontFamily.Serif, fontWeight = FontWeight.Light),
            displayMedium = base.displayMedium.copy(fontFamily = FontFamily.Serif, fontWeight = FontWeight.Light),
            headlineLarge = base.headlineLarge.copy(fontFamily = FontFamily.Serif),
            titleLarge = base.titleLarge.copy(fontFamily = FontFamily.Serif),
        )
        "minimal" -> Typography(
            displayLarge = base.displayLarge.copy(fontWeight = FontWeight.Thin),
            displayMedium = base.displayMedium.copy(fontWeight = FontWeight.Thin),
            headlineLarge = base.headlineLarge.copy(fontWeight = FontWeight.Light),
            titleLarge = base.titleLarge.copy(fontWeight = FontWeight.Light),
        )
        else -> base
    }

    val colorScheme = if (wallpaperDarkPalette) {
        darkColorScheme(
            onBackground = Color(0xFFF7F5FF),
            onSurface = Color(0xFFF7F5FF),
            onSurfaceVariant = Color(0xFFD6D0E0),
        )
    } else {
        lightColorScheme(
            onBackground = Color(0xFF111015),
            onSurface = Color(0xFF111015),
            onSurfaceVariant = Color(0xFF4F4A55),
        )
    }

    androidx.compose.runtime.CompositionLocalProvider(LocalHandVisualTokens provides visuals) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = typography,
            content = content,
        )
    }
}
