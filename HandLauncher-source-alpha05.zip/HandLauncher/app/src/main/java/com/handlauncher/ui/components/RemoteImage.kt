package com.handlauncher.ui.components

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Newspaper
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

private object ArticleImageMemoryCache {
    private val cache = object : LruCache<String, Bitmap>(14 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount / 1024
    }
    fun get(url: String): Bitmap? = cache.get(url)
    fun put(url: String, bitmap: Bitmap) { cache.put(url, bitmap) }
}

@Composable
fun RemoteArticleImage(
    imageUrl: String?,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    articleUrl: String? = null,
) {
    val bitmap = produceState<Bitmap?>(initialValue = imageUrl?.let(ArticleImageMemoryCache::get), key1 = imageUrl, key2 = articleUrl) {
        if (value != null || imageUrl.isNullOrBlank()) return@produceState
        value = withContext(Dispatchers.IO) {
            runCatching {
                val connection = (URL(imageUrl).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 5_500
                    readTimeout = 8_000
                    instanceFollowRedirects = true
                    setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 16) AppleWebKit/537.36 Chrome/140 Mobile Safari/537.36")
                    setRequestProperty("Accept", "image/jpeg,image/png,image/webp,image/*;q=0.8,*/*;q=0.5")
                    articleUrl?.takeIf { it.startsWith("http") }?.let { setRequestProperty("Referer", it) }
                }
                connection.inputStream.buffered().use { stream ->
                    BitmapFactory.decodeStream(stream, null, BitmapFactory.Options().apply { inSampleSize = 2 })
                }?.takeIf { it.width >= 120 && it.height >= 80 }
                    ?.also { ArticleImageMemoryCache.put(imageUrl, it) }
            }.getOrNull()
        }
    }.value

    val clipped = modifier.clip(RoundedCornerShape(topStart = 18.dp, bottomStart = 18.dp))
    if (bitmap != null) {
        Image(bitmap = bitmap.asImageBitmap(), contentDescription = contentDescription, modifier = clipped, contentScale = ContentScale.Crop)
    } else {
        Box(modifier = clipped.background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.40f)), contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.Newspaper, contentDescription = null, modifier = Modifier.fillMaxSize(0.28f))
        }
    }
}
