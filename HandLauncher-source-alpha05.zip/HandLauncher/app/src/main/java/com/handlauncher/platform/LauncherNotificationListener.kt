package com.handlauncher.platform

import android.service.notification.NotificationListenerService

/** Grants the launcher access to Android's active media sessions when the user enables it. */
class LauncherNotificationListener : NotificationListenerService()
