package com.handlauncher.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Manual/coarse location avoids background location permission for a launcher. */
data class WeatherLocation(
    val label: String = "Luxembourg",
    val latitude: Double = 49.6116,
    val longitude: Double = 6.1319,
)

data class DailyForecast(
    val dayLabel: String,
    val highC: Double?,
    val lowC: Double?,
    val condition: String,
    val precipitationChancePercent: Int?,
)

data class WeatherState(
    val location: WeatherLocation = WeatherLocation(),
    val temperatureC: Double? = null,
    val condition: String = "Unavailable",
    val rainExpectedInMinutes: Int? = null,
    val available: Boolean = false,
    val dailyForecast: List<DailyForecast> = emptyList(),
)

class WeatherRepository(context: Context) {
    private val prefs = context.getSharedPreferences("hand_weather", Context.MODE_PRIVATE)

    fun location(): WeatherLocation = WeatherLocation(
        label = prefs.getString(KEY_LABEL, "Luxembourg") ?: "Luxembourg",
        latitude = java.lang.Double.longBitsToDouble(prefs.getLong(KEY_LAT, java.lang.Double.doubleToRawLongBits(49.6116))),
        longitude = java.lang.Double.longBitsToDouble(prefs.getLong(KEY_LON, java.lang.Double.doubleToRawLongBits(6.1319))),
    )

    fun saveLocation(location: WeatherLocation) {
        prefs.edit()
            .putString(KEY_LABEL, location.label.trim().ifBlank { "Weather" })
            .putLong(KEY_LAT, java.lang.Double.doubleToRawLongBits(location.latitude.coerceIn(-90.0, 90.0)))
            .putLong(KEY_LON, java.lang.Double.doubleToRawLongBits(location.longitude.coerceIn(-180.0, 180.0)))
            .apply()
    }

    suspend fun refresh(): WeatherState = withContext(Dispatchers.IO) {
        val location = location()
        runCatching {
            val endpoint = "https://api.open-meteo.com/v1/forecast" +
                "?latitude=${location.latitude}&longitude=${location.longitude}" +
                "&current=temperature_2m,weather_code" +
                "&hourly=precipitation_probability&forecast_hours=12" +
                "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max" +
                "&forecast_days=4&timezone=auto"
            val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                connectTimeout = 8_000
                readTimeout = 10_000
                requestMethod = "GET"
            }
            val raw = connection.inputStream.bufferedReader().use { it.readText() }
            val root = JSONObject(raw)
            val current = root.getJSONObject("current")
            val temp = current.optDouble("temperature_2m")
            val code = current.optInt("weather_code", -1)
            val hourly = root.optJSONObject("hourly")
            val probabilities = hourly?.optJSONArray("precipitation_probability")
            var rainMinutes: Int? = null
            if (probabilities != null) {
                for (i in 0 until probabilities.length()) {
                    if (probabilities.optInt(i, 0) >= 50) {
                        rainMinutes = i * 60
                        break
                    }
                }
            }
            val daily = root.optJSONObject("daily")
            val days = buildList {
                val times = daily?.optJSONArray("time")
                val codes = daily?.optJSONArray("weather_code")
                val highs = daily?.optJSONArray("temperature_2m_max")
                val lows = daily?.optJSONArray("temperature_2m_min")
                val precip = daily?.optJSONArray("precipitation_probability_max")
                if (times != null) {
                    for (i in 0 until minOf(times.length(), 4)) {
                        val rawDay = times.optString(i)
                        val label = runCatching {
                            java.time.LocalDate.parse(rawDay).format(java.time.format.DateTimeFormatter.ofPattern("EEE"))
                        }.getOrDefault(rawDay)
                        add(
                            DailyForecast(
                                dayLabel = if (i == 0) "Today" else label,
                                highC = highs?.optDouble(i).takeUnless { it == null || it.isNaN() },
                                lowC = lows?.optDouble(i).takeUnless { it == null || it.isNaN() },
                                condition = weatherCodeLabel(codes?.optInt(i, -1) ?: -1),
                                precipitationChancePercent = precip?.optInt(i, -1)?.takeIf { it >= 0 },
                            )
                        )
                    }
                }
            }
            WeatherState(location, temp, weatherCodeLabel(code), rainMinutes, true, days)
        }.getOrElse { WeatherState(location = location, condition = "Weather unavailable") }
    }

    private fun weatherCodeLabel(code: Int): String = when (code) {
        0 -> "Clear"
        1, 2 -> "Partly cloudy"
        3 -> "Overcast"
        45, 48 -> "Fog"
        in 51..57 -> "Drizzle"
        in 61..67 -> "Rain"
        in 71..77 -> "Snow"
        in 80..82 -> "Showers"
        in 85..86 -> "Snow showers"
        in 95..99 -> "Thunderstorm"
        else -> "Conditions unavailable"
    }

    companion object {
        private const val KEY_LABEL = "label"
        private const val KEY_LAT = "lat"
        private const val KEY_LON = "lon"
    }
}
