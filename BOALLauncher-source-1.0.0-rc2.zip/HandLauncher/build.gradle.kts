buildscript {
    dependencies {
        // AGP 9.x provides built-in Kotlin. Pin its KGP runtime to the same
        // release as the Compose compiler plugin so the compiler versions match.
        classpath("org.jetbrains.kotlin:kotlin-gradle-plugin:2.4.10")
    }
}

plugins {
    id("com.android.application") version "9.4.0" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.4.10" apply false
}
