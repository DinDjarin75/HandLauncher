package com.handlauncher.platform

import android.app.Activity
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.Context
import android.content.Intent
import android.os.Bundle

/**
 * Platform bridge for real Android widgets. Widget IDs are durable launcher data;
 * callers must persist them until removal and then call deleteAppWidgetId().
 */
class AndroidWidgetHostController(private val context: Context) {
    private val manager = AppWidgetManager.getInstance(context)
    val host: AppWidgetHost = AppWidgetHost(context, HOST_ID)

    fun startListening() = host.startListening()
    fun stopListening() = host.stopListening()

    fun allocateId(): Int = host.allocateAppWidgetId()
    fun deleteId(id: Int) = host.deleteAppWidgetId(id)

    fun createSystemPickerIntent(appWidgetId: Int): Intent =
        Intent(AppWidgetManager.ACTION_APPWIDGET_PICK).apply {
            putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId)
        }

    fun providerInfo(appWidgetId: Int) = manager.getAppWidgetInfo(appWidgetId)

    fun providersForPackage(packageName: String): List<AppWidgetProviderInfo> =
        manager.installedProviders.filter { it.provider.packageName == packageName }

    fun bindIfAllowed(appWidgetId: Int, providerInfo: AppWidgetProviderInfo): Boolean =
        manager.bindAppWidgetIdIfAllowed(appWidgetId, providerInfo.provider)

    fun createBindIntent(appWidgetId: Int, providerInfo: AppWidgetProviderInfo): Intent =
        Intent(AppWidgetManager.ACTION_APPWIDGET_BIND).apply {
            putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId)
            putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, providerInfo.provider)
        }

    fun createHostView(appWidgetId: Int): AppWidgetHostView? {
        val info = providerInfo(appWidgetId) ?: return null
        return host.createView(context, appWidgetId, info).apply {
            setAppWidget(appWidgetId, info)
        }
    }

    fun createConfigureIntent(appWidgetId: Int): Intent? {
        val info = providerInfo(appWidgetId) ?: return null
        val configure = info.configure ?: return null
        return Intent(AppWidgetManager.ACTION_APPWIDGET_CONFIGURE).apply {
            component = configure
            putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId)
        }
    }

    fun updateSize(appWidgetId: Int, minWidthDp: Int, minHeightDp: Int, maxWidthDp: Int, maxHeightDp: Int) {
        val options = Bundle().apply {
            putInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, minWidthDp)
            putInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, minHeightDp)
            putInt(AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH, maxWidthDp)
            putInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, maxHeightDp)
        }
        manager.updateAppWidgetOptions(appWidgetId, options)
    }

    companion object {
        const val HOST_ID = 0x48414E44 // "HAND"

        fun widgetIdFromResult(data: Intent?, fallback: Int): Int =
            data?.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, fallback) ?: fallback

        fun resultSucceeded(resultCode: Int) = resultCode == Activity.RESULT_OK
    }
}
