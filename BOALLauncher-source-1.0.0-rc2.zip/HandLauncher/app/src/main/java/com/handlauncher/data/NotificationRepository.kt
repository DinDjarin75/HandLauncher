package com.handlauncher.data

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ComponentName
import android.content.Context
import com.handlauncher.platform.LauncherNotificationListener
import kotlinx.coroutines.flow.StateFlow

data class LauncherNotification(
    val key: String,
    val packageName: String,
    val title: String,
    val text: String,
    val postTime: Long,
    val contentIntent: PendingIntent?,
    val fullScreenIntent: PendingIntent?,
)

class NotificationRepository(private val context: Context) {
    private val listener = ComponentName(context, LauncherNotificationListener::class.java)
    private val notificationManager = context.getSystemService(NotificationManager::class.java)

    val notifications: StateFlow<List<LauncherNotification>> = LauncherNotificationListener.notifications

    fun hasAccess(): Boolean = notificationManager.isNotificationListenerAccessGranted(listener)
    fun ensureConnected() = LauncherNotificationListener.ensureConnected(context)
    fun dismiss(key: String) = LauncherNotificationListener.dismiss(key)
}
