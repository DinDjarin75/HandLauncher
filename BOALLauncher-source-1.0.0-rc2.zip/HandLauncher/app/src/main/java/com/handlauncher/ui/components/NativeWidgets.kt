package com.handlauncher.ui.components

import android.app.AlarmManager
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.handlauncher.data.BatteryState
import com.handlauncher.data.MediaPlaybackState
import com.handlauncher.data.ConnectivityState
import com.handlauncher.data.WeatherState
import com.handlauncher.domain.*
import com.handlauncher.ui.theme.LocalHandAccentPalette
import kotlinx.coroutines.delay
import java.time.Instant
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter

@Composable
private fun WidgetSurface(
    modifier: Modifier = Modifier,
    compactPadding: Boolean = false,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    val clickModifier = if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier
    HandGlassSurface(
        modifier = modifier.fillMaxWidth().then(clickModifier),
        contentPadding = PaddingValues(if (compactPadding) 12.dp else 18.dp),
    ) { Column(content = content) }
}

@Composable
private fun WidgetHeader(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
) {
    val accent = LocalHandAccentPalette.current
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Icon(icon, contentDescription = null, tint = accent.accentStrong, modifier = Modifier.size(23.dp))
        Text(label, style = MaterialTheme.typography.labelMedium, letterSpacing = 0.8.sp)
    }
}

@Composable
private fun AccentGauge(
    progress: Float,
    modifier: Modifier = Modifier,
    centerContent: @Composable BoxScope.() -> Unit,
) {
    val accent = LocalHandAccentPalette.current
    val track = LocalContentColor.current.copy(alpha = 0.12f)
    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val strokeWidth = size.minDimension * 0.065f
            val inset = strokeWidth / 2f + 1f
            val arcSize = androidx.compose.ui.geometry.Size(
                width = size.width - inset * 2f,
                height = size.height - inset * 2f,
            )
            drawArc(
                color = track,
                startAngle = 135f,
                sweepAngle = 270f,
                useCenter = false,
                topLeft = Offset(inset, inset),
                size = arcSize,
                style = Stroke(strokeWidth, cap = StrokeCap.Round),
            )
            drawArc(
                color = accent.accentStrong,
                startAngle = 135f,
                sweepAngle = 270f * progress.coerceIn(0f, 1f),
                useCenter = false,
                topLeft = Offset(inset, inset),
                size = arcSize,
                style = Stroke(strokeWidth, cap = StrokeCap.Round),
            )
        }
        centerContent()
    }
}

@Composable
private fun MediaControlButton(
    primary: Boolean = false,
    contentDescription: String,
    onClick: () -> Unit,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
) {
    val accent = LocalHandAccentPalette.current
    val size = if (primary) 48.dp else 40.dp
    Box(
        modifier = Modifier
            .size(size)
            .clip(CircleShape)
            .background(if (primary) accent.accentSoft else LocalContentColor.current.copy(alpha = 0.07f))
            .border(0.8.dp, if (primary) accent.outline else LocalContentColor.current.copy(alpha = 0.12f), CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        IconButton(onClick = onClick, modifier = Modifier.fillMaxSize()) {
            Icon(icon, contentDescription = contentDescription, tint = if (primary) accent.accentStrong else LocalContentColor.current)
        }
    }
}

private fun formatMediaTime(durationMs: Long): String {
    val totalSeconds = (durationMs.coerceAtLeast(0L) / 1000L)
    val hours = totalSeconds / 3600L
    val minutes = (totalSeconds % 3600L) / 60L
    val seconds = totalSeconds % 60L
    return if (hours > 0L) "%d:%02d:%02d".format(hours, minutes, seconds)
    else "%d:%02d".format(minutes, seconds)
}

@Composable
fun ClockWidget(
    modifier: Modifier = Modifier,
    variant: String = "standard",
    showSeconds: Boolean = false,
    showDate: Boolean = true,
    onClick: (() -> Unit)? = null,
) {
    val context = LocalContext.current
    val alarmManager = remember(context) { context.getSystemService(AlarmManager::class.java) }
    var now by remember { mutableStateOf(LocalTime.now()) }
    var nextAlarmMillis by remember { mutableStateOf(runCatching { alarmManager.nextAlarmClock?.triggerTime }.getOrNull()) }

    LaunchedEffect(showSeconds, alarmManager) {
        while (true) {
            now = LocalTime.now()
            nextAlarmMillis = runCatching { alarmManager.nextAlarmClock?.triggerTime }.getOrNull()
            delay(if (showSeconds) 1000 else 15_000)
        }
    }

    WidgetSurface(modifier, compactPadding = variant == "minimal", onClick = onClick) {
        if (variant == "minimal") {
            Text(
                now.format(DateTimeFormatter.ofPattern(if (showSeconds) "HH:mm:ss" else "HH:mm")),
                style = MaterialTheme.typography.displaySmall,
                fontWeight = FontWeight.Light,
            )
            if (showDate) Text(LocalDate.now().format(DateTimeFormatter.ofPattern("EEE, d MMM")))
            return@WidgetSurface
        }

        WidgetHeader(Icons.Rounded.Schedule, "CLOCK")
        Spacer(Modifier.height(4.dp))
        Row(
            modifier = Modifier.fillMaxWidth().weight(1f),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(
                modifier = Modifier.weight(0.62f),
                verticalArrangement = Arrangement.Center,
            ) {
                Text(
                    now.format(DateTimeFormatter.ofPattern(if (showSeconds) "HH:mm:ss" else "HH:mm")),
                    style = MaterialTheme.typography.displayMedium,
                    fontWeight = FontWeight.Light,
                    maxLines = 1,
                )
                if (showDate) {
                    Text(
                        LocalDate.now().format(DateTimeFormatter.ofPattern(if (variant == "detailed") "EEEE, d MMMM yyyy" else "EEEE, d MMMM")),
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                Spacer(Modifier.height(7.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(Icons.Rounded.Alarm, null, modifier = Modifier.size(18.dp), tint = LocalContentColor.current.copy(alpha = 0.72f))
                    val alarmText = nextAlarmMillis?.let { millis ->
                        val localTime = Instant.ofEpochMilli(millis).atZone(ZoneId.systemDefault()).toLocalTime()
                        "Next alarm · ${localTime.format(DateTimeFormatter.ofPattern("HH:mm"))}"
                    } ?: "No alarm set"
                    Text(
                        alarmText,
                        style = MaterialTheme.typography.bodySmall,
                        color = LocalContentColor.current.copy(alpha = 0.72f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }

            val secondsIntoDay = now.toSecondOfDay().toFloat()
            val dayProgress = (secondsIntoDay / (24f * 60f * 60f)).coerceIn(0f, 1f)
            AccentGauge(
                progress = dayProgress,
                modifier = Modifier.weight(0.38f).aspectRatio(1f).sizeIn(maxWidth = 126.dp, maxHeight = 126.dp),
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Rounded.WbSunny, null, modifier = Modifier.size(22.dp), tint = LocalHandAccentPalette.current.accentStrong)
                    Text("DAY", style = MaterialTheme.typography.labelSmall, color = LocalContentColor.current.copy(alpha = 0.66f))
                    Text("${(dayProgress * 100f).toInt()}%", style = MaterialTheme.typography.titleMedium, color = LocalHandAccentPalette.current.accentStrong, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

@Composable
fun CalendarWidget(
    modifier: Modifier = Modifier,
    variant: String = "standard",
    nextEventInMinutes: Int? = null,
    nextEventTitle: String? = null,
    nextEventStartMillis: Long? = null,
    onOpenCalendar: (() -> Unit)? = null,
    onOpenEvent: (() -> Unit)? = null,
) {
    val today = LocalDate.now()
    WidgetSurface(modifier, compactPadding = variant == "minimal") {
        if (variant != "minimal") {
            Row(
                modifier = Modifier.then(if (onOpenCalendar != null) Modifier.clickable(onClick = onOpenCalendar) else Modifier),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Icon(Icons.Rounded.CalendarMonth, null, tint = LocalHandAccentPalette.current.accentStrong)
                Text("CALENDAR", style = MaterialTheme.typography.labelMedium, letterSpacing = 0.8.sp)
            }
            Spacer(Modifier.height(8.dp))
        }
        Column(
            modifier = Modifier.then(if (variant == "minimal" && onOpenCalendar != null) Modifier.clickable(onClick = onOpenCalendar) else Modifier)
        ) {
            Text(today.dayOfMonth.toString(), style = MaterialTheme.typography.displaySmall)
            Text(today.format(DateTimeFormatter.ofPattern("EEEE · MMMM yyyy")))
        }
        if (nextEventInMinutes != null) {
            Spacer(Modifier.height(4.dp))
            val timing = humanEventTime(nextEventStartMillis, nextEventInMinutes)
            Column(
                modifier = Modifier.then(if (onOpenEvent != null) Modifier.clickable(onClick = onOpenEvent) else Modifier)
            ) {
                Text(
                    nextEventTitle.orEmpty().ifBlank { "Next event" },
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.primary,
                    maxLines = if (variant == "detailed") 2 else 1,
                )
                timing?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = LocalContentColor.current.copy(alpha = 0.78f)) }
            }
        } else if (variant == "detailed") {
            Text("Nothing upcoming", style = MaterialTheme.typography.bodySmall, color = LocalContentColor.current.copy(alpha = 0.76f))
        }
    }
}

@Composable
fun WeatherWidget(
    weather: WeatherState,
    modifier: Modifier = Modifier,
    variant: String = "standard",
    onClick: (() -> Unit)? = null,
) {
    WidgetSurface(modifier, compactPadding = variant == "minimal", onClick = onClick) {
        if (variant != "minimal") {
            Text(weather.location.label.uppercase(), style = MaterialTheme.typography.labelMedium, color = LocalHandAccentPalette.current.accentStrong, letterSpacing = 0.8.sp)
            Spacer(Modifier.height(6.dp))
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            WeatherGraphic(weather.condition, Modifier.size(if (variant == "minimal") 50.dp else 64.dp))
            Column(Modifier.weight(1f)) {
                Text(weather.temperatureC?.let { "${kotlin.math.round(it).toInt()}°" } ?: "—°", style = MaterialTheme.typography.displaySmall)
                Text(weather.condition)
                if (variant == "detailed" && weather.rainExpectedInMinutes != null) {
                    Text("Rain possible in ~${weather.rainExpectedInMinutes} min", style = MaterialTheme.typography.bodySmall, color = LocalContentColor.current.copy(alpha = 0.76f))
                }
            }
        }
        if (variant != "minimal" && weather.dailyForecast.isNotEmpty()) {
            Spacer(Modifier.height(10.dp))
            HorizontalDivider(color = LocalContentColor.current.copy(alpha = 0.16f))
            Spacer(Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top,
            ) {
                weather.dailyForecast.take(5).forEach { day ->
                    Column(
                        modifier = Modifier.weight(1f),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(2.dp),
                    ) {
                        Text(day.dayLabel, style = MaterialTheme.typography.labelSmall, maxLines = 1)
                        WeatherGraphic(day.condition, Modifier.size(24.dp))
                        Text(
                            listOfNotNull(
                                day.highC?.let { "${kotlin.math.round(it).toInt()}°" },
                                day.lowC?.let { "${kotlin.math.round(it).toInt()}°" },
                            ).joinToString("/").ifBlank { "—" },
                            style = MaterialTheme.typography.labelSmall,
                            maxLines = 1,
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun BatteryWidget(
    battery: BatteryState,
    modifier: Modifier = Modifier,
    variant: String = "standard",
    connectedDeviceNames: Set<String> = emptySet(),
    showDevices: Boolean = true,
    onClick: (() -> Unit)? = null,
) {
    WidgetSurface(modifier, compactPadding = variant == "minimal", onClick = onClick) {
        if (variant == "minimal") {
            Text("${battery.percent}%", style = MaterialTheme.typography.displaySmall)
            Text(if (battery.charging) "Phone · charging" else "Phone")
            return@WidgetSurface
        }

        WidgetHeader(Icons.Rounded.BatteryFull, "BATTERY")
        Spacer(Modifier.height(4.dp))
        Row(
            modifier = Modifier.fillMaxWidth().weight(1f),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(
                modifier = Modifier.weight(0.62f),
                verticalArrangement = Arrangement.Center,
            ) {
                Text(
                    "${battery.percent}%",
                    style = MaterialTheme.typography.displayMedium,
                    fontWeight = FontWeight.Light,
                    maxLines = 1,
                )
                Text(
                    if (battery.charging) "Phone · charging" else "Phone",
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 1,
                )
                if (showDevices && connectedDeviceNames.isNotEmpty()) {
                    Spacer(Modifier.height(3.dp))
                    Text(
                        "Connected · ${connectedDeviceNames.take(if (variant == "detailed") 3 else 2).joinToString(" · ")}",
                        style = MaterialTheme.typography.bodySmall,
                        color = LocalContentColor.current.copy(alpha = 0.72f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                Spacer(Modifier.height(7.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(
                        if (battery.charging) Icons.Rounded.Bolt else Icons.Rounded.BatteryStd,
                        null,
                        modifier = Modifier.size(18.dp),
                        tint = LocalHandAccentPalette.current.accentStrong,
                    )
                    Text(
                        if (battery.charging) "Charging" else "On battery",
                        style = MaterialTheme.typography.bodySmall,
                        color = LocalContentColor.current.copy(alpha = 0.72f),
                    )
                }
            }

            AccentGauge(
                progress = battery.percent.coerceIn(0, 100) / 100f,
                modifier = Modifier.weight(0.38f).aspectRatio(1f).sizeIn(maxWidth = 126.dp, maxHeight = 126.dp),
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        if (battery.charging) Icons.Rounded.BatteryChargingFull else Icons.Rounded.BatteryStd,
                        null,
                        modifier = Modifier.size(34.dp),
                        tint = LocalHandAccentPalette.current.accentStrong,
                    )
                }
            }
        }
    }
}

@Composable
fun ConnectivityWidget(
    connectivity: ConnectivityState,
    modifier: Modifier = Modifier,
) {
    WidgetSurface(modifier = modifier) {
        Text("CONNECTIVITY", style = MaterialTheme.typography.labelMedium, color = LocalHandAccentPalette.current.accentStrong, letterSpacing = 0.8.sp)
        Spacer(Modifier.height(8.dp))

        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Icon(Icons.Rounded.Wifi, contentDescription = null, modifier = Modifier.size(25.dp), tint = LocalHandAccentPalette.current.accentStrong)
            Column(Modifier.weight(1f)) {
                Text(connectivity.wifiName, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    connectivity.wifiSpeedMbps?.let { "$it Mbps" } ?: if (connectivity.wifiConnected) "Connected" else "Wi-Fi off",
                    style = MaterialTheme.typography.bodySmall,
                    color = LocalContentColor.current.copy(alpha = 0.72f),
                )
            }
        }

        Spacer(Modifier.height(9.dp))
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Box(
                modifier = Modifier.width(30.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    connectivity.mobileType,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = LocalHandAccentPalette.current.accentStrong,
                    maxLines = 1,
                )
            }
            Column(Modifier.weight(1f)) {
                Text(connectivity.operatorName, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    connectivity.mobileType,
                    style = MaterialTheme.typography.bodySmall,
                    color = LocalHandAccentPalette.current.accentStrong.copy(alpha = 0.78f),
                    maxLines = 1,
                )
            }
            SignalBars(connectivity.mobileSignalLevel)
        }

        Spacer(Modifier.height(9.dp))
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Icon(Icons.Rounded.Bluetooth, contentDescription = null, modifier = Modifier.size(25.dp), tint = LocalHandAccentPalette.current.accentStrong)
            Column(Modifier.weight(1f)) {
                Text("Bluetooth", style = MaterialTheme.typography.titleSmall)
                Text(
                    connectivity.bluetoothDeviceNames.take(3).joinToString(" · ").ifBlank { "No connected devices" },
                    style = MaterialTheme.typography.bodySmall,
                    color = LocalContentColor.current.copy(alpha = 0.72f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}

@Composable
private fun SignalBars(level: Int?) {
    Row(
        modifier = Modifier.height(24.dp),
        verticalAlignment = Alignment.Bottom,
        horizontalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        repeat(4) { index ->
            val active = level != null && index < level
            Box(
                Modifier
                    .width(4.dp)
                    .height((7 + index * 4).dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(if (active) LocalHandAccentPalette.current.accentStrong else LocalContentColor.current.copy(alpha = 0.20f))
            )
        }
    }
}

@Composable
fun MediaWidget(
    media: MediaPlaybackState,
    modifier: Modifier = Modifier,
    outputDeviceName: String? = null,
    onOpen: () -> Unit,
    onPlayPause: () -> Unit,
    onPrevious: () -> Unit,
    onNext: () -> Unit,
    onSeek: (Long) -> Unit = {},
) {
    val accent = LocalHandAccentPalette.current
    val duration = media.durationMs.coerceAtLeast(0L)
    var scrubbing by remember(media.sessionId) { mutableStateOf(false) }
    var localPosition by remember(media.sessionId) { mutableFloatStateOf(media.positionMs.toFloat()) }
    LaunchedEffect(media.positionMs, media.sessionId, scrubbing) {
        if (!scrubbing) localPosition = media.positionMs.toFloat()
    }
    LaunchedEffect(media.sessionId, media.playing, scrubbing, duration) {
        while (media.playing && !scrubbing) {
            delay(500)
            localPosition = if (duration > 0L) {
                (localPosition + 500f).coerceAtMost(duration.toFloat())
            } else {
                localPosition + 500f
            }
        }
    }

    WidgetSurface(modifier = modifier, onClick = onOpen) {
        Row(
            modifier = Modifier.fillMaxWidth().weight(1f),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            if (media.artwork != null) {
                Image(
                    bitmap = media.artwork.asImageBitmap(),
                    contentDescription = null,
                    modifier = Modifier.size(90.dp).clip(RoundedCornerShape(20.dp)),
                    contentScale = ContentScale.Crop,
                )
            } else {
                Box(
                    Modifier
                        .size(90.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .background(accent.accentFaint)
                        .border(0.8.dp, accent.outline, RoundedCornerShape(20.dp)),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(Icons.Rounded.GraphicEq, null, modifier = Modifier.size(38.dp), tint = accent.accentStrong)
                }
            }

            Column(
                modifier = Modifier.weight(1f).fillMaxHeight(),
                verticalArrangement = Arrangement.Center,
            ) {
                Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            media.title.ifBlank { "Now playing" },
                            style = MaterialTheme.typography.titleMedium,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                        )
                        if (media.subtitle.isNotBlank()) {
                            Text(
                                media.subtitle,
                                style = MaterialTheme.typography.bodyMedium,
                                color = LocalContentColor.current.copy(alpha = 0.68f),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                    }
                    if (!outputDeviceName.isNullOrBlank()) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(accent.accentFaint)
                                .border(0.8.dp, accent.outline, CircleShape),
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(Icons.Rounded.Headphones, contentDescription = outputDeviceName, modifier = Modifier.size(19.dp), tint = accent.accentStrong)
                        }
                    }
                }

                Spacer(Modifier.height(8.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    MediaControlButton(contentDescription = "Previous", onClick = onPrevious, icon = Icons.Rounded.SkipPrevious)
                    MediaControlButton(
                        primary = true,
                        contentDescription = if (media.playing) "Pause" else "Play",
                        onClick = onPlayPause,
                        icon = if (media.playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                    )
                    MediaControlButton(contentDescription = "Next", onClick = onNext, icon = Icons.Rounded.SkipNext)
                }
            }
        }

        Spacer(Modifier.height(2.dp))
        if (duration > 0L) {
            val boundedPosition = localPosition.coerceIn(0f, duration.toFloat())
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Text(
                    formatMediaTime(boundedPosition.toLong()),
                    style = MaterialTheme.typography.labelSmall,
                    color = LocalContentColor.current.copy(alpha = 0.70f),
                    modifier = Modifier.widthIn(min = 36.dp),
                )
                Slider(
                    value = boundedPosition,
                    onValueChange = { value ->
                        if (media.seekable) {
                            scrubbing = true
                            localPosition = value
                        }
                    },
                    onValueChangeFinished = {
                        if (media.seekable) onSeek(localPosition.toLong())
                        scrubbing = false
                    },
                    valueRange = 0f..duration.toFloat().coerceAtLeast(1f),
                    enabled = media.seekable,
                    modifier = Modifier.weight(1f).height(30.dp),
                    colors = SliderDefaults.colors(
                        thumbColor = accent.accentStrong,
                        activeTrackColor = accent.accent,
                        inactiveTrackColor = LocalContentColor.current.copy(alpha = 0.18f),
                        disabledThumbColor = accent.accentStrong.copy(alpha = 0.70f),
                        disabledActiveTrackColor = accent.accent.copy(alpha = 0.70f),
                        disabledInactiveTrackColor = LocalContentColor.current.copy(alpha = 0.14f),
                    ),
                )
                Text(
                    formatMediaTime(duration),
                    style = MaterialTheme.typography.labelSmall,
                    color = LocalContentColor.current.copy(alpha = 0.70f),
                    modifier = Modifier.widthIn(min = 36.dp),
                )
            }
        } else {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    formatMediaTime(media.positionMs),
                    style = MaterialTheme.typography.labelSmall,
                    color = LocalContentColor.current.copy(alpha = 0.70f),
                )
                Spacer(Modifier.weight(1f))
                Text("LIVE", style = MaterialTheme.typography.labelSmall, color = accent.accentStrong, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

private object SmartStackMediaSessionMemory {
    private val promotedSessionByStack = mutableMapOf<String, String>()
    private val selectedKindByStack = mutableMapOf<String, NativeWidgetKind>()

    @Synchronized
    fun claimPromotion(stackKey: String, sessionId: String): Boolean {
        if (promotedSessionByStack[stackKey] == sessionId) return false
        promotedSessionByStack[stackKey] = sessionId
        return true
    }

    @Synchronized
    fun selectedKind(stackKey: String): NativeWidgetKind? = selectedKindByStack[stackKey]

    @Synchronized
    fun rememberSelection(stackKey: String, kind: NativeWidgetKind) {
        selectedKindByStack[stackKey] = kind
    }

    @Synchronized
    fun clear(stackKey: String) {
        promotedSessionByStack.remove(stackKey)
        selectedKindByStack.remove(stackKey)
    }
}

@Composable
fun SmartWidgetStack(
    battery: BatteryState,
    contextDecision: ContextDecision,
    modifier: Modifier = Modifier,
    definition: SmartStackDefinition? = null,
    connectedDeviceNames: Set<String> = emptySet(),
    nextEventInMinutes: Int? = null,
    nextEventTitle: String? = null,
    nextEventStartMillis: Long? = null,
    weather: WeatherState = WeatherState(),
    media: MediaPlaybackState = MediaPlaybackState(),
    connectivity: ConnectivityState = ConnectivityState(),
    initialPermanentIndex: Int = 0,
    onPermanentIndexChanged: (Int) -> Unit = {},
    autoAdvanceAllowed: Boolean = true,
    onOpenClock: () -> Unit = {},
    onOpenCalendar: () -> Unit = {},
    onOpenCalendarEvent: () -> Unit = {},
    onOpenWeather: () -> Unit = {},
    onOpenBattery: () -> Unit = {},
    onOpenMedia: () -> Unit = {},
    onMediaPlayPause: () -> Unit = {},
    onMediaPrevious: () -> Unit = {},
    onMediaNext: () -> Unit = {},
    onMediaSeek: (Long) -> Unit = {},
) {
    // BOAL's default Smart Stack has a fixed permanent roster. This is deliberately
    // independent from legacy persisted definitions so migration state cannot remove cards.
    val configured = definition?.items.orEmpty().map { it.widgetKind }
        .filterNot { it in setOf(NativeWidgetKind.MEDIA, NativeWidgetKind.CONTEXT, NativeWidgetKind.NEWS, NativeWidgetKind.CONNECTIVITY) }
    val permanent = remember(definition?.id, configured) {
        if (definition?.id == "default_home_stack" || definition == null) {
            listOf(
                NativeWidgetKind.CLOCK,
                NativeWidgetKind.CALENDAR,
                NativeWidgetKind.WEATHER,
                NativeWidgetKind.BATTERY,
                NativeWidgetKind.CONNECTIVITY,
            )
        } else {
            buildList {
                addAll(configured)
                listOf(
                    NativeWidgetKind.CLOCK,
                    NativeWidgetKind.CALENDAR,
                    NativeWidgetKind.WEATHER,
                    NativeWidgetKind.BATTERY,
                ).forEach { if (it !in this) add(it) }
                add(NativeWidgetKind.CONNECTIVITY)
            }.distinct()
        }
    }

    val memoryKey = "${definition?.id ?: "inline"}:${permanent.joinToString { it.name }}"
    var lastPermanentIndex by remember(memoryKey) {
        mutableIntStateOf(initialPermanentIndex.coerceIn(0, permanent.lastIndex.coerceAtLeast(0)))
    }

    val activeCards = remember(permanent, media.active) {
        if (media.active) permanent + NativeWidgetKind.MEDIA else permanent
    }

    val sessionRememberedKind = if (media.active) SmartStackMediaSessionMemory.selectedKind(memoryKey) else null
    val initialKind = sessionRememberedKind
        ?.takeIf { it in activeCards }
        ?: permanent.getOrElse(lastPermanentIndex) { NativeWidgetKind.CLOCK }
    var selectedKind by remember(memoryKey) { mutableStateOf(initialKind) }

    fun canonicalPageFor(kind: NativeWidgetKind): Int {
        val index = activeCards.indexOf(kind).takeIf { it >= 0 } ?: 0
        return index + 1 // page 0 is the duplicate of the last card
    }

    // Duplicate edge pages produce a genuine circular manual pager:
    // [last duplicate] [0] [1] ... [last] [first duplicate].
    val pagerState = rememberPagerState(
        initialPage = canonicalPageFor(initialKind),
        pageCount = { activeCards.size + 2 },
    )

    fun kindForPage(page: Int): NativeWidgetKind {
        val count = activeCards.size
        return when {
            count == 0 -> NativeWidgetKind.CLOCK
            page <= 0 -> activeCards.last()
            page >= count + 1 -> activeCards.first()
            else -> activeCards[page - 1]
        }
    }

    // Media may promote once when a genuinely new session appears. After that, the
    // user's selected card wins—even across Home/Brief recomposition for that session.
    LaunchedEffect(media.active, media.sessionId, memoryKey, activeCards) {
        if (media.active) {
            val sessionId = media.sessionId ?: media.packageName ?: "active-media"
            if (SmartStackMediaSessionMemory.claimPromotion(memoryKey, sessionId)) {
                selectedKind = NativeWidgetKind.MEDIA
                SmartStackMediaSessionMemory.rememberSelection(memoryKey, NativeWidgetKind.MEDIA)
                pagerState.animateScrollToPage(canonicalPageFor(NativeWidgetKind.MEDIA))
            } else {
                val desired = SmartStackMediaSessionMemory.selectedKind(memoryKey)
                    ?.takeIf { it in activeCards }
                    ?: selectedKind.takeIf { it in activeCards }
                    ?: permanent.getOrElse(lastPermanentIndex) { NativeWidgetKind.CLOCK }
                selectedKind = desired
                pagerState.scrollToPage(canonicalPageFor(desired))
            }
        } else {
            val fallback = selectedKind.takeIf { it in permanent }
                ?: permanent.getOrElse(lastPermanentIndex) { NativeWidgetKind.CLOCK }
            selectedKind = fallback
            pagerState.scrollToPage(canonicalPageFor(fallback))
            SmartStackMediaSessionMemory.clear(memoryKey)
        }
    }

    // Normalize the duplicate edge pages immediately after a swipe settles, then persist
    // the user's actual selection. There is intentionally no timer/automatic advance.
    LaunchedEffect(pagerState.settledPage, activeCards, memoryKey) {
        if (activeCards.isEmpty()) return@LaunchedEffect
        var page = pagerState.settledPage
        val count = activeCards.size
        if (page == 0) {
            pagerState.scrollToPage(count)
            page = count
        } else if (page == count + 1) {
            pagerState.scrollToPage(1)
            page = 1
        }

        val kind = kindForPage(page)
        selectedKind = kind
        if (media.active) SmartStackMediaSessionMemory.rememberSelection(memoryKey, kind)

        val permanentIndex = permanent.indexOf(kind)
        if (permanentIndex >= 0 && permanentIndex != lastPermanentIndex) {
            lastPermanentIndex = permanentIndex
            onPermanentIndexChanged(permanentIndex)
        }
    }

    HorizontalPager(
        state = pagerState,
        modifier = modifier,
        beyondViewportPageCount = 0,
        key = { page -> "${memoryKey}:${kindForPage(page).name}:$page" },
    ) { page ->
        when (kindForPage(page)) {
            NativeWidgetKind.CLOCK -> ClockWidget(modifier = Modifier.fillMaxSize(), onClick = onOpenClock)
            NativeWidgetKind.CALENDAR -> CalendarWidget(
                modifier = Modifier.fillMaxSize(),
                nextEventInMinutes = nextEventInMinutes,
                nextEventTitle = nextEventTitle,
                nextEventStartMillis = nextEventStartMillis,
                onOpenCalendar = onOpenCalendar,
                onOpenEvent = onOpenCalendarEvent,
            )
            NativeWidgetKind.WEATHER -> WeatherWidget(weather, modifier = Modifier.fillMaxSize(), onClick = onOpenWeather)
            NativeWidgetKind.BATTERY -> BatteryWidget(battery, modifier = Modifier.fillMaxSize(), connectedDeviceNames = connectedDeviceNames, onClick = onOpenBattery)
            NativeWidgetKind.CONNECTIVITY -> ConnectivityWidget(connectivity, modifier = Modifier.fillMaxSize())
            NativeWidgetKind.MEDIA -> MediaWidget(
                media = media,
                modifier = Modifier.fillMaxSize(),
                outputDeviceName = connectedDeviceNames.firstOrNull(),
                onOpen = onOpenMedia,
                onPlayPause = onMediaPlayPause,
                onPrevious = onMediaPrevious,
                onNext = onMediaNext,
                onSeek = onMediaSeek,
            )
            NativeWidgetKind.CONTEXT, NativeWidgetKind.NEWS -> ClockWidget(modifier = Modifier.fillMaxSize(), onClick = onOpenClock)
        }
    }
}
