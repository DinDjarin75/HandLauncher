package com.handlauncher.data

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.LauncherApps
import android.os.Process
import android.net.Uri
import android.provider.Settings
import com.handlauncher.domain.AppEntry

class LauncherRepository(private val context: Context) {
    private val launcherApps = context.getSystemService(LauncherApps::class.java)

    fun loadLaunchableApps(): List<AppEntry> {
        val profile = Process.myUserHandle()
        return launcherApps.getActivityList(null, profile)
            .asSequence()
            .filterNot { it.applicationInfo.packageName == context.packageName }
            .map { info ->
                val packageName = info.applicationInfo.packageName
                val label = info.label?.toString().orEmpty().ifBlank { packageName }
                val classification = AppCategorizer.classify(packageName, label, info.applicationInfo.category)
                AppEntry(
                    packageName = packageName,
                    activityName = info.componentName.className,
                    label = label,
                    categoryId = classification.categoryId,
                    tags = classification.tags,
                    isSystemApp = info.applicationInfo.flags and ApplicationInfo.FLAG_SYSTEM != 0,
                )
            }
            .distinctBy { it.stableId }
            .sortedBy { it.label.lowercase() }
            .toList()
    }

    fun launch(entry: AppEntry): Boolean = runCatching {
        val intent = Intent(Intent.ACTION_MAIN).apply {
            component = ComponentName(entry.packageName, entry.activityName)
            addCategory(Intent.CATEGORY_LAUNCHER)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        }
        context.startActivity(intent)
        true
    }.getOrDefault(false)

    fun openAppInfo(entry: AppEntry): Boolean = runCatching {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.parse("package:${entry.packageName}")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
        true
    }.getOrDefault(false)

    fun requestUninstall(entry: AppEntry): Boolean {
        if (entry.isSystemApp) return false
        return runCatching {
            val intent = Intent(Intent.ACTION_UNINSTALL_PACKAGE).apply {
                data = Uri.parse("package:${entry.packageName}")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            true
        }.getOrDefault(false)
    }
}
