package com.handlauncher.data

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

class WorkspaceRefreshWorker(
    appContext: Context,
    params: WorkerParameters,
) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        runCatching { WeatherRepository(applicationContext).refresh() }
        runCatching { WorkspaceSystemRepository(applicationContext).snapshot() }
        runCatching { EnergyGridRepository(applicationContext).refresh() }
        runCatching {
            val workspace = WorkspaceRepository(applicationContext)
            requestWidgetUpdate(workspace.showlyShowsWidgetId())
            requestWidgetUpdate(workspace.showlyMoviesWidgetId())
        }
        return Result.success()
    }

    private fun requestWidgetUpdate(appWidgetId: Int?) {
        if (appWidgetId == null) return
        val manager = AppWidgetManager.getInstance(applicationContext)
        val provider = manager.getAppWidgetInfo(appWidgetId)?.provider ?: return
        val intent = Intent(AppWidgetManager.ACTION_APPWIDGET_UPDATE).apply {
            component = ComponentName(provider.packageName, provider.className)
            putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, intArrayOf(appWidgetId))
        }
        applicationContext.sendBroadcast(intent)
    }

    companion object {
        private const val UNIQUE_WORK = "boal_workspace_modules_refresh_30m"

        fun schedule(context: Context) {
            val request = PeriodicWorkRequestBuilder<WorkspaceRefreshWorker>(30, TimeUnit.MINUTES).build()
            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                UNIQUE_WORK,
                ExistingPeriodicWorkPolicy.UPDATE,
                request,
            )
        }
    }
}
