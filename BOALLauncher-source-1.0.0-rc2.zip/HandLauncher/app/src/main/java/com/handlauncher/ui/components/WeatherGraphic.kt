package com.handlauncher.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.material3.LocalContentColor
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

private enum class WeatherVisualKind { CLEAR, PARTLY_CLOUDY, CLOUDY, RAIN, SNOW, THUNDER, FOG }

private fun visualKind(condition: String): WeatherVisualKind {
    val value = condition.lowercase()
    return when {
        "thunder" in value -> WeatherVisualKind.THUNDER
        "snow" in value -> WeatherVisualKind.SNOW
        "rain" in value || "shower" in value || "drizzle" in value -> WeatherVisualKind.RAIN
        "fog" in value || "mist" in value -> WeatherVisualKind.FOG
        "partly" in value -> WeatherVisualKind.PARTLY_CLOUDY
        "cloud" in value || "overcast" in value -> WeatherVisualKind.CLOUDY
        else -> WeatherVisualKind.CLEAR
    }
}

@Composable
fun WeatherGraphic(
    condition: String,
    modifier: Modifier = Modifier,
) {
    val foreground = LocalContentColor.current
    val kind = visualKind(condition)

    Canvas(modifier = modifier.semantics { contentDescription = condition }) {
        val width = size.width
        val height = size.height
        val unit = min(width, height)
        val stroke = unit * 0.055f

        fun drawSun(center: Offset, radius: Float, alpha: Float = 1f) {
            drawCircle(foreground.copy(alpha = alpha), radius, center)
            repeat(8) { index ->
                val angle = Math.toRadians((index * 45.0) - 90.0)
                val inner = radius * 1.45f
                val outer = radius * 2.05f
                drawLine(
                    color = foreground.copy(alpha = alpha * 0.9f),
                    start = Offset(center.x + cos(angle).toFloat() * inner, center.y + sin(angle).toFloat() * inner),
                    end = Offset(center.x + cos(angle).toFloat() * outer, center.y + sin(angle).toFloat() * outer),
                    strokeWidth = stroke * 0.72f,
                    cap = StrokeCap.Round,
                )
            }
        }

        fun drawCloud(top: Float = height * 0.37f, alpha: Float = 0.96f) {
            val cloudColor = foreground.copy(alpha = alpha)
            drawRoundRect(
                color = cloudColor,
                topLeft = Offset(width * 0.16f, top + height * 0.15f),
                size = Size(width * 0.68f, height * 0.24f),
                cornerRadius = CornerRadius(height * 0.12f),
            )
            drawCircle(cloudColor, unit * 0.16f, Offset(width * 0.39f, top + height * 0.13f))
            drawCircle(cloudColor, unit * 0.21f, Offset(width * 0.58f, top + height * 0.12f))
            drawCircle(cloudColor, unit * 0.13f, Offset(width * 0.73f, top + height * 0.18f))
        }

        when (kind) {
            WeatherVisualKind.CLEAR -> drawSun(Offset(width * 0.50f, height * 0.50f), unit * 0.15f)
            WeatherVisualKind.PARTLY_CLOUDY -> {
                drawSun(Offset(width * 0.35f, height * 0.34f), unit * 0.11f, 0.75f)
                drawCloud(top = height * 0.36f)
            }
            WeatherVisualKind.CLOUDY -> drawCloud(top = height * 0.30f)
            WeatherVisualKind.RAIN -> {
                drawCloud(top = height * 0.20f)
                listOf(0.30f, 0.50f, 0.70f).forEach { x ->
                    drawLine(
                        color = foreground.copy(alpha = 0.82f),
                        start = Offset(width * x, height * 0.68f),
                        end = Offset(width * (x - 0.05f), height * 0.88f),
                        strokeWidth = stroke,
                        cap = StrokeCap.Round,
                    )
                }
            }
            WeatherVisualKind.SNOW -> {
                drawCloud(top = height * 0.18f)
                listOf(0.30f, 0.50f, 0.70f).forEachIndexed { index, x ->
                    val center = Offset(width * x, height * (0.73f + (index % 2) * 0.08f))
                    val r = unit * 0.045f
                    drawLine(foreground.copy(alpha = 0.85f), Offset(center.x - r, center.y), Offset(center.x + r, center.y), stroke, StrokeCap.Round)
                    drawLine(foreground.copy(alpha = 0.85f), Offset(center.x, center.y - r), Offset(center.x, center.y + r), stroke, StrokeCap.Round)
                }
            }
            WeatherVisualKind.THUNDER -> {
                drawCloud(top = height * 0.18f)
                val path = Path().apply {
                    moveTo(width * 0.55f, height * 0.61f)
                    lineTo(width * 0.43f, height * 0.79f)
                    lineTo(width * 0.54f, height * 0.79f)
                    lineTo(width * 0.45f, height * 0.94f)
                    lineTo(width * 0.67f, height * 0.72f)
                    lineTo(width * 0.56f, height * 0.72f)
                    close()
                }
                drawPath(path, foreground.copy(alpha = 0.92f))
            }
            WeatherVisualKind.FOG -> {
                drawCloud(top = height * 0.12f, alpha = 0.78f)
                listOf(0.66f, 0.78f, 0.90f).forEachIndexed { index, y ->
                    drawLine(
                        color = foreground.copy(alpha = 0.72f - index * 0.08f),
                        start = Offset(width * (0.16f + index * 0.06f), height * y),
                        end = Offset(width * (0.84f - index * 0.04f), height * y),
                        strokeWidth = stroke * 0.8f,
                        cap = StrokeCap.Round,
                    )
                }
            }
        }
    }
}
