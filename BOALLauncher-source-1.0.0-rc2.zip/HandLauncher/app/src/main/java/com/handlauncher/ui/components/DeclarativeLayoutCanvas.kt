package com.handlauncher.ui.components

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.handlauncher.data.BatteryState
import com.handlauncher.data.MediaPlaybackState
import com.handlauncher.data.ConnectivityState
import com.handlauncher.data.WeatherState
import com.handlauncher.domain.*
import com.handlauncher.platform.AndroidWidgetHostController
import com.handlauncher.ui.theme.LocalHandVisualTokens
import kotlin.math.abs
import kotlin.math.roundToInt

@Composable
fun DeclarativeLayoutCanvas(
    layout: LauncherLayout,
    apps: List<AppEntry>,
    battery: BatteryState,
    weather: WeatherState,
    media: MediaPlaybackState,
    connectivity: ConnectivityState = ConnectivityState(),
    contextDecision: ContextDecision,
    connectedDeviceNames: Set<String>,
    nextEventInMinutes: Int?,
    nextEventTitle: String? = null,
    nextEventStartMillis: Long? = null,
    smartStacks: Map<String, SmartStackDefinition>,
    editMode: Boolean,
    loadStackPosition: (String) -> Int = { 0 },
    onStackPositionChanged: (String, Int) -> Unit = { _, _ -> },
    stackAutoAdvanceAllowed: Boolean = true,
    onGesture: (SmartObject, GestureSlot) -> Unit,
    onRectChange: (String, GridRect, Boolean) -> Unit,
    onRemoveObject: (SmartObject) -> Unit,
    onEditObject: (SmartObject) -> Unit,
    onOpenClock: () -> Unit = {},
    onOpenCalendar: () -> Unit = {},
    onOpenCalendarEvent: () -> Unit = {},
    onOpenWeather: () -> Unit = {},
    onOpenBattery: () -> Unit = {},
    onOpenMedia: () -> Unit = {},
    onMediaPlayPause: () -> Unit = {},
    onMediaPrevious: () -> Unit = {},
    onMediaNext: () -> Unit = {},
    onMediaSeek: (Long) -> Unit = {},
    onBackgroundSwipeDown: (() -> Unit)? = null,
    onBackgroundSwipeLeftDown: (() -> Unit)? = null,
    onBackgroundSwipeRightDown: (() -> Unit)? = null,
    onBackgroundSwipeUp: (() -> Unit)? = null,
    widgetHostController: AndroidWidgetHostController? = null,
    modifier: Modifier = Modifier,
) {
    val page = layout.pages.firstOrNull()
    if (page == null) {
        Box(modifier, contentAlignment = Alignment.Center) { Text("Empty layout", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        return
    }

    var canvasSize by remember { mutableStateOf(IntSize.Zero) }
    var backgroundGestureActive by remember { mutableStateOf(false) }
    var backgroundDrag by remember { mutableFloatStateOf(0f) }
    val density = LocalDensity.current
    val backgroundGestureThreshold = with(density) { 96.dp.toPx() }
    val maxGestureTravel = with(density) { 24.dp.toPx() }
    val backgroundTranslation by animateFloatAsState(
        targetValue = if (backgroundGestureActive) (backgroundDrag * 0.14f).coerceIn(-maxGestureTravel, maxGestureTravel) else 0f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "canvasGestureTranslation",
    )
    Box(
        modifier = modifier
            .graphicsLayer { translationY = backgroundTranslation }
            .onSizeChanged { canvasSize = it }
            .then(
                if (!editMode && (onBackgroundSwipeDown != null || onBackgroundSwipeLeftDown != null || onBackgroundSwipeRightDown != null || onBackgroundSwipeUp != null)) {
                    Modifier.pointerInput(page.objects, canvasSize) {
                        awaitEachGesture {
                            val down = awaitFirstDown(requireUnconsumed = false)
                            val width = canvasSize.width.coerceAtLeast(1).toFloat()
                            val height = canvasSize.height.coerceAtLeast(1).toFloat()
                            val x = down.position.x / width
                            val y = down.position.y / height
                            val emptyBackground = page.objects.none { obj ->
                                x >= obj.rect.x && x <= obj.rect.x + obj.rect.width &&
                                    y >= obj.rect.y && y <= obj.rect.y + obj.rect.height
                            }
                            val downZone = when {
                                x < 0.30f -> 0
                                x > 0.70f -> 2
                                else -> 1
                            }
                            val systemGestureThreshold = with(density) { 56.dp.toPx() }
                            var totalY = 0f
                            var decisionMade = false
                            var claimedByLauncher = false
                            var systemActionFired = false
                            backgroundGestureActive = false
                            backgroundDrag = 0f

                            while (true) {
                                val event = awaitPointerEvent()
                                val change = event.changes.firstOrNull { it.id == down.id } ?: break
                                if (!change.pressed) break

                                totalY += change.positionChange().y
                                if (!decisionMade && abs(totalY) > viewConfiguration.touchSlop) {
                                    claimedByLauncher = emptyBackground
                                    backgroundGestureActive = claimedByLauncher
                                    decisionMade = true
                                }
                                if (claimedByLauncher) {
                                    backgroundDrag = totalY
                                    change.consume()
                                    if (!systemActionFired && totalY > systemGestureThreshold && downZone != 1) {
                                        systemActionFired = true
                                        if (downZone == 0) onBackgroundSwipeLeftDown?.invoke()
                                        else onBackgroundSwipeRightDown?.invoke()
                                    }
                                }
                            }

                            if (claimedByLauncher && !systemActionFired && abs(totalY) > backgroundGestureThreshold) {
                                if (totalY > 0f) onBackgroundSwipeDown?.invoke() else onBackgroundSwipeUp?.invoke()
                            }
                            backgroundGestureActive = false
                            backgroundDrag = 0f
                        }
                    }
                } else Modifier
            )
            .then(
                if (editMode) Modifier.border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.35f), RoundedCornerShape(22.dp))
                else Modifier
            )
    ) {
        if (editMode && !layout.finePositioning) GridGuide(layout.columns, layout.rows, Modifier.fillMaxSize())

        page.objects.forEach { obj ->
            val widthPx = canvasSize.width.coerceAtLeast(1)
            val heightPx = canvasSize.height.coerceAtLeast(1)
            val objectModifier = Modifier
                .offset {
                    IntOffset((widthPx * obj.rect.x).roundToInt(), (heightPx * obj.rect.y).roundToInt())
                }
                .width(with(density) { (widthPx * obj.rect.width).toDp() })
                .height(with(density) { (heightPx * obj.rect.height).toDp() })

            EditableObjectFrame(
                obj = obj,
                editMode = editMode,
                childConsumesGestures = obj.type == SmartObjectType.ANDROID_WIDGET,
                canvasSize = canvasSize,
                onGesture = onGesture,
                onRectChange = onRectChange,
                onRemove = { onRemoveObject(obj) },
                onEdit = { onEditObject(obj) },
                modifier = objectModifier,
            ) {
                when (obj.type) {
                    SmartObjectType.NATIVE_WIDGET -> {
                        val variant = obj.payload["variant"] ?: "standard"
                        when (runCatching { NativeWidgetKind.valueOf(obj.payload["widgetKind"].orEmpty()) }.getOrNull()) {
                            NativeWidgetKind.CLOCK -> ClockWidget(
                                Modifier.fillMaxSize(),
                                variant = variant,
                                showSeconds = obj.payload["showSeconds"] == "true",
                                showDate = obj.payload["showDate"] != "false",
                                onClick = onOpenClock,
                            )
                            NativeWidgetKind.CALENDAR -> CalendarWidget(
                                modifier = Modifier.fillMaxSize(),
                                variant = variant,
                                nextEventInMinutes = nextEventInMinutes,
                                nextEventTitle = nextEventTitle,
                                nextEventStartMillis = nextEventStartMillis,
                                onOpenCalendar = onOpenCalendar,
                                onOpenEvent = onOpenCalendarEvent,
                            )
                            NativeWidgetKind.WEATHER -> WeatherWidget(weather, Modifier.fillMaxSize(), variant, onOpenWeather)
                            NativeWidgetKind.BATTERY -> BatteryWidget(
                                battery,
                                Modifier.fillMaxSize(),
                                variant,
                                connectedDeviceNames,
                                obj.payload["showDevices"] != "false",
                                onOpenBattery,
                            )
                            NativeWidgetKind.CONNECTIVITY -> ConnectivityWidget(connectivity, Modifier.fillMaxSize())
                            NativeWidgetKind.MEDIA -> MediaWidget(
                                media = media,
                                modifier = Modifier.fillMaxSize(),
                                outputDeviceName = connectedDeviceNames.firstOrNull(),
                                onOpen = onOpenMedia,
                                onPlayPause = onMediaPlayPause,
                                onPrevious = onMediaPrevious,
                                onNext = onMediaNext,
                                onSeek = onMediaSeek,
                            )
                            NativeWidgetKind.CONTEXT -> {
                                val inlineStackId = "inline_${obj.id}"
                                SmartWidgetStack(
                                    battery = battery,
                                    contextDecision = contextDecision,
                                    modifier = Modifier.fillMaxSize(),
                                    connectedDeviceNames = connectedDeviceNames,
                                    nextEventInMinutes = nextEventInMinutes,
                                    nextEventTitle = nextEventTitle,
                                    nextEventStartMillis = nextEventStartMillis,
                                    weather = weather,
                                    media = media,
                                    connectivity = connectivity,
                                    initialPermanentIndex = loadStackPosition(inlineStackId),
                                    onPermanentIndexChanged = { onStackPositionChanged(inlineStackId, it) },
                                    autoAdvanceAllowed = stackAutoAdvanceAllowed,
                                    onOpenClock = onOpenClock,
                                    onOpenCalendar = onOpenCalendar,
                                    onOpenCalendarEvent = onOpenCalendarEvent,
                                    onOpenWeather = onOpenWeather,
                                    onOpenBattery = onOpenBattery,
                                    onOpenMedia = onOpenMedia,
                                    onMediaPlayPause = onMediaPlayPause,
                                    onMediaPrevious = onMediaPrevious,
                                    onMediaNext = onMediaNext,
                                    onMediaSeek = onMediaSeek,
                                )
                            }
                            else -> ClockWidget(Modifier.fillMaxSize(), variant, onClick = onOpenClock)
                        }
                    }

                    SmartObjectType.SMART_STACK -> {
                        val stackId = obj.payload["stackId"] ?: "stack_${obj.id}"
                        SmartWidgetStack(
                            battery = battery,
                            contextDecision = contextDecision,
                            modifier = Modifier.fillMaxSize(),
                            definition = smartStacks[stackId],
                            connectedDeviceNames = connectedDeviceNames,
                            nextEventInMinutes = nextEventInMinutes,
                            nextEventTitle = nextEventTitle,
                            nextEventStartMillis = nextEventStartMillis,
                            weather = weather,
                            media = media,
                            connectivity = connectivity,
                            initialPermanentIndex = loadStackPosition(stackId),
                            onPermanentIndexChanged = { onStackPositionChanged(stackId, it) },
                            autoAdvanceAllowed = stackAutoAdvanceAllowed,
                            onOpenClock = onOpenClock,
                            onOpenCalendar = onOpenCalendar,
                            onOpenCalendarEvent = onOpenCalendarEvent,
                            onOpenWeather = onOpenWeather,
                            onOpenBattery = onOpenBattery,
                            onOpenMedia = onOpenMedia,
                            onMediaPlayPause = onMediaPlayPause,
                            onMediaPrevious = onMediaPrevious,
                            onMediaNext = onMediaNext,
                            onMediaSeek = onMediaSeek,
                        )
                    }

                    SmartObjectType.APP -> {
                        val app = apps.firstOrNull { it.stableId == obj.payload["appStableId"] }
                        if (app != null) AppIcon(
                            app = app,
                            displayLabel = obj.title,
                            onClick = {},
                            onLongClick = null,
                            interactionEnabled = false,
                            modifier = Modifier.fillMaxSize(),
                        )
                    }

                    SmartObjectType.ANDROID_WIDGET -> {
                        val id = obj.payload["appWidgetId"]?.toIntOrNull()
                        if (id != null && widgetHostController != null) {
                            AndroidHostedWidget(id, widgetHostController, Modifier.fillMaxSize())
                        } else ObjectPlaceholder(obj.title, Icons.Rounded.Widgets)
                    }

                    SmartObjectType.FOLDER -> ObjectPlaceholder(obj.title, Icons.Rounded.Folder)
                    SmartObjectType.COMMAND -> ObjectPlaceholder(obj.title, Icons.Rounded.Bolt)
                    SmartObjectType.SHORTCUT -> ObjectPlaceholder(obj.title, Icons.Rounded.TouchApp)
                }
            }
        }
    }
}

@Composable
private fun ObjectPlaceholder(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    val visuals = LocalHandVisualTokens.current
    Column(
        Modifier.fillMaxSize().background(
            MaterialTheme.colorScheme.surface.copy(alpha = visuals.surfaceAlpha),
            RoundedCornerShape(visuals.cornerRadiusDp.dp),
        ).padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Icon(icon, null)
        Text(title, style = MaterialTheme.typography.labelMedium, maxLines = 2)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun EditableObjectFrame(
    obj: SmartObject,
    editMode: Boolean,
    childConsumesGestures: Boolean,
    canvasSize: IntSize,
    onGesture: (SmartObject, GestureSlot) -> Unit,
    onRectChange: (String, GridRect, Boolean) -> Unit,
    onRemove: () -> Unit,
    onEdit: () -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit,
) {
    val latestRect by rememberUpdatedState(obj.rect)
    var verticalGesture by remember { mutableFloatStateOf(0f) }

    Box(
        modifier = modifier.then(
            if (editMode) {
                Modifier
                    .border(1.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(18.dp))
                    .pointerInput(obj.id, canvasSize) {
                        detectDragGestures(
                            onDrag = { change, amount ->
                                change.consume()
                                if (canvasSize.width > 0 && canvasSize.height > 0) {
                                    val rect = latestRect
                                    onRectChange(obj.id, rect.copy(x = rect.x + amount.x / canvasSize.width, y = rect.y + amount.y / canvasSize.height), false)
                                }
                            },
                            onDragEnd = { onRectChange(obj.id, latestRect, true) },
                        )
                    }
            } else if (!childConsumesGestures) {
                Modifier
                    .combinedClickable(
                        onClick = { onGesture(obj, GestureSlot.TAP) },
                        onLongClick = { onGesture(obj, GestureSlot.LONG_PRESS) },
                    )
                    .pointerInput(obj.id) {
                        detectVerticalDragGestures(
                            onVerticalDrag = { _, amount -> verticalGesture += amount },
                            onDragEnd = {
                                if (abs(verticalGesture) > 42f) onGesture(obj, if (verticalGesture < 0) GestureSlot.SWIPE_UP else GestureSlot.SWIPE_DOWN)
                                verticalGesture = 0f
                            },
                        )
                    }
            } else Modifier
        )
    ) {
        content()
        if (editMode) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .size(34.dp)
                    .background(MaterialTheme.colorScheme.secondaryContainer, RoundedCornerShape(12.dp))
                    .combinedClickable(onClick = onEdit, onLongClick = null),
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Rounded.Edit, contentDescription = "Edit object") }

            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .size(34.dp)
                    .background(MaterialTheme.colorScheme.errorContainer, RoundedCornerShape(12.dp))
                    .combinedClickable(onClick = onRemove, onLongClick = null),
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Rounded.Close, contentDescription = "Remove") }

            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .size(34.dp)
                    .background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(12.dp))
                    .pointerInput(obj.id, canvasSize) {
                        detectDragGestures(
                            onDrag = { change, amount ->
                                change.consume()
                                if (canvasSize.width > 0 && canvasSize.height > 0) {
                                    val rect = latestRect
                                    onRectChange(obj.id, rect.copy(width = rect.width + amount.x / canvasSize.width, height = rect.height + amount.y / canvasSize.height), false)
                                }
                            },
                            onDragEnd = { onRectChange(obj.id, latestRect, true) },
                        )
                    },
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Rounded.DragHandle, contentDescription = "Resize") }
        }
    }
}

@Composable
private fun GridGuide(columns: Int, rows: Int, modifier: Modifier = Modifier) {
    BoxWithConstraints(modifier) {
        for (column in 1 until columns) {
            Box(Modifier.offset(x = maxWidth * (column.toFloat() / columns)).width(1.dp).fillMaxHeight().background(MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.18f)))
        }
        for (row in 1 until rows) {
            Box(Modifier.offset(y = maxHeight * (row.toFloat() / rows)).height(1.dp).fillMaxWidth().background(MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.18f)))
        }
        Text("$columns × $rows grid", modifier = Modifier.align(Alignment.BottomStart).padding(8.dp), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
