package com.handlauncher.data

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.util.concurrent.ConcurrentHashMap

data class IconPackInfo(
    val packageName: String,
    val label: String,
)

class IconPackRepository(private val context: Context) {
    private val prefs = context.getSharedPreferences("icon_pack_preferences", Context.MODE_PRIVATE)

    fun selectedPackage(): String? = prefs.getString(KEY_SELECTED, null)

    fun saveSelectedPackage(packageName: String?) {
        prefs.edit().apply {
            if (packageName.isNullOrBlank()) remove(KEY_SELECTED) else putString(KEY_SELECTED, packageName)
        }.apply()
        IconPackResolver.clearCache()
    }

    fun discover(): List<IconPackInfo> {
        val pm = context.packageManager
        val packages = linkedSetOf<String>()
        THEME_ACTIONS.forEach { action ->
            runCatching {
                pm.queryIntentActivities(Intent(action), PackageManager.MATCH_ALL)
                    .mapTo(packages) { it.activityInfo.packageName }
            }
        }
        runCatching {
            pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), PackageManager.MATCH_ALL)
                .mapTo(packages) { it.activityInfo.packageName }
        }
        return packages.mapNotNull { packageName ->
            if (!IconPackResolver.hasMappings(context, packageName)) return@mapNotNull null
            val label = runCatching {
                val info = pm.getApplicationInfo(packageName, 0)
                pm.getApplicationLabel(info).toString()
            }.getOrDefault(packageName)
            IconPackInfo(packageName, label)
        }.distinctBy { it.packageName }.sortedBy { it.label.lowercase() }
    }

    private companion object {
        const val KEY_SELECTED = "selected_icon_pack"
        val THEME_ACTIONS = listOf(
            "org.adw.launcher.THEMES",
            "com.novalauncher.THEME",
            "com.teslacoilsw.launcher.THEME",
            "com.anddoes.launcher.THEME",
        )
    }
}

object IconPackResolver {
    private data class Mapping(
        val byComponent: Map<String, String>,
        val byPackage: Map<String, String>,
    )

    private val cache = ConcurrentHashMap<String, Mapping>()

    fun clearCache() = cache.clear()

    fun hasMappings(context: Context, iconPackPackage: String): Boolean =
        loadMapping(context, iconPackPackage).byComponent.isNotEmpty()

    fun resolveDrawable(
        context: Context,
        iconPackPackage: String?,
        packageName: String,
        activityName: String? = null,
    ): Drawable? {
        if (iconPackPackage.isNullOrBlank()) return null
        val mapping = loadMapping(context, iconPackPackage)
        val normalizedActivity = activityName?.let { if (it.startsWith('.')) packageName + it else it }
        val componentKey = normalizedActivity?.let { "$packageName/$it" }
        val drawableName = componentKey?.let(mapping.byComponent::get)
            ?: mapping.byPackage[packageName]
            ?: return null
        return runCatching {
            val resources = context.packageManager.getResourcesForApplication(iconPackPackage)
            val id = resources.getIdentifier(drawableName, "drawable", iconPackPackage)
                .takeIf { it != 0 }
                ?: resources.getIdentifier(drawableName, "mipmap", iconPackPackage).takeIf { it != 0 }
                ?: return@runCatching null
            resources.getDrawable(id, null)
        }.getOrNull()
    }

    private fun loadMapping(context: Context, packageName: String): Mapping =
        cache.getOrPut(packageName) { parseMapping(context, packageName) }

    private fun parseMapping(context: Context, packageName: String): Mapping {
        val byComponent = linkedMapOf<String, String>()
        val byPackage = linkedMapOf<String, String>()
        val parser = openParser(context, packageName) ?: return Mapping(emptyMap(), emptyMap())
        runCatching {
            var event = parser.eventType
            while (event != XmlPullParser.END_DOCUMENT) {
                if (event == XmlPullParser.START_TAG && parser.name.equals("item", ignoreCase = true)) {
                    val componentRaw = parser.getAttributeValue(null, "component").orEmpty()
                    val drawable = parser.getAttributeValue(null, "drawable").orEmpty()
                    val component = normalizeComponent(componentRaw)
                    if (component != null && drawable.isNotBlank()) {
                        byComponent[component] = drawable
                        byPackage.putIfAbsent(component.substringBefore('/'), drawable)
                    }
                }
                event = parser.next()
            }
        }
        return Mapping(byComponent, byPackage)
    }

    private fun openParser(context: Context, packageName: String): XmlPullParser? {
        return runCatching {
            val resources = context.packageManager.getResourcesForApplication(packageName)
            val xmlId = resources.getIdentifier("appfilter", "xml", packageName)
            if (xmlId != 0) return@runCatching resources.getXml(xmlId)
            val packContext = context.createPackageContext(packageName, Context.CONTEXT_IGNORE_SECURITY)
            val input = packContext.assets.open("appfilter.xml")
            Xml.newPullParser().also {
                it.setInput(input, "utf-8")
            }
        }.getOrNull()
    }

    private fun normalizeComponent(raw: String): String? {
        val inner = when {
            raw.startsWith("ComponentInfo{") -> raw.removePrefix("ComponentInfo{").removeSuffix("}")
            else -> raw
        }.trim()
        val slash = inner.indexOf('/')
        if (slash <= 0 || slash >= inner.lastIndex) return null
        val pkg = inner.substring(0, slash)
        var activity = inner.substring(slash + 1)
        if (activity.startsWith('.')) activity = pkg + activity
        return "$pkg/$activity"
    }
}
