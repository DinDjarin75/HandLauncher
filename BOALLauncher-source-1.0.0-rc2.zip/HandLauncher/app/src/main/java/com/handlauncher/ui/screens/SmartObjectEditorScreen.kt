package com.handlauncher.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Gesture
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.handlauncher.domain.*

@Composable
fun SmartObjectEditorScreen(
    app: AppEntry,
    smartObject: SmartObject,
    onTitleChange: (String) -> Unit,
    onActionChange: (GestureSlot, SmartAction) -> Unit,
    onSave: () -> Unit,
    onDismiss: () -> Unit,
) {
    BackHandler(onBack = onDismiss)
    Surface(Modifier.fillMaxSize()) {
        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Gesture, null)
                Spacer(Modifier.width(10.dp))
                Text("Smart Object", style = MaterialTheme.typography.headlineMedium, modifier = Modifier.weight(1f))
                IconButton(onClick = onDismiss) { Icon(Icons.Rounded.Close, "Close") }
            }

            Text(app.label, style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(
                value = smartObject.title,
                onValueChange = onTitleChange,
                label = { Text("Home label") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )

            Text("Gestures", style = MaterialTheme.typography.titleLarge)
            GestureActionRow(
                label = "Tap",
                selected = smartObject.actions.tap,
                options = listOf(
                    "Open app" to SmartAction.LaunchApp(app.packageName, app.activityName),
                    "Search" to SmartAction.ShowSurface("search"),
                    "App Library" to SmartAction.ShowSurface("app_library"),
                ),
                onSelect = { onActionChange(GestureSlot.TAP, it) },
            )
            GestureActionRow(
                label = "Swipe up",
                selected = smartObject.actions.swipeUp,
                options = secondaryOptions(app),
                onSelect = { onActionChange(GestureSlot.SWIPE_UP, it) },
            )
            GestureActionRow(
                label = "Swipe down",
                selected = smartObject.actions.swipeDown,
                options = secondaryOptions(app),
                onSelect = { onActionChange(GestureSlot.SWIPE_DOWN, it) },
            )
            GestureActionRow(
                label = "Long press",
                selected = smartObject.actions.longPress,
                options = listOf(
                    "Edit Smart Object" to SmartAction.ShowSurface("smart_object_editor"),
                    "Search" to SmartAction.ShowSurface("search"),
                    "App Library" to SmartAction.ShowSurface("app_library"),
                    "AI Design" to SmartAction.ShowSurface("ai_design"),
                    "None" to SmartAction.None,
                ),
                onSelect = { onActionChange(GestureSlot.LONG_PRESS, it) },
            )

            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Smart Object foundation", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "These actions are persisted independently from the icon layout. Future pop-ups, shutters, folders and commands reuse the same object model.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            Spacer(Modifier.weight(1f))
            Button(onClick = onSave, modifier = Modifier.fillMaxWidth()) { Text("Save Smart Object") }
        }
    }
}

private fun secondaryOptions(app: AppEntry): List<Pair<String, SmartAction>> = listOf(
    "None" to SmartAction.None,
    "Search" to SmartAction.ShowSurface("search"),
    "App Library" to SmartAction.ShowSurface("app_library"),
    "Open ${app.categoryId}" to SmartAction.OpenCollection(app.categoryId),
)

@Composable
private fun GestureActionRow(
    label: String,
    selected: SmartAction,
    options: List<Pair<String, SmartAction>>,
    onSelect: (SmartAction) -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(label, style = MaterialTheme.typography.labelLarge)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            options.forEach { (name, action) ->
                FilterChip(
                    selected = selected == action,
                    onClick = { onSelect(action) },
                    label = { Text(name) },
                )
            }
        }
    }
}
