package com.handlauncher.data

import android.app.NotificationManager
import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.SystemClock
import com.handlauncher.platform.LauncherNotificationListener

/** Current external media session used by the contextual Smart Stack player. */
data class MediaPlaybackState(
    val active: Boolean = false,
    val playing: Boolean = false,
    val title: String = "",
    val subtitle: String = "",
    val packageName: String? = null,
    val sessionId: String? = null,
    val artwork: Bitmap? = null,
    val durationMs: Long = 0L,
    val positionMs: Long = 0L,
    val seekable: Boolean = false,
    val needsAccess: Boolean = false,
)

class MediaSessionRepository(private val context: Context) {
    private val sessionManager = context.getSystemService(MediaSessionManager::class.java)
    private val audioManager = context.getSystemService(AudioManager::class.java)
    private val listener = ComponentName(context, LauncherNotificationListener::class.java)
    @Volatile private var currentController: MediaController? = null

    fun hasAccess(): Boolean {
        val manager = context.getSystemService(NotificationManager::class.java)
        return manager.isNotificationListenerAccessGranted(listener)
    }

    fun snapshot(): MediaPlaybackState {
        if (!hasAccess()) {
            return if (audioManager.isMusicActive) MediaPlaybackState(
                active = true,
                playing = true,
                title = "Media playing",
                subtitle = "Tap to enable controls",
                sessionId = "permissionless-media",
                needsAccess = true,
            ) else MediaPlaybackState()
        }
        val controllers = runCatching { sessionManager.getActiveSessions(listener) }.getOrDefault(emptyList())
        val preferred = controllers.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: controllers.firstOrNull { controller ->
                controller.playbackState?.state in setOf(
                    PlaybackState.STATE_PAUSED,
                    PlaybackState.STATE_BUFFERING,
                    PlaybackState.STATE_CONNECTING,
                )
            }
        currentController = preferred
        if (preferred == null) {
            return MediaPlaybackState(active = false, playing = audioManager.isMusicActive)
        }
        val metadata = preferred.metadata
        val state = preferred.playbackState
        val title = metadata?.getText(MediaMetadata.METADATA_KEY_TITLE)?.toString().orEmpty()
            .ifBlank { metadata?.getText(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)?.toString().orEmpty() }
        val artist = metadata?.getText(MediaMetadata.METADATA_KEY_ARTIST)?.toString().orEmpty()
        val albumArtist = metadata?.getText(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)?.toString().orEmpty()
        val album = metadata?.getText(MediaMetadata.METADATA_KEY_ALBUM)?.toString().orEmpty()
        val subtitle = listOf(artist.ifBlank { albumArtist }, album).filter(String::isNotBlank).distinct().joinToString(" · ")
        val artwork = metadata?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: metadata?.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: metadata?.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)

        val duration = metadata?.getLong(MediaMetadata.METADATA_KEY_DURATION)?.coerceAtLeast(0L) ?: 0L
        val rawPosition = state?.position?.takeIf { it >= 0L } ?: 0L
        val estimatedPosition = if (
            state?.state == PlaybackState.STATE_PLAYING &&
            state.lastPositionUpdateTime > 0L &&
            rawPosition >= 0L
        ) {
            val elapsed = (SystemClock.elapsedRealtime() - state.lastPositionUpdateTime).coerceAtLeast(0L)
            rawPosition + (elapsed * state.playbackSpeed).toLong()
        } else rawPosition
        val position = if (duration > 0L) estimatedPosition.coerceIn(0L, duration) else estimatedPosition.coerceAtLeast(0L)
        val canSeek = duration > 0L && ((state?.actions ?: 0L) and PlaybackState.ACTION_SEEK_TO != 0L)

        return MediaPlaybackState(
            active = state?.state in setOf(
                PlaybackState.STATE_PLAYING,
                PlaybackState.STATE_PAUSED,
                PlaybackState.STATE_BUFFERING,
                PlaybackState.STATE_CONNECTING,
            ),
            playing = state?.state == PlaybackState.STATE_PLAYING,
            title = title.ifBlank { "Now playing" },
            subtitle = subtitle,
            packageName = preferred.packageName,
            sessionId = "${preferred.packageName}:${preferred.sessionToken.hashCode()}",
            artwork = artwork,
            durationMs = duration,
            positionMs = position,
            seekable = canSeek,
        )
    }

    fun playPause() {
        val controller = currentController ?: return
        if (controller.playbackState?.state == PlaybackState.STATE_PLAYING) controller.transportControls.pause()
        else controller.transportControls.play()
    }

    fun seekTo(positionMs: Long) {
        val controller = currentController ?: return
        val duration = controller.metadata?.getLong(MediaMetadata.METADATA_KEY_DURATION)?.coerceAtLeast(0L) ?: 0L
        val target = if (duration > 0L) positionMs.coerceIn(0L, duration) else positionMs.coerceAtLeast(0L)
        controller.transportControls.seekTo(target)
    }

    fun next() { currentController?.transportControls?.skipToNext() }
    fun previous() { currentController?.transportControls?.skipToPrevious() }
}
