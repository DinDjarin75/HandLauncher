@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.handlauncher.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.handlauncher.domain.AppCategory
import com.handlauncher.domain.AppEntry
import com.handlauncher.ui.components.HandGlassSurface
import com.handlauncher.ui.components.ThemedPackageIcon
import com.handlauncher.ui.theme.LocalHandAccentPalette

@Composable
fun CategoryEditorScreen(
    apps: List<AppEntry>,
    categories: List<AppCategory>,
    selectedCategoryId: String,
    onSelectCategory: (String) -> Unit,
    onRenameCategory: (String, String) -> Unit,
    onCreateCategory: (String) -> Unit,
    onAssignApp: (AppEntry, String) -> Unit,
    onMoveCategory: (String, Int) -> Unit,
    onTransparencyChange: (String, Int) -> Unit,
    onDismiss: () -> Unit,
) {
    BackHandler(onBack = onDismiss)
    val selected = categories.firstOrNull { it.id == selectedCategoryId } ?: categories.firstOrNull()
    var rename by remember(selected?.id, selected?.name) { mutableStateOf(selected?.name.orEmpty()) }
    var showNewCategory by remember { mutableStateOf(false) }
    var newCategoryName by remember { mutableStateOf("") }
    val accent = LocalHandAccentPalette.current

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background.copy(alpha = .18f), contentColor = Color.White) {
        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 16.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onDismiss) { Icon(Icons.Rounded.ArrowBack, "Back") }
                Text("Edit categories", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                FilledTonalIconButton(onClick = { showNewCategory = true }, colors = IconButtonDefaults.filledTonalIconButtonColors(containerColor = accent.accentFaint)) {
                    Icon(Icons.Rounded.Add, "New category", tint = accent.accentStrong)
                }
            }

            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                categories.forEach { category ->
                    Surface(
                        onClick = { onSelectCategory(category.id) },
                        shape = RoundedCornerShape(18.dp),
                        color = if (category.id == selectedCategoryId) accent.accentSoft else MaterialTheme.colorScheme.surface.copy(alpha = .34f),
                        border = androidx.compose.foundation.BorderStroke(.8.dp, if (category.id == selectedCategoryId) accent.accent else Color.White.copy(alpha = .20f)),
                    ) {
                        Text(category.name, modifier = Modifier.padding(horizontal = 14.dp, vertical = 9.dp), maxLines = 1)
                    }
                }
            }

            if (selected != null) {
                HandGlassSurface(Modifier.fillMaxWidth(), cornerRadiusDp = 24, contentPadding = PaddingValues(16.dp)) {
                    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(selected.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                                Text("${apps.count { it.categoryId == selected.id }} apps · ${if (selected.userCreated) "Custom" else "Auto-sorted"}", style = MaterialTheme.typography.bodySmall, color = Color.White.copy(alpha = .58f))
                            }
                            IconButton(onClick = { onMoveCategory(selected.id, -1) }, enabled = categories.indexOf(selected) > 0) { Icon(Icons.Rounded.KeyboardArrowUp, "Move up") }
                            IconButton(onClick = { onMoveCategory(selected.id, 1) }, enabled = categories.indexOf(selected) < categories.lastIndex) { Icon(Icons.Rounded.KeyboardArrowDown, "Move down") }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedTextField(
                                value = rename,
                                onValueChange = { rename = it },
                                label = { Text("Category name") },
                                singleLine = true,
                                shape = RoundedCornerShape(18.dp),
                                modifier = Modifier.weight(1f),
                            )
                            FilledTonalIconButton(
                                onClick = { onRenameCategory(selected.id, rename) },
                                enabled = rename.isNotBlank() && rename.trim() != selected.name,
                                colors = IconButtonDefaults.filledTonalIconButtonColors(containerColor = accent.accentSoft),
                            ) { Icon(Icons.Rounded.Check, "Save", tint = accent.onAccent) }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Glass transparency", style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                            Text("${selected.backgroundTransparencyPercent}%", style = MaterialTheme.typography.labelLarge, color = accent.accentStrong)
                        }
                        Slider(
                            value = selected.backgroundTransparencyPercent.toFloat(),
                            onValueChange = { onTransparencyChange(selected.id, it.toInt()) },
                            valueRange = 0f..90f,
                            steps = 17,
                        )
                    }
                }

                Text("Apps", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(horizontal = 4.dp))
                LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(6.dp), contentPadding = PaddingValues(bottom = 18.dp)) {
                    items(apps, key = { it.stableId }) { app ->
                        val assigned = app.categoryId == selected.id
                        Row(
                            Modifier.fillMaxWidth()
                                .background(MaterialTheme.colorScheme.surface.copy(alpha = if (assigned) .48f else .30f), RoundedCornerShape(18.dp))
                                .combinedClickable(onClick = { onAssignApp(app, selected.id) })
                                .padding(horizontal = 12.dp, vertical = 9.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            ThemedPackageIcon(app.packageName, app.activityName, app.label, Modifier.size(42.dp), 96)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(app.label, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                if (app.tags.isNotEmpty()) Text(app.tags.take(3).joinToString(" · "), style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = .48f), maxLines = 1)
                            }
                            if (assigned) {
                                Icon(Icons.Rounded.CheckCircle, "Assigned", tint = accent.accentStrong)
                            } else {
                                Icon(Icons.Rounded.RadioButtonUnchecked, "Assign", tint = Color.White.copy(alpha = .28f))
                            }
                        }
                    }
                }
            }
        }
    }

    if (showNewCategory) {
        AlertDialog(
            onDismissRequest = { showNewCategory = false },
            title = { Text("New category") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Custom categories sit alongside BOAL's automatic categories. Apps you move into one stay there until you move them again.", style = MaterialTheme.typography.bodySmall)
                    OutlinedTextField(
                        value = newCategoryName,
                        onValueChange = { newCategoryName = it },
                        label = { Text("Name") },
                        singleLine = true,
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        onCreateCategory(newCategoryName)
                        newCategoryName = ""
                        showNewCategory = false
                    },
                    enabled = newCategoryName.isNotBlank(),
                ) { Text("Create") }
            },
            dismissButton = { TextButton(onClick = { showNewCategory = false }) { Text("Cancel") } },
        )
    }
}
