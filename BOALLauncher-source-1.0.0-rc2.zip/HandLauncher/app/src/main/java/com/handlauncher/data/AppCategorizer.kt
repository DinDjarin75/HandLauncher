package com.handlauncher.data

import android.content.pm.ApplicationInfo
import com.handlauncher.domain.DefaultCategories

/**
 * Initial classification only. User edits always win and are persisted separately.
 * We prefer Android's app category when publishers supplied one, then fall back to
 * conservative package/label heuristics.
 */
object AppCategorizer {
    data class Classification(val categoryId: String, val tags: Set<String>)

    fun classify(packageName: String, label: String, androidCategory: Int = ApplicationInfo.CATEGORY_UNDEFINED): Classification {
        fromAndroidCategory(androidCategory)?.let { return it }

        val haystack = "$packageName $label".lowercase()
        fun containsAny(vararg terms: String) = terms.any(haystack::contains)

        return when {
            containsAny("whatsapp", "telegram", "signal", "messages", "messenger", "phone", "dialer", "contacts", "mail", "gmail", "outlook") ->
                Classification(DefaultCategories.communication.id, setOf("communication", "people"))

            containsAny("instagram", "facebook", "reddit", "tiktok", "threads", "linkedin", "x.com", "twitter", "bluesky", "mastodon") ->
                Classification(DefaultCategories.social.id, setOf("social", "people"))

            containsAny("spotify", "netflix", "youtube", "primevideo", "disney", "plex", "vlc", "music", "podcast", "audible", "twitch") ->
                Classification(DefaultCategories.media.id, setOf("media", "entertainment"))

            containsAny("camera", "photos", "gallery", "lightroom", "snapseed", "photo", "video editor") ->
                Classification(DefaultCategories.photo.id, setOf("photo", "creative"))

            containsAny("bank", "paypal", "revolut", "wise", "wallet", "finance", "trading", "broker", "crypto") ->
                Classification(DefaultCategories.finance.id, setOf("finance", "money"))

            containsAny("amazon", "ebay", "etsy", "shop", "store", "aliexpress", "vinted", "temu") ->
                Classification(DefaultCategories.shopping.id, setOf("shopping"))

            containsAny("maps", "waze", "uber", "booking", "airbnb", "travel", "flight", "train", "moovit") ->
                Classification(DefaultCategories.travel.id, setOf("travel", "navigation"))

            containsAny("smartthings", "home assistant", "google home", "hue", "alexa", "nest", "tuya") ->
                Classification(DefaultCategories.smartHome.id, setOf("smart-home", "iot"))

            containsAny("game", "steam", "xbox", "playstation", "roblox", "minecraft", "nintendo") ->
                Classification(DefaultCategories.games.id, setOf("games", "entertainment"))

            containsAny("calendar", "drive", "docs", "sheets", "office", "notion", "slack", "teams", "zoom", "meet", "todo", "tasks", "keep") ->
                Classification(DefaultCategories.productivity.id, setOf("productivity", "work"))

            containsAny("settings", "calculator", "clock", "files", "weather", "vpn", "authenticator", "scanner") ->
                Classification(DefaultCategories.utilities.id, setOf("utilities"))

            else -> Classification(DefaultCategories.other.id, setOf("other"))
        }
    }

    private fun fromAndroidCategory(category: Int): Classification? = when (category) {
        ApplicationInfo.CATEGORY_GAME -> Classification(DefaultCategories.games.id, setOf("games", "entertainment"))
        ApplicationInfo.CATEGORY_AUDIO, ApplicationInfo.CATEGORY_VIDEO -> Classification(DefaultCategories.media.id, setOf("media", "entertainment"))
        ApplicationInfo.CATEGORY_IMAGE -> Classification(DefaultCategories.photo.id, setOf("photo", "creative"))
        ApplicationInfo.CATEGORY_SOCIAL -> Classification(DefaultCategories.social.id, setOf("social", "people"))
        ApplicationInfo.CATEGORY_MAPS -> Classification(DefaultCategories.travel.id, setOf("travel", "navigation"))
        ApplicationInfo.CATEGORY_PRODUCTIVITY -> Classification(DefaultCategories.productivity.id, setOf("productivity", "work"))
        ApplicationInfo.CATEGORY_NEWS -> Classification(DefaultCategories.media.id, setOf("news", "media"))
        else -> null
    }
}
