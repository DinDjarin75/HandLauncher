package com.handlauncher.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.KeyboardArrowLeft
import androidx.compose.material.icons.rounded.KeyboardArrowRight
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.handlauncher.domain.NativeWidgetKind
import com.handlauncher.domain.SmartStackDefinition

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StackEditorScreen(
    stack: SmartStackDefinition,
    onNameChange: (String) -> Unit,
    onSmartRotationChange: (Boolean) -> Unit,
    onAutoLoopChange: (Boolean) -> Unit,
    onWidgetEnabledChange: (NativeWidgetKind, Boolean) -> Unit,
    onPromotionChange: (NativeWidgetKind, Boolean) -> Unit,
    onMove: (NativeWidgetKind, Int) -> Unit,
    onSave: () -> Unit,
    onDismiss: () -> Unit,
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stack.name) },
                navigationIcon = {
                    IconButton(onClick = onDismiss) { Icon(Icons.Rounded.ArrowBack, contentDescription = "Back") }
                },
                actions = { TextButton(onClick = onSave) { Text("Save") } },
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                OutlinedTextField(
                    value = stack.name,
                    onValueChange = onNameChange,
                    label = { Text("Stack name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            item { Text("Stack contents", style = MaterialTheme.typography.titleMedium) }
            NativeWidgetKind.entries.filter { it !in setOf(NativeWidgetKind.CONTEXT, NativeWidgetKind.NEWS, NativeWidgetKind.MEDIA) }.forEach { kind ->
                item(key = kind.name) {
                    val current = stack.items.firstOrNull { it.widgetKind == kind }
                    val index = stack.items.indexOfFirst { it.widgetKind == kind }
                    OutlinedCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(kind.name.lowercase().replaceFirstChar { it.uppercase() }, modifier = Modifier.weight(1f))
                                if (current != null) {
                                    IconButton(onClick = { onMove(kind, -1) }, enabled = index > 0) { Icon(Icons.Rounded.KeyboardArrowLeft, "Move earlier") }
                                    IconButton(onClick = { onMove(kind, 1) }, enabled = index in 0 until stack.items.lastIndex) { Icon(Icons.Rounded.KeyboardArrowRight, "Move later") }
                                }
                                val required = kind in setOf(NativeWidgetKind.CLOCK, NativeWidgetKind.WEATHER, NativeWidgetKind.BATTERY, NativeWidgetKind.CONNECTIVITY)
                                if (required) {
                                    Text("Always", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                } else {
                                    Checkbox(
                                        checked = current != null,
                                        onCheckedChange = { onWidgetEnabledChange(kind, it) },
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
