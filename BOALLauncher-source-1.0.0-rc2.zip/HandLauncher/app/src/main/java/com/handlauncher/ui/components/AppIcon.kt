package com.handlauncher.ui.components

import android.content.ComponentName
import android.graphics.Bitmap
import android.graphics.Canvas as AndroidCanvas
import android.graphics.drawable.Drawable
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.handlauncher.data.IconPackResolver
import com.handlauncher.domain.AppEntry

val LocalIconPackPackage = compositionLocalOf<String?> { null }

private fun Drawable.toBitmapSafely(sizePx: Int): Bitmap {
    val bitmap = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
    val canvas = AndroidCanvas(bitmap)
    setBounds(0, 0, sizePx, sizePx)
    draw(canvas)
    return bitmap
}

@Composable
fun ThemedPackageIcon(
    packageName: String,
    activityName: String? = null,
    contentDescription: String? = null,
    modifier: Modifier = Modifier,
    sizePx: Int = 96,
) {
    val context = LocalContext.current
    val iconPackPackage = LocalIconPackPackage.current
    val bitmap = remember(packageName, activityName, iconPackPackage, sizePx) {
        val drawable = IconPackResolver.resolveDrawable(
            context = context,
            iconPackPackage = iconPackPackage,
            packageName = packageName,
            activityName = activityName,
        ) ?: runCatching {
            if (activityName != null) {
                context.packageManager.getActivityIcon(ComponentName(packageName, activityName))
            } else {
                context.packageManager.getApplicationIcon(packageName)
            }
        }.getOrNull()
        drawable?.toBitmapSafely(sizePx)?.asImageBitmap()
    }
    if (bitmap != null) {
        Image(bitmap = bitmap, contentDescription = contentDescription, modifier = modifier)
    } else {
        Box(
            modifier = modifier.background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center,
        ) {
            Text(packageName.substringAfterLast('.').take(1).uppercase())
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppIcon(
    app: AppEntry,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    compact: Boolean = false,
    displayLabel: String = app.label,
    onLongClick: (() -> Unit)? = null,
    interactionEnabled: Boolean = true,
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(18.dp))
            .combinedClickable(enabled = interactionEnabled, onClick = onClick, onLongClick = onLongClick)
            .padding(6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        ThemedPackageIcon(
            packageName = app.packageName,
            activityName = app.activityName,
            contentDescription = displayLabel,
            modifier = Modifier.size(if (compact) 42.dp else 52.dp),
            sizePx = if (compact) 96 else 128,
        )
        val labelColor = Color.White
        val shadowColor = Color.Black.copy(alpha = 0.92f)
        Text(
            text = displayLabel,
            color = labelColor,
            style = MaterialTheme.typography.labelSmall.copy(
                shadow = Shadow(
                    color = shadowColor,
                    offset = Offset(0f, 1.5f),
                    blurRadius = 4f,
                )
            ),
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth(),
        )
    }
}
