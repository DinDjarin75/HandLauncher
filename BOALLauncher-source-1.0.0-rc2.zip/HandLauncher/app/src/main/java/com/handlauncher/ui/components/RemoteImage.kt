package com.handlauncher.ui.components

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.text.Html
import android.util.LruCache
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Newspaper
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URI
import java.net.URL
import java.util.Locale

private object ArticleImageMemoryCache {
    private val cache = object : LruCache<String, Bitmap>(14 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount / 1024
    }
    fun get(url: String): Bitmap? = cache.get(url)
    fun put(url: String, bitmap: Bitmap) { cache.put(url, bitmap) }
}

@Composable
fun RemoteArticleImage(
    imageUrl: String?,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    articleUrl: String? = null,
) {
    val cacheKey = imageUrl ?: articleUrl
    val bitmap = produceState<Bitmap?>(initialValue = cacheKey?.let(ArticleImageMemoryCache::get), key1 = imageUrl, key2 = articleUrl) {
        if (value != null) return@produceState
        value = withContext(Dispatchers.IO) {
            val primary = imageUrl?.let { loadBitmap(it, articleUrl) }
            if (primary != null) {
                cacheKey?.let { ArticleImageMemoryCache.put(it, primary) }
                primary
            } else {
                val fallbackUrl = articleUrl?.let(::resolveArticleLeadImage)
                fallbackUrl?.let { loadBitmap(it, articleUrl) }?.also { loaded ->
                    cacheKey?.let { ArticleImageMemoryCache.put(it, loaded) }
                    ArticleImageMemoryCache.put(fallbackUrl, loaded)
                }
            }
        }
    }.value

    val clipped = modifier.clip(RoundedCornerShape(topStart = 18.dp, bottomStart = 18.dp))
    if (bitmap != null) {
        Image(bitmap = bitmap.asImageBitmap(), contentDescription = contentDescription, modifier = clipped, contentScale = ContentScale.Crop)
    } else {
        Box(modifier = clipped.background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.40f)), contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.Newspaper, contentDescription = null, modifier = Modifier.fillMaxSize(0.28f))
        }
    }
}

private fun loadBitmap(url: String, referer: String?): Bitmap? = runCatching {
    val connection = (URL(url).openConnection() as HttpURLConnection).apply {
        connectTimeout = 5_500
        readTimeout = 8_000
        instanceFollowRedirects = true
        setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 16) AppleWebKit/537.36 Chrome/140 Mobile Safari/537.36")
        setRequestProperty("Accept", "image/jpeg,image/png,image/webp,image/*;q=0.8,*/*;q=0.5")
        setRequestProperty("Accept-Encoding", "identity")
        referer?.takeIf { it.startsWith("http") }?.let { setRequestProperty("Referer", it) }
    }
    if (connection.responseCode !in 200..399) return@runCatching null
    connection.inputStream.buffered().use { stream ->
        BitmapFactory.decodeStream(stream, null, BitmapFactory.Options().apply { inSampleSize = 2 })
    }?.takeIf { it.width >= 120 && it.height >= 80 }
}.getOrNull()

private fun resolveArticleLeadImage(articleUrl: String): String? = runCatching {
    val connection = (URL(articleUrl).openConnection() as HttpURLConnection).apply {
        connectTimeout = 5_000
        readTimeout = 7_000
        instanceFollowRedirects = true
        setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 16) AppleWebKit/537.36 Chrome/140 Mobile Safari/537.36")
        setRequestProperty("Accept", "text/html,application/xhtml+xml")
        setRequestProperty("Accept-Encoding", "identity")
    }
    if (connection.responseCode !in 200..399) return@runCatching null
    val finalUrl = connection.url.toString()
    val html = connection.inputStream.bufferedReader().use { reader ->
        val out = StringBuilder()
        val buffer = CharArray(8192)
        while (out.length < 300_000) {
            val read = reader.read(buffer)
            if (read <= 0) break
            out.append(buffer, 0, read.coerceAtMost(300_000 - out.length))
        }
        out.toString()
    }
    findMetaImage(html, finalUrl) ?: firstHtmlImage(html, finalUrl)
}.getOrNull()

private fun findMetaImage(html: String, baseUrl: String): String? {
    META_TAG.findAll(html).forEach { match ->
        val attrs = ATTRIBUTE.findAll(match.value).associate { attr ->
            attr.groupValues[1].lowercase(Locale.ROOT) to attr.groupValues[2]
        }
        val key = attrs["property"] ?: attrs["name"]
        if (key.equals("og:image", true) || key.equals("og:image:url", true) || key.equals("twitter:image", true) || key.equals("twitter:image:src", true)) {
            val raw = attrs["content"]?.let(::decodeHtml)
            absoluteUrl(baseUrl, raw)?.let { return it }
        }
    }
    return null
}

private fun firstHtmlImage(html: String, baseUrl: String): String? = IMG_SRC.findAll(html)
    .mapNotNull { it.groupValues.getOrNull(1)?.let(::decodeHtml) }
    .mapNotNull { absoluteUrl(baseUrl, it) }
    .firstOrNull { candidate ->
        val lower = candidate.lowercase(Locale.ROOT)
        !lower.contains("pixel") && !lower.contains("tracking") && !lower.contains("1x1") && !lower.contains("spacer.gif")
    }

private fun absoluteUrl(baseUrl: String, candidate: String?): String? {
    val value = candidate?.trim().orEmpty()
    if (value.isBlank() || value.startsWith("data:", ignoreCase = true)) return null
    return runCatching {
        val uri = URI(value)
        val resolved = if (uri.isAbsolute) uri else URI(baseUrl).resolve(uri)
        resolved.toString().takeIf { it.startsWith("http://") || it.startsWith("https://") }
    }.getOrNull()
}

private fun decodeHtml(value: String): String = Html.fromHtml(value, Html.FROM_HTML_MODE_LEGACY).toString().trim()

private val META_TAG = Regex("""<meta\s+[^>]*>""", RegexOption.IGNORE_CASE)
private val ATTRIBUTE = Regex("""([A-Za-z_:.-]+)\s*=\s*[\"']([^\"']*)[\"']""")
private val IMG_SRC = Regex("""<img[^>]+(?:src|data-src)\s*=\s*[\"']([^\"']+)[\"']""", RegexOption.IGNORE_CASE)
