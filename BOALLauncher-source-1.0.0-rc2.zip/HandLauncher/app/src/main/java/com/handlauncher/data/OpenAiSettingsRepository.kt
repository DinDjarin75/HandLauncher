package com.handlauncher.data

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

class OpenAiSettingsRepository(context: Context) {
    private val prefs = context.getSharedPreferences("boal_openai_settings", Context.MODE_PRIVATE)

    fun isConfigured(): Boolean = !readApiKey().isNullOrBlank()

    fun saveApiKey(raw: String) {
        val apiKey = raw.trim()
        if (apiKey.isBlank()) return
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
        val encrypted = cipher.doFinal(apiKey.toByteArray(Charsets.UTF_8))
        prefs.edit()
            .putString(KEY_API_KEY, Base64.encodeToString(encrypted, Base64.NO_WRAP))
            .putString(KEY_API_IV, Base64.encodeToString(cipher.iv, Base64.NO_WRAP))
            .apply()
    }

    fun clearApiKey() = prefs.edit().remove(KEY_API_KEY).remove(KEY_API_IV).apply()

    fun readApiKey(): String? = runCatching {
        val encrypted = prefs.getString(KEY_API_KEY, null) ?: return null
        val iv = prefs.getString(KEY_API_IV, null) ?: return null
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), GCMParameterSpec(128, Base64.decode(iv, Base64.NO_WRAP)))
        String(cipher.doFinal(Base64.decode(encrypted, Base64.NO_WRAP)), Charsets.UTF_8)
    }.getOrNull()

    private fun getOrCreateKey(): SecretKey {
        val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (keyStore.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(KEY_ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .build()
        )
        return generator.generateKey()
    }

    companion object {
        private const val KEY_API_KEY = "api_key"
        private const val KEY_API_IV = "api_iv"
        private const val KEY_ALIAS = "boal_workspace_openai_key"
        private const val TRANSFORMATION = "AES/GCM/NoPadding"
    }
}
