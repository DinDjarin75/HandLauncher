package com.handlauncher.ui.theme

import android.app.WallpaperColors
import android.app.WallpaperManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Handler
import android.os.Looper
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.core.graphics.ColorUtils
import com.handlauncher.domain.AiThemeTokens
import kotlin.math.abs

@Immutable
data class HandVisualTokens(
    val cornerRadiusDp: Int = 28,
    val surfaceAlpha: Float = 0.72f,
    val typographyMood: String = "clean",
)

/**
 * Wallpaper-derived color roles used by BOAL's own chrome.
 *
 * The wallpaper color is deliberately an accent rather than a surface tint: cards stay
 * neutral and readable while outlines, progress, focus states and subtle glow follow the
 * user's current wallpaper.
 */
@Immutable
data class HandAccentPalette(
    val accent: Color = Color(0xFF9E7BFF),
    val accentStrong: Color = Color(0xFFB794FF),
    val accentSoft: Color = Color(0xFF9E7BFF).copy(alpha = 0.32f),
    val accentFaint: Color = Color(0xFF9E7BFF).copy(alpha = 0.14f),
    val outline: Color = Color(0xFF9E7BFF).copy(alpha = 0.52f),
    val glow: Color = Color(0xFF9E7BFF).copy(alpha = 0.24f),
    val onAccent: Color = Color.White,
)

val LocalHandVisualTokens = staticCompositionLocalOf { HandVisualTokens() }
val LocalHandAccentPalette = staticCompositionLocalOf { HandAccentPalette() }

private data class WallpaperVisualState(
    val colors: WallpaperColors?,
    val generation: Int = 0,
)

private fun colorToHsl(argb: Int): FloatArray = FloatArray(3).also { ColorUtils.colorToHSL(argb, it) }

private fun normalizedAccent(argb: Int): Color {
    val hsl = colorToHsl(argb)
    // Keep the wallpaper hue, but pull extreme values into a usable UI-accent range.
    // Very muted wallpapers stay restrained instead of being artificially neon.
    val saturation = when {
        hsl[1] < 0.08f -> hsl[1]
        hsl[1] < 0.24f -> hsl[1].coerceAtLeast(0.24f)
        else -> hsl[1].coerceAtMost(0.88f)
    }
    val lightness = hsl[2].coerceIn(0.44f, 0.66f)
    hsl[1] = saturation
    hsl[2] = lightness
    return Color(ColorUtils.HSLToColor(hsl))
}

/** Select the wallpaper's main usable accent, preferring primary unless it is too neutral. */
private fun wallpaperAccent(colors: WallpaperColors?): Color {
    if (colors == null) return Color(0xFF9E7BFF)

    val candidates = listOfNotNull(colors.primaryColor, colors.secondaryColor, colors.tertiaryColor)
        .map { it.toArgb() }
    if (candidates.isEmpty()) return Color(0xFF9E7BFF)

    val primary = candidates.first()
    val primaryHsl = colorToHsl(primary)
    val selected = if (primaryHsl[1] >= 0.18f) {
        primary
    } else {
        // A gray/near-black primary is common on illustrated wallpapers. In that case,
        // prefer the most chromatic supporting color, but require a meaningful advantage.
        candidates.maxByOrNull { argb ->
            val hsl = colorToHsl(argb)
            hsl[1] * 1.8f - abs(hsl[2] - 0.55f) * 0.25f
        }?.takeIf { colorToHsl(it)[1] >= primaryHsl[1] + 0.08f } ?: primary
    }
    return normalizedAccent(selected)
}


/**
 * Manual accent override used by the explicit Settings recovery action.
 *
 * Modern Android blocks ordinary launchers from reading the wallpaper bitmap directly,
 * while some OEMs can return stale WallpaperColors after a wallpaper change. BOAL's
 * recovery path therefore samples a user-triggered AccessibilityService screenshot of
 * Home and writes the derived accent here. The override intentionally remains authoritative
 * for the process until the user refreshes it again.
 */
private var manualAccentOverride by mutableStateOf<Color?>(null)

fun applyManualAccentOverride(accent: Color) {
    manualAccentOverride = accent
}

/** Derive a usable wallpaper accent from the wallpaper-heavy lower portion of Home. */
fun sampleVisibleWallpaperAccent(bitmap: Bitmap): Color? {
    if (bitmap.width <= 0 || bitmap.height <= 0) return null

    val bins = 24
    val weights = DoubleArray(bins)
    val red = DoubleArray(bins)
    val green = DoubleArray(bins)
    val blue = DoubleArray(bins)

    // Home's Smart Stack / action rail occupy the upper region. Sampling the center/lower
    // wallpaper gives the artwork itself far more influence than BOAL's own chrome.
    val startY = (bitmap.height * 0.42f).toInt().coerceIn(0, bitmap.height - 1)
    val endY = (bitmap.height * 0.93f).toInt().coerceIn(startY + 1, bitmap.height)
    val startX = (bitmap.width * 0.05f).toInt().coerceIn(0, bitmap.width - 1)
    val endX = (bitmap.width * 0.95f).toInt().coerceIn(startX + 1, bitmap.width)
    val stepX = (bitmap.width / 90).coerceAtLeast(2)
    val stepY = (bitmap.height / 160).coerceAtLeast(2)

    for (y in startY until endY step stepY) {
        for (x in startX until endX step stepX) {
            val pixel = bitmap.getPixel(x, y)
            if (android.graphics.Color.alpha(pixel) < 160) continue
            val hsl = colorToHsl(pixel)
            val saturation = hsl[1]
            val lightness = hsl[2]
            if (saturation < 0.20f || lightness < 0.08f || lightness > 0.94f) continue

            val midTone = (1f - abs(lightness - 0.52f) * 1.35f).coerceIn(0.14f, 1f)
            val weight = (saturation * saturation * midTone).toDouble()
            val bin = ((hsl[0] / 360f) * bins).toInt().coerceIn(0, bins - 1)
            weights[bin] += weight
            red[bin] += android.graphics.Color.red(pixel) * weight
            green[bin] += android.graphics.Color.green(pixel) * weight
            blue[bin] += android.graphics.Color.blue(pixel) * weight
        }
    }

    val best = weights.indices.maxByOrNull { weights[it] } ?: return null
    val total = weights[best]
    if (total <= 0.001) return null
    val sampled = android.graphics.Color.rgb(
        (red[best] / total).toInt().coerceIn(0, 255),
        (green[best] / total).toInt().coerceIn(0, 255),
        (blue[best] / total).toInt().coerceIn(0, 255),
    )
    return normalizedAccent(sampled)
}

private fun buildAccentPalette(seed: Color): HandAccentPalette {
    val seedArgb = android.graphics.Color.argb(
        255,
        (seed.red * 255).toInt(),
        (seed.green * 255).toInt(),
        (seed.blue * 255).toInt(),
    )
    val hsl = colorToHsl(seedArgb)

    fun tone(lightness: Float, saturationScale: Float = 1f): Color {
        val adjusted = hsl.copyOf().apply {
            this[1] = (this[1] * saturationScale).coerceIn(0f, 0.92f)
            this[2] = lightness.coerceIn(0f, 1f)
        }
        return Color(ColorUtils.HSLToColor(adjusted))
    }

    val accent = seed
    val accentStrong = tone((hsl[2] + 0.10f).coerceAtMost(0.72f), 1.04f)
    val onAccent = if (accent.luminance() > 0.52f) Color(0xFF111015) else Color.White
    return HandAccentPalette(
        accent = accent,
        accentStrong = accentStrong,
        accentSoft = accent.copy(alpha = 0.32f),
        accentFaint = accent.copy(alpha = 0.14f),
        outline = accentStrong.copy(alpha = 0.50f),
        glow = accentStrong.copy(alpha = 0.23f),
        onAccent = onAccent,
    )
}

@Composable
private fun rememberWallpaperVisualState(context: Context): WallpaperVisualState {
    val manager = remember(context) { WallpaperManager.getInstance(context.applicationContext) }
    var state by remember(manager) {
        mutableStateOf(
            WallpaperVisualState(
                colors = runCatching { manager.getWallpaperColors(WallpaperManager.FLAG_SYSTEM) }.getOrNull(),
            )
        )
    }


    DisposableEffect(manager) {
        val listener = WallpaperManager.OnColorsChangedListener { colors, which ->
            if (which and WallpaperManager.FLAG_SYSTEM != 0) {
                state = WallpaperVisualState(
                    colors = colors ?: state.colors,
                    generation = state.generation + 1,
                )
            }
        }
        runCatching {
            manager.addOnColorsChangedListener(listener, Handler(Looper.getMainLooper()))
        }
        onDispose { runCatching { manager.removeOnColorsChangedListener(listener) } }
    }
    return state
}

/**
 * Returns true when BOAL should use a dark Material palette (light foreground).
 * Transparent launcher surfaces sit directly over the wallpaper, so foreground
 * contrast follows a small sample of the upper wallpaper rather than trusting the
 * AI theme's requested light/dark mode.
 */
fun resolveWallpaperDarkPalette(context: Context, fallbackDark: Boolean = true): Boolean {
    // WallpaperColors describes the whole image and can choose dark text for a mixed
    // wallpaper even when the launcher header sits over a dark area. Sample a tiny
    // rendering of the upper wallpaper instead; app labels also carry an opposite
    // shadow for local contrast changes lower on the screen.
    val sampled = runCatching {
        val drawable = WallpaperManager.getInstance(context).drawable ?: return@runCatching null
        val bitmap = Bitmap.createBitmap(48, 48, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        drawable.setBounds(0, 0, bitmap.width, bitmap.height)
        drawable.draw(canvas)

        var luminanceSum = 0.0
        var darkPixels = 0
        var samples = 0
        val maxY = (bitmap.height * 0.72f).toInt().coerceAtLeast(1)
        for (y in 0 until maxY step 2) {
            for (x in 0 until bitmap.width step 2) {
                val luminance = ColorUtils.calculateLuminance(bitmap.getPixel(x, y))
                luminanceSum += luminance
                if (luminance < 0.45) darkPixels++
                samples++
            }
        }
        bitmap.recycle()
        if (samples == 0) null else {
            val average = luminanceSum / samples
            val darkShare = darkPixels.toDouble() / samples
            average < 0.54 || darkShare >= 0.55
        }
    }.getOrNull()
    if (sampled != null) return sampled

    return runCatching {
        val colors = WallpaperManager.getInstance(context)
            .getWallpaperColors(WallpaperManager.FLAG_SYSTEM)
            ?: return@runCatching fallbackDark
        val supportsDarkText = colors.colorHints and WallpaperColors.HINT_SUPPORTS_DARK_TEXT != 0
        !supportsDarkText
    }.getOrDefault(fallbackDark)
}

@Composable
fun BOALLauncherTheme(
    theme: AiThemeTokens? = null,
    darkTheme: Boolean = theme?.dark ?: true,
    content: @Composable () -> Unit,
) {
    val context = LocalContext.current
    val wallpaperState = rememberWallpaperVisualState(context)
    val wallpaperDarkPalette = remember(context, darkTheme, wallpaperState.colors, wallpaperState.generation) {
        resolveWallpaperDarkPalette(context, darkTheme)
    }

    val targetAccent = manualAccentOverride ?: remember(wallpaperState.colors, wallpaperState.generation) {
        wallpaperAccent(wallpaperState.colors)
    }
    val targetPalette = remember(targetAccent) { buildAccentPalette(targetAccent) }
    val accent by animateColorAsState(targetPalette.accent, tween(450), label = "wallpaperAccent")
    val accentStrong by animateColorAsState(targetPalette.accentStrong, tween(450), label = "wallpaperAccentStrong")
    val animatedPalette = remember(accent, accentStrong) {
        buildAccentPalette(accent).copy(accentStrong = accentStrong)
    }

    val mood = theme?.typographyMood?.lowercase() ?: "clean"
    val visuals = HandVisualTokens(
        cornerRadiusDp = (theme?.cornerRadiusDp ?: 28).coerceIn(0, 48),
        surfaceAlpha = (1f - (theme?.transparencyPercent ?: 28).coerceIn(0, 85) / 100f).coerceIn(0.15f, 1f),
        typographyMood = mood,
    )
    val base = Typography()
    val typography = when (mood) {
        "bold" -> Typography(
            displayLarge = base.displayLarge.copy(fontWeight = FontWeight.Bold),
            displayMedium = base.displayMedium.copy(fontWeight = FontWeight.Bold),
            headlineLarge = base.headlineLarge.copy(fontWeight = FontWeight.Bold),
            titleLarge = base.titleLarge.copy(fontWeight = FontWeight.Bold),
        )
        "editorial" -> Typography(
            displayLarge = base.displayLarge.copy(fontFamily = FontFamily.Serif, fontWeight = FontWeight.Light),
            displayMedium = base.displayMedium.copy(fontFamily = FontFamily.Serif, fontWeight = FontWeight.Light),
            headlineLarge = base.headlineLarge.copy(fontFamily = FontFamily.Serif),
            titleLarge = base.titleLarge.copy(fontFamily = FontFamily.Serif),
        )
        "minimal" -> Typography(
            displayLarge = base.displayLarge.copy(fontWeight = FontWeight.Thin),
            displayMedium = base.displayMedium.copy(fontWeight = FontWeight.Thin),
            headlineLarge = base.headlineLarge.copy(fontWeight = FontWeight.Light),
            titleLarge = base.titleLarge.copy(fontWeight = FontWeight.Light),
        )
        else -> base
    }

    val colorScheme = if (wallpaperDarkPalette) {
        darkColorScheme(
            primary = animatedPalette.accentStrong,
            secondary = animatedPalette.accent,
            tertiary = animatedPalette.accentStrong,
            onPrimary = animatedPalette.onAccent,
            onBackground = Color(0xFFF7F5FF),
            onSurface = Color(0xFFF7F5FF),
            onSurfaceVariant = Color(0xFFD6D0E0),
            surfaceTint = animatedPalette.accent,
        )
    } else {
        lightColorScheme(
            primary = animatedPalette.accent,
            secondary = animatedPalette.accentStrong,
            tertiary = animatedPalette.accent,
            onPrimary = animatedPalette.onAccent,
            onBackground = Color(0xFF111015),
            onSurface = Color(0xFF111015),
            onSurfaceVariant = Color(0xFF4F4A55),
            surfaceTint = animatedPalette.accent,
        )
    }

    CompositionLocalProvider(
        LocalHandVisualTokens provides visuals,
        LocalHandAccentPalette provides animatedPalette,
    ) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = typography,
            content = content,
        )
    }
}
