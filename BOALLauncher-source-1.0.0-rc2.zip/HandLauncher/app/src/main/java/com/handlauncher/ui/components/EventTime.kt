package com.handlauncher.ui.components

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter

fun humanEventTime(startMillis: Long?, minutesAway: Int?): String? {
    if (startMillis == null) return minutesAway?.let { if (it <= 0) "Now" else if (it < 90) "in $it min" else null }
    if (minutesAway != null && minutesAway <= 0) return "Now"
    if (minutesAway != null && minutesAway < 90) return "in $minutesAway min"

    val zone = ZoneId.systemDefault()
    val event = Instant.ofEpochMilli(startMillis).atZone(zone)
    val today = LocalDate.now(zone)
    val day = event.toLocalDate()
    val time = event.toLocalTime().format(DateTimeFormatter.ofPattern("HH:mm"))
    return when (day) {
        today -> "Today · $time"
        today.plusDays(1) -> "Tomorrow · $time"
        else -> "${day.format(DateTimeFormatter.ofPattern("EEE, d MMM"))} · $time"
    }
}
