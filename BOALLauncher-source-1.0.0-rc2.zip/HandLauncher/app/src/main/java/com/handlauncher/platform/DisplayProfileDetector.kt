package com.handlauncher.platform

import android.app.Activity
import android.content.Context
import android.content.res.Configuration
import android.hardware.display.DisplayManager
import android.view.Display
import androidx.window.layout.FoldingFeature
import androidx.window.layout.WindowLayoutInfo
import com.handlauncher.domain.LayoutProfile

/** Resolves the launcher layout profile from the active display, window size and fold posture. */
class DisplayProfileDetector(private val context: Context) {
    fun resolve(activity: Activity, layoutInfo: WindowLayoutInfo? = null): LayoutProfile {
        val displayManager = context.getSystemService(DisplayManager::class.java)
        val currentDisplayId = activity.display?.displayId ?: Display.DEFAULT_DISPLAY
        val isExternal = currentDisplayId != Display.DEFAULT_DISPLAY ||
            displayManager.displays.any { it.displayId == currentDisplayId && it.displayId != Display.DEFAULT_DISPLAY }
        if (isExternal) return LayoutProfile.EXTERNAL_DISPLAY

        val config = context.resources.configuration
        val width = config.screenWidthDp
        val height = config.screenHeightDp
        val fold = layoutInfo?.displayFeatures?.filterIsInstance<FoldingFeature>()?.firstOrNull()

        // A separating hinge or half-open posture is unquestionably the large/fold surface.
        if (fold?.isSeparating == true || fold?.state == FoldingFeature.State.HALF_OPENED) {
            return LayoutProfile.INNER_FOLD
        }

        return when {
            width >= 600 -> LayoutProfile.INNER_FOLD
            config.orientation == Configuration.ORIENTATION_LANDSCAPE -> LayoutProfile.PHONE_LANDSCAPE
            width < 430 && height >= 700 -> LayoutProfile.COVER
            else -> LayoutProfile.PHONE_PORTRAIT
        }
    }
}
