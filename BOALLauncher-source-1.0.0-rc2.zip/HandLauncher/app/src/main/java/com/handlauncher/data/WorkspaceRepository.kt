package com.handlauncher.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

@JvmInline
value class WorkspaceChatRole(val value: String) {
    companion object {
        val USER = WorkspaceChatRole("user")
        val ASSISTANT = WorkspaceChatRole("assistant")
    }
}

data class WorkspaceChatMessage(
    val id: String,
    val role: WorkspaceChatRole,
    val text: String,
    val timestampMillis: Long,
)

class WorkspaceRepository(context: Context) {
    private val prefs = context.getSharedPreferences("boal_workspace", Context.MODE_PRIVATE)

    fun keepWidgetId(): Int? = prefs.getInt(KEY_KEEP_WIDGET_ID, -1).takeIf { it >= 0 }
    fun saveKeepWidgetId(id: Int?) {
        prefs.edit().apply {
            if (id == null) remove(KEY_KEEP_WIDGET_ID) else putInt(KEY_KEEP_WIDGET_ID, id)
        }.apply()
    }


    fun showlyShowsWidgetId(): Int? = prefs.getInt(KEY_SHOWLY_SHOWS_WIDGET_ID, -1).takeIf { it >= 0 }
    fun showlyMoviesWidgetId(): Int? = prefs.getInt(KEY_SHOWLY_MOVIES_WIDGET_ID, -1).takeIf { it >= 0 }

    fun saveShowlyShowsWidgetId(id: Int?) {
        prefs.edit().apply {
            if (id == null) remove(KEY_SHOWLY_SHOWS_WIDGET_ID) else putInt(KEY_SHOWLY_SHOWS_WIDGET_ID, id)
        }.apply()
    }

    fun saveShowlyMoviesWidgetId(id: Int?) {
        prefs.edit().apply {
            if (id == null) remove(KEY_SHOWLY_MOVIES_WIDGET_ID) else putInt(KEY_SHOWLY_MOVIES_WIDGET_ID, id)
        }.apply()
    }

    fun carouselIndex(): Int = prefs.getInt(KEY_CAROUSEL_INDEX, 0).coerceIn(0, 5)
    fun saveCarouselIndex(index: Int) { prefs.edit().putInt(KEY_CAROUSEL_INDEX, index.coerceIn(0, 5)).apply() }

    fun conversationId(): String? = prefs.getString(KEY_CONVERSATION_ID, null)
    fun saveConversationId(id: String?) {
        prefs.edit().apply {
            if (id.isNullOrBlank()) remove(KEY_CONVERSATION_ID) else putString(KEY_CONVERSATION_ID, id)
        }.apply()
    }

    fun messages(): List<WorkspaceChatMessage> = runCatching {
        val array = JSONArray(prefs.getString(KEY_MESSAGES, "[]"))
        buildList {
            for (index in 0 until array.length()) {
                val obj = array.getJSONObject(index)
                add(
                    WorkspaceChatMessage(
                        id = obj.optString("id"),
                        role = WorkspaceChatRole(obj.optString("role", "assistant")),
                        text = obj.optString("text"),
                        timestampMillis = obj.optLong("timestampMillis", System.currentTimeMillis()),
                    )
                )
            }
        }
    }.getOrDefault(emptyList())

    fun saveMessages(messages: List<WorkspaceChatMessage>) {
        val array = JSONArray()
        messages.takeLast(40).forEach { message ->
            array.put(
                JSONObject()
                    .put("id", message.id)
                    .put("role", message.role.value)
                    .put("text", message.text)
                    .put("timestampMillis", message.timestampMillis)
            )
        }
        prefs.edit().putString(KEY_MESSAGES, array.toString()).apply()
    }

    fun clearChat() {
        prefs.edit().remove(KEY_MESSAGES).remove(KEY_CONVERSATION_ID).apply()
    }

    companion object {
        private const val KEY_KEEP_WIDGET_ID = "keep_widget_id"
        private const val KEY_SHOWLY_SHOWS_WIDGET_ID = "showly_shows_widget_id"
        private const val KEY_SHOWLY_MOVIES_WIDGET_ID = "showly_movies_widget_id"
        private const val KEY_CAROUSEL_INDEX = "workspace_carousel_index"
        private const val KEY_CONVERSATION_ID = "openai_conversation_id"
        private const val KEY_MESSAGES = "chat_messages"
    }
}
