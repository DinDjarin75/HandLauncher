package com.handlauncher.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.handlauncher.domain.AiProviderSettings
import com.handlauncher.data.WeatherState
import com.handlauncher.data.IconPackInfo
import com.handlauncher.ui.theme.LocalHandAccentPalette

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    aiSettings: AiProviderSettings,
    weather: WeatherState,
    iconPacks: List<IconPackInfo>,
    selectedIconPackPackage: String?,
    isHomeRoleHeld: Boolean,
    onRequestHomeRole: () -> Unit,
    onSaveAi: (String, String?) -> Unit,
    onClearAiKey: () -> Unit,
    onSaveWeather: (String, Double, Double) -> Unit,
    onExport: () -> Unit,
    onImport: () -> Unit,
    onAutomations: () -> Unit,
    onMediaAccess: () -> Unit,
    onSystemGestureAccess: () -> Unit,
    onSelectIconPack: (String?) -> Unit,
    onRefreshWallpaperAccent: () -> Unit,
    onDismiss: () -> Unit,
) {
    BackHandler(onBack = onDismiss)
    var model by remember(aiSettings.model) { mutableStateOf(aiSettings.model) }
    var apiKey by remember { mutableStateOf("") }
    var weatherLabel by remember(weather.location.label) { mutableStateOf(weather.location.label) }
    var weatherLat by remember(weather.location.latitude) { mutableStateOf(weather.location.latitude.toString()) }
    var weatherLon by remember(weather.location.longitude) { mutableStateOf(weather.location.longitude.toString()) }
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = { IconButton(onClick = onDismiss) { Icon(Icons.Rounded.ArrowBack, "Back") } },
            )
        }
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Launcher", style = MaterialTheme.typography.titleMedium)
                    Text(if (isHomeRoleHeld) "Default Home is enabled" else "This is not yet your default Home")
                    if (!isHomeRoleHeld) Button(onClick = onRequestHomeRole) { Text("Set as default Home") }
                    OutlinedButton(onClick = onAutomations) { Icon(Icons.Rounded.Bolt, null); Spacer(Modifier.width(8.dp)); Text("Automations") }
                    OutlinedButton(onClick = onMediaAccess) { Icon(Icons.Rounded.GraphicEq, null); Spacer(Modifier.width(8.dp)); Text("Notifications & media access") }
                    OutlinedButton(onClick = onSystemGestureAccess) { Icon(Icons.Rounded.TouchApp, null); Spacer(Modifier.width(8.dp)); Text("System shade gestures") }
                }
            }

            val adaptiveAccent = LocalHandAccentPalette.current
            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Appearance", style = MaterialTheme.typography.titleMedium)
                    Row(
                        Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Box(
                            Modifier
                                .size(44.dp)
                                .background(adaptiveAccent.accent, CircleShape)
                                .border(2.dp, adaptiveAccent.accentStrong, CircleShape)
                        )
                        Column(Modifier.weight(1f)) {
                            Text("Adaptive accent", style = MaterialTheme.typography.titleSmall)
                            Text(
                                "Wallpaper · updates automatically",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        Icon(Icons.Rounded.AutoAwesome, contentDescription = null, tint = adaptiveAccent.accentStrong)
                    }
                    Text(
                        "BOAL extracts a usable accent from your current wallpaper while keeping glass surfaces neutral for readability.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    FilledTonalButton(
                        onClick = onRefreshWallpaperAccent,
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Icon(Icons.Rounded.Refresh, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Refresh from wallpaper")
                    }
                    Text(
                        "BOAL briefly opens Home, samples the visible wallpaper, then returns here.",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Icons", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Apply an installed icon-pack APK across Home, App Library, search and notifications.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Row(
                        Modifier.fillMaxWidth().clickable { onSelectIconPack(null) }.padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        RadioButton(selected = selectedIconPackPackage == null, onClick = { onSelectIconPack(null) })
                        Spacer(Modifier.width(8.dp))
                        Text("Original app icons")
                    }
                    iconPacks.forEach { pack ->
                        Row(
                            Modifier.fillMaxWidth().clickable { onSelectIconPack(pack.packageName) }.padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            RadioButton(
                                selected = selectedIconPackPackage == pack.packageName,
                                onClick = { onSelectIconPack(pack.packageName) },
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(pack.label, maxLines = 1)
                        }
                    }
                    if (iconPacks.isEmpty()) {
                        Text(
                            "No compatible icon packs found. Install an APK/icon pack (including Icon Pack Studio exports), then return here.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }

            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("AI designer", style = MaterialTheme.typography.titleMedium)
                    Text(
                        if (aiSettings.apiKeyConfigured) "Gemini is configured. Your key is encrypted with Android Keystore and excluded from backups."
                        else "Without a Gemini key, layouts are generated locally.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    OutlinedTextField(model, { model = it }, label = { Text("Gemini model") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(
                        value = apiKey,
                        onValueChange = { apiKey = it },
                        label = { Text(if (aiSettings.apiKeyConfigured) "Replace API key (optional)" else "Gemini API key (optional)") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { onSaveAi(model, apiKey.takeIf(String::isNotBlank)); apiKey = "" }) { Text("Save") }
                        if (aiSettings.apiKeyConfigured) OutlinedButton(onClick = onClearAiKey) { Text("Remove key") }
                    }
                }
            }

            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Weather", style = MaterialTheme.typography.titleMedium)
                    Text("Choose a coarse location for weather without continuous location access.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    OutlinedTextField(weatherLabel, { weatherLabel = it }, label = { Text("Location label") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(weatherLat, { weatherLat = it }, label = { Text("Latitude") }, singleLine = true, modifier = Modifier.weight(1f))
                        OutlinedTextField(weatherLon, { weatherLon = it }, label = { Text("Longitude") }, singleLine = true, modifier = Modifier.weight(1f))
                    }
                    Text("${weather.temperatureC?.let { "${kotlin.math.round(it).toInt()}°" } ?: "—°"} · ${weather.condition}", style = MaterialTheme.typography.bodySmall)
                    OutlinedButton(onClick = {
                        val lat = weatherLat.toDoubleOrNull(); val lon = weatherLon.toDoubleOrNull()
                        if (lat != null && lon != null) onSaveWeather(weatherLabel, lat, lon)
                    }) { Text("Save weather location") }
                }
            }

            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Backup & restore", style = MaterialTheme.typography.titleMedium)
                    Text("Exports layouts, categories, automations, Smart Objects and themes. AI credentials are never exported.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = onExport) { Icon(Icons.Rounded.Upload, null); Spacer(Modifier.width(6.dp)); Text("Export") }
                        OutlinedButton(onClick = onImport) { Icon(Icons.Rounded.Download, null); Spacer(Modifier.width(6.dp)); Text("Restore") }
                    }
                }
            }

            Spacer(Modifier.height(18.dp))
        }
    }
}
