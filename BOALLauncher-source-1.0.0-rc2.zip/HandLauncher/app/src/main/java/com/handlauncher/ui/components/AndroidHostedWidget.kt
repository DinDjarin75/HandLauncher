package com.handlauncher.ui.components

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.viewinterop.AndroidView
import com.handlauncher.platform.AndroidWidgetHostController

@Composable
fun AndroidHostedWidget(
    appWidgetId: Int,
    hostController: AndroidWidgetHostController,
    modifier: Modifier = Modifier,
) {
    val info = hostController.providerInfo(appWidgetId)
    if (info == null) {
        Box(modifier, contentAlignment = Alignment.Center) {
            Text("Widget unavailable", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        return
    }

    val density = LocalDensity.current
    var widthDp by remember { mutableIntStateOf(0) }
    var heightDp by remember { mutableIntStateOf(0) }
    LaunchedEffect(appWidgetId, widthDp, heightDp) {
        if (widthDp > 0 && heightDp > 0) {
            hostController.updateSize(appWidgetId, widthDp, heightDp, widthDp, heightDp)
        }
    }

    AndroidView(
        modifier = modifier
            .fillMaxSize()
            .onSizeChanged { size ->
                widthDp = with(density) { size.width.toDp().value.toInt() }
                heightDp = with(density) { size.height.toDp().value.toInt() }
            },
        factory = {
            hostController.createHostView(appWidgetId) ?: android.widget.FrameLayout(it)
        },
        update = { view ->
            if (view is android.appwidget.AppWidgetHostView) view.setAppWidget(appWidgetId, info)
        },
    )
}
