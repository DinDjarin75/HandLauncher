package com.handlauncher.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.unit.dp
import com.handlauncher.ui.theme.LocalHandAccentPalette
import com.handlauncher.ui.theme.LocalHandVisualTokens

/**
 * Shared translucent surface for BOAL's own UI.
 *
 * The surface itself deliberately remains neutral so a wallpaper change never turns the
 * launcher into one large colored sheet. Only the fine outline follows the adaptive accent;
 * widgets add stronger accent roles where they convey state or interaction.
 */
@Composable
fun HandGlassSurface(
    modifier: Modifier = Modifier,
    cornerRadiusDp: Int? = null,
    contentPadding: PaddingValues = PaddingValues(18.dp),
    content: @Composable BoxScope.() -> Unit,
) {
    val visuals = LocalHandVisualTokens.current
    val accent = LocalHandAccentPalette.current
    val baseSurface = MaterialTheme.colorScheme.surface
    val foreground = if (baseSurface.luminance() < 0.45f) Color.White else Color(0xFF111015)
    val shape = RoundedCornerShape((cornerRadiusDp ?: visuals.cornerRadiusDp).dp)
    val alpha = visuals.surfaceAlpha
    val glassBrush = Brush.verticalGradient(
        listOf(
            baseSurface.copy(alpha = (alpha + 0.08f).coerceAtMost(0.94f)),
            baseSurface.copy(alpha = (alpha - 0.04f).coerceAtLeast(0.14f)),
        )
    )

    CompositionLocalProvider(LocalContentColor provides foreground) {
        Box(
            modifier = modifier
                .background(glassBrush, shape)
                .border(0.8.dp, accent.outline, shape)
                .padding(contentPadding),
            content = content,
        )
    }
}
