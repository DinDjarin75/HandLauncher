package com.handlauncher.engine

import com.handlauncher.domain.AppEntry

class SearchEngine {
    fun search(apps: List<AppEntry>, rawQuery: String): List<AppEntry> {
        val query = rawQuery.trim().lowercase()
        if (query.isBlank()) return apps.take(12)

        return apps.asSequence()
            .map { app -> app to score(app, query) }
            .filter { (_, score) -> score > 0 }
            .sortedWith(compareByDescending<Pair<AppEntry, Int>> { it.second }.thenBy { it.first.label.lowercase() })
            .map { it.first }
            .take(40)
            .toList()
    }

    private fun score(app: AppEntry, query: String): Int {
        val label = app.label.lowercase()
        val packageName = app.packageName.lowercase()
        return when {
            label == query -> 100
            label.startsWith(query) -> 80
            label.split(" ").any { it.startsWith(query) } -> 65
            label.contains(query) -> 50
            app.tags.any { it.startsWith(query) } -> 35
            app.categoryId.contains(query) -> 25
            packageName.contains(query) -> 10
            else -> 0
        }
    }
}
