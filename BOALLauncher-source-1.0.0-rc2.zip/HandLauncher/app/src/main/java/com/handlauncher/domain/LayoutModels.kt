package com.handlauncher.domain

enum class LayoutProfile {
    COVER,
    INNER_FOLD,
    PHONE_PORTRAIT,
    PHONE_LANDSCAPE,
    EXTERNAL_DISPLAY,
}

data class LayoutPage(
    val id: String,
    val title: String,
    val objects: List<SmartObject>,
)

data class LauncherLayout(
    val id: String,
    val name: String,
    val profile: LayoutProfile,
    val columns: Int,
    val rows: Int,
    val finePositioning: Boolean,
    val locked: Boolean = false,
    val pages: List<LayoutPage>,
)
