package com.handlauncher.domain

import java.time.LocalDateTime

data class ContextSnapshot(
    val now: LocalDateTime,
    val phoneBatteryPercent: Int,
    val isCharging: Boolean,
    val layoutProfile: LayoutProfile,
    val connectedBluetoothNames: Set<String> = emptySet(),
    val nextCalendarEventInMinutes: Int? = null,
    val rainExpectedInMinutes: Int? = null,
)

sealed interface ContextCondition {
    data class BatteryBelow(val percent: Int) : ContextCondition
    data class ChargingIs(val charging: Boolean) : ContextCondition
    data class TimeBetween(val startHour: Int, val endHourExclusive: Int) : ContextCondition
    data class ProfileIs(val profile: LayoutProfile) : ContextCondition
    data class BluetoothConnected(val nameContains: String) : ContextCondition
    data class EventWithin(val minutes: Int) : ContextCondition
    data class RainWithin(val minutes: Int) : ContextCondition
}

sealed interface ContextEffect {
    data class PromoteWidget(val kind: NativeWidgetKind) : ContextEffect
    data class SuggestCommand(val title: String, val command: String) : ContextEffect
    data class SurfaceObject(val objectId: String) : ContextEffect
}

data class ContextRule(
    val id: String,
    val name: String,
    val enabled: Boolean = true,
    val conditions: List<ContextCondition>,
    val effect: ContextEffect,
    val userCreated: Boolean = false,
)

data class ContextDecision(
    val matchedRuleIds: List<String>,
    val effects: List<ContextEffect>,
)
