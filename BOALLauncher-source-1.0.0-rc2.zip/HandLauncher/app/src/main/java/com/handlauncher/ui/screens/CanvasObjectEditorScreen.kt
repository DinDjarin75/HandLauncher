package com.handlauncher.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.handlauncher.domain.NativeWidgetKind
import com.handlauncher.domain.SmartObject
import com.handlauncher.domain.SmartObjectType

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CanvasObjectEditorScreen(
    smartObject: SmartObject,
    onTitleChange: (String) -> Unit,
    onPayloadChange: (String, String) -> Unit,
    onSave: () -> Unit,
    onDismiss: () -> Unit,
) {
    BackHandler(onBack = onDismiss)
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Edit ${smartObject.type.name.replace('_', ' ').lowercase()}") },
                navigationIcon = { IconButton(onClick = onDismiss) { Icon(Icons.Rounded.Close, "Close") } },
                actions = { TextButton(onClick = onSave) { Text("Save") } },
            )
        }
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            OutlinedTextField(
                value = smartObject.title,
                onValueChange = onTitleChange,
                label = { Text("Label") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )

            if (smartObject.type == SmartObjectType.NATIVE_WIDGET) {
                Text("Widget appearance", style = MaterialTheme.typography.titleMedium)
                val variant = smartObject.payload["variant"] ?: "standard"
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("minimal", "standard", "detailed").forEach { option ->
                        FilterChip(
                            selected = variant == option,
                            onClick = { onPayloadChange("variant", option) },
                            label = { Text(option.replaceFirstChar { it.uppercase() }) },
                        )
                    }
                }
                val kind = runCatching { NativeWidgetKind.valueOf(smartObject.payload["widgetKind"].orEmpty()) }.getOrNull()
                if (kind == NativeWidgetKind.CLOCK) {
                    SettingSwitch(
                        label = "Show seconds",
                        checked = smartObject.payload["showSeconds"] == "true",
                        onChange = { onPayloadChange("showSeconds", it.toString()) },
                    )
                    SettingSwitch(
                        label = "Show date",
                        checked = smartObject.payload["showDate"] != "false",
                        onChange = { onPayloadChange("showDate", it.toString()) },
                    )
                }
                if (kind == NativeWidgetKind.BATTERY) {
                    SettingSwitch(
                        label = "Show connected devices",
                        checked = smartObject.payload["showDevices"] != "false",
                        onChange = { onPayloadChange("showDevices", it.toString()) },
                    )
                }
            }

            if (smartObject.type == SmartObjectType.COMMAND) {
                OutlinedTextField(
                    value = smartObject.payload["command"].orEmpty(),
                    onValueChange = { onPayloadChange("command", it) },
                    label = { Text("Command") },
                    modifier = Modifier.fillMaxWidth(),
                )
            }

            Spacer(Modifier.weight(1f))
            Button(onClick = onSave, modifier = Modifier.fillMaxWidth()) { Text("Save object") }
        }
    }
}

@Composable
private fun SettingSwitch(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
