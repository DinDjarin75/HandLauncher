package com.handlauncher.data

import android.content.Context
import android.text.Html
import android.util.Xml
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import org.xmlpull.v1.XmlPullParser
import java.net.HttpURLConnection
import java.net.URI
import java.net.URL
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap


data class NewsHeadline(
    val title: String,
    val url: String,
    val source: String = "",
    val publishedAtMillis: Long? = null,
    val imageUrl: String? = null,
)

data class NewsState(
    val headlines: List<NewsHeadline> = emptyList(),
    val entertainment: List<NewsHeadline> = emptyList(),
    val tech: List<NewsHeadline> = emptyList(),
    val lego: List<NewsHeadline> = emptyList(),
    val available: Boolean = false,
    val lastUpdatedMillis: Long? = null,
    val message: String? = null,
)

/**
 * Key-free briefing news provider.
 *
 * Alpha07 hotfix: use direct publisher feeds with article images instead of Google News
 * wrapper links. Each section merges several feeds, sorts by publication time and keeps
 * the newest five items.
 */
class NewsRepository(@Suppress("UNUSED_PARAMETER") context: Context) {
    private data class FeedSource(val label: String, val url: String)

    private val resolvedImageCache = ConcurrentHashMap<String, String>()

    suspend fun refresh(): NewsState = withContext(Dispatchers.IO) {
        runCatching {
            coroutineScope {
                val headlineJob = async { loadMergedFeeds(HEADLINE_FEEDS, 5) }
                val entertainmentJob = async { loadMergedFeeds(ENTERTAINMENT_FEEDS, 5) }
                val techJob = async { loadMergedFeeds(TECH_FEEDS, 5) }
                val legoJob = async { loadMergedFeeds(LEGO_FEEDS, 5) }

                val headlines = headlineJob.await()
                val entertainment = entertainmentJob.await()
                val tech = techJob.await()
                val lego = legoJob.await()
                val sections = listOf(headlines, entertainment, tech, lego)

                NewsState(
                    headlines = headlines,
                    entertainment = entertainment,
                    tech = tech,
                    lego = lego,
                    available = sections.any { it.isNotEmpty() },
                    lastUpdatedMillis = System.currentTimeMillis(),
                    message = if (sections.all { it.isEmpty() }) "News unavailable" else null,
                )
            }
        }.getOrElse { NewsState(message = "News unavailable") }
    }

    private suspend fun loadMergedFeeds(feeds: List<FeedSource>, limit: Int): List<NewsHeadline> = coroutineScope {
        val candidates = feeds.map { feed -> async { loadFeed(feed, limit * 4) } }
            .awaitAll()
            .flatten()
            .distinctBy { normalizeHeadlineKey(it) }
            .sortedWith(compareByDescending<NewsHeadline> { it.publishedAtMillis ?: 0L })
            .take(limit * 4)

        val enriched = candidates.map { headline ->
            async {
                if (!headline.imageUrl.isNullOrBlank()) headline
                else headline.copy(
                    imageUrl = resolvedImageCache[headline.url]
                        ?: resolveLeadImage(headline.url)?.also { resolvedImageCache[headline.url] = it },
                )
            }
        }.awaitAll()

        // Prefer the newest image-bearing stories so the visual news layout remains
        // image-led. Only fall back to an imageless item when a section genuinely
        // cannot provide enough illustrated stories.
        val withImages = enriched.filter { !it.imageUrl.isNullOrBlank() }
        val withoutImages = enriched.filter { it.imageUrl.isNullOrBlank() }
        (withImages + withoutImages).take(limit)
    }

    private fun normalizeHeadlineKey(headline: NewsHeadline): String = headline.title
        .lowercase(Locale.ROOT)
        .replace(Regex("[^a-z0-9]+"), " ")
        .trim()

    private fun loadFeed(feed: FeedSource, limit: Int): List<NewsHeadline> = runCatching {
        val connection = open(feed.url, 7_500, 9_000)
        connection.inputStream.buffered().use { input ->
            val parser = Xml.newPullParser().apply {
                setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
                setInput(input, null)
            }
            parse(parser, feed.label, limit)
        }
    }.getOrDefault(emptyList())

    private fun parse(parser: XmlPullParser, fallbackSource: String, limit: Int): List<NewsHeadline> {
        val results = mutableListOf<NewsHeadline>()
        var event = parser.eventType
        var inItem = false
        var currentTag: String? = null
        var title = ""
        var link = ""
        var source = ""
        var description = ""
        var published: Long? = null
        var imageUrl: String? = null
        var imageScore = -1L

        fun considerImage(candidate: String?, width: String? = null, height: String? = null) {
            val raw = candidate?.trim().orEmpty()
            if (raw.isBlank()) return
            val w = width?.toLongOrNull() ?: 0L
            val h = height?.toLongOrNull() ?: 0L
            val score = if (w > 0 && h > 0) w * h else 1L
            if (score >= imageScore) {
                imageUrl = raw
                imageScore = score
            }
        }

        while (event != XmlPullParser.END_DOCUMENT && results.size < limit) {
            when (event) {
                XmlPullParser.START_TAG -> {
                    currentTag = parser.name
                    if (parser.name.equals("item", ignoreCase = true)) {
                        inItem = true
                        title = ""
                        link = ""
                        source = ""
                        description = ""
                        published = null
                        imageUrl = null
                        imageScore = -1L
                    } else if (inItem) {
                        val tag = parser.name.lowercase(Locale.ROOT)
                        when (tag) {
                            "media:content", "media:thumbnail", "thumbnail", "content" -> considerImage(
                                parser.getAttributeValue(null, "url"),
                                parser.getAttributeValue(null, "width"),
                                parser.getAttributeValue(null, "height"),
                            )
                            "enclosure" -> {
                                val type = parser.getAttributeValue(null, "type").orEmpty()
                                if (type.startsWith("image/", ignoreCase = true)) {
                                    considerImage(parser.getAttributeValue(null, "url"))
                                }
                            }
                            "image" -> considerImage(parser.getAttributeValue(null, "url"))
                        }
                    }
                }

                XmlPullParser.TEXT -> if (inItem) {
                    val raw = parser.text.orEmpty()
                    val value = raw.trim()
                    if (value.isNotBlank()) {
                        when (currentTag?.lowercase(Locale.ROOT)) {
                            "title" -> title += value
                            "link" -> link += value
                            "source" -> if (source.isBlank()) source += value
                            "description", "content:encoded" -> description += raw
                            "image" -> considerImage(value)
                            "pubdate", "published", "updated", "dc:date" -> if (published == null) published = parseDate(value)
                        }
                    }
                }

                XmlPullParser.END_TAG -> {
                    if (parser.name.equals("item", ignoreCase = true)) {
                        val cleanLink = decodeHtml(link.trim())
                        if (title.isNotBlank() && cleanLink.isNotBlank()) {
                            val htmlImage = firstImageInHtml(description, cleanLink)
                            val normalizedImage = absoluteUrl(cleanLink, imageUrl ?: htmlImage)
                            results += NewsHeadline(
                                title = decodeHtml(title.trim()),
                                url = cleanLink,
                                source = source.trim().ifBlank { fallbackSource },
                                publishedAtMillis = published,
                                imageUrl = normalizedImage,
                            )
                        }
                        inItem = false
                    }
                    currentTag = null
                }
            }
            event = parser.next()
        }
        return results
    }

    private fun resolveLeadImage(articleUrl: String): String? = runCatching {
        val page = fetchHtml(articleUrl) ?: return@runCatching null
        findLeadImageMeta(page.html, page.finalUrl)
            ?: firstImageInHtml(page.html, page.finalUrl)
    }.getOrNull()

    private data class HtmlPage(val finalUrl: String, val html: String)

    private fun fetchHtml(url: String): HtmlPage? = runCatching {
        val connection = open(url, 5_500, 7_500).apply {
            setRequestProperty("Accept", "text/html,application/xhtml+xml")
        }
        if (connection.responseCode !in 200..399) return@runCatching null
        val html = connection.inputStream.bufferedReader().use { reader ->
            val out = StringBuilder()
            val buffer = CharArray(8192)
            while (out.length < 350_000) {
                val read = reader.read(buffer)
                if (read <= 0) break
                out.append(buffer, 0, read.coerceAtMost(350_000 - out.length))
            }
            out.toString()
        }
        HtmlPage(connection.url.toString(), html)
    }.getOrNull()

    private fun open(url: String, connectMs: Int, readMs: Int): HttpURLConnection =
        (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = connectMs
            readTimeout = readMs
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 16) AppleWebKit/537.36 Chrome/140 Mobile Safari/537.36")
            setRequestProperty("Accept-Language", "en-GB,en;q=0.9")
            setRequestProperty("Accept-Encoding", "identity")
        }

    private fun firstImageInHtml(html: String, baseUrl: String): String? =
        IMG_SRC.findAll(html)
            .mapNotNull { it.groupValues.getOrNull(1)?.let(::decodeHtml) }
            .mapNotNull { absoluteUrl(baseUrl, it) }
            .firstOrNull { candidate -> !looksLikeTrackingImage(candidate) }

    private fun findLeadImageMeta(html: String, baseUrl: String): String? {
        META_TAG.findAll(html).forEach { match ->
            val attrs = ATTRIBUTE.findAll(match.value).associate { attr ->
                attr.groupValues[1].lowercase(Locale.ROOT) to attr.groupValues[2]
            }
            val key = attrs["property"] ?: attrs["name"]
            if (key.equals("og:image", true) || key.equals("og:image:url", true) || key.equals("twitter:image", true) || key.equals("twitter:image:src", true)) {
                val value = attrs["content"]?.let(::decodeHtml)?.let { absoluteUrl(baseUrl, it) }
                if (value != null && !looksLikeTrackingImage(value)) return value
            }
        }
        return null
    }

    private fun absoluteUrl(baseUrl: String, candidate: String?): String? {
        val value = candidate?.trim().orEmpty()
        if (value.isBlank() || value.startsWith("data:", ignoreCase = true)) return null
        return runCatching {
            val uri = URI(value)
            val resolved = if (uri.isAbsolute) uri else URI(baseUrl).resolve(uri)
            resolved.toString().takeIf { it.startsWith("http://") || it.startsWith("https://") }
        }.getOrNull()
    }

    private fun looksLikeTrackingImage(url: String): Boolean {
        val lower = url.lowercase(Locale.ROOT)
        return lower.contains("pixel") || lower.contains("tracking") || lower.contains("1x1") || lower.contains("spacer.gif")
    }

    private fun decodeHtml(value: String): String = Html.fromHtml(value, Html.FROM_HTML_MODE_LEGACY).toString().trim()

    private fun parseDate(raw: String): Long? {
        val candidates = listOf(
            DateTimeFormatter.RFC_1123_DATE_TIME,
            DateTimeFormatter.ISO_ZONED_DATE_TIME,
            DateTimeFormatter.ISO_OFFSET_DATE_TIME,
        )
        candidates.forEach { formatter ->
            runCatching { return ZonedDateTime.parse(raw, formatter).toInstant().toEpochMilli() }
        }
        return null
    }

    companion object {
        private val HEADLINE_FEEDS = listOf(
            FeedSource("BBC News", "https://feeds.bbci.co.uk/news/rss.xml"),
            FeedSource("The Guardian", "https://www.theguardian.com/world/rss"),
            FeedSource("France 24", "https://www.france24.com/en/rss"),
            FeedSource("The New York Times", "https://rss.nytimes.com/services/xml/rss/nyt/HomePage.xml"),
        )

        private val ENTERTAINMENT_FEEDS = listOf(
            FeedSource("BBC", "https://feeds.bbci.co.uk/news/entertainment_and_arts/rss.xml"),
            FeedSource("The Guardian", "https://www.theguardian.com/culture/rss"),
            FeedSource("The New York Times", "https://rss.nytimes.com/services/xml/rss/nyt/Arts.xml"),
        )

        private val TECH_FEEDS = listOf(
            FeedSource("BBC", "https://feeds.bbci.co.uk/news/technology/rss.xml"),
            FeedSource("The Guardian", "https://www.theguardian.com/uk/technology/rss"),
            FeedSource("WIRED", "https://www.wired.com/feed/rss"),
            FeedSource("The New York Times", "https://rss.nytimes.com/services/xml/rss/nyt/Technology.xml"),
        )

        private val LEGO_FEEDS = listOf(
            FeedSource("Brickset", "https://brickset.com/feed"),
            FeedSource("The Brothers Brick", "https://www.brothers-brick.com/feed/"),
        )

        private val IMG_SRC = Regex("""<img[^>]+(?:src|data-src)\s*=\s*[\"']([^\"']+)[\"']""", RegexOption.IGNORE_CASE)
        private val META_TAG = Regex("""<meta\s+[^>]*>""", RegexOption.IGNORE_CASE)
        private val ATTRIBUTE = Regex("""([A-Za-z_:.-]+)\s*=\s*[\"']([^\"']*)[\"']""")
    }
}
