package com.handlauncher.engine

import com.handlauncher.domain.*

class ContextEngine {
    fun evaluate(snapshot: ContextSnapshot, rules: List<ContextRule> = defaultRules()): ContextDecision {
        val matching = rules.filter { it.enabled && it.conditions.isNotEmpty() && it.conditions.all { condition -> matches(condition, snapshot) } }
        return ContextDecision(
            matchedRuleIds = matching.map { it.id },
            effects = matching.map { it.effect },
        )
    }

    private fun matches(condition: ContextCondition, snapshot: ContextSnapshot): Boolean = when (condition) {
        is ContextCondition.BatteryBelow -> snapshot.phoneBatteryPercent < condition.percent
        is ContextCondition.ChargingIs -> snapshot.isCharging == condition.charging
        is ContextCondition.TimeBetween -> {
            val start = condition.startHour.coerceIn(0, 23)
            val end = condition.endHourExclusive.coerceIn(0, 24)
            if (start < end) snapshot.now.hour in start until end
            else snapshot.now.hour >= start || snapshot.now.hour < end
        }
        is ContextCondition.ProfileIs -> snapshot.layoutProfile == condition.profile
        is ContextCondition.BluetoothConnected -> snapshot.connectedBluetoothNames.any {
            it.contains(condition.nameContains, ignoreCase = true)
        }
        is ContextCondition.EventWithin -> snapshot.nextCalendarEventInMinutes?.let { it in 0..condition.minutes } == true
        is ContextCondition.RainWithin -> snapshot.rainExpectedInMinutes?.let { it in 0..condition.minutes } == true
    }

    companion object {
        fun defaultRules() = listOf(
            ContextRule(
                id = "low-battery",
                name = "Promote battery when low",
                conditions = listOf(ContextCondition.BatteryBelow(20)),
                effect = ContextEffect.PromoteWidget(NativeWidgetKind.BATTERY),
            ),
            ContextRule(
                id = "upcoming-event",
                name = "Promote calendar before an event",
                conditions = listOf(ContextCondition.EventWithin(30)),
                effect = ContextEffect.PromoteWidget(NativeWidgetKind.CALENDAR),
            ),
            ContextRule(
                id = "desktop-context",
                name = "Desktop workspace suggestion",
                conditions = listOf(ContextCondition.ProfileIs(LayoutProfile.EXTERNAL_DISPLAY)),
                effect = ContextEffect.SuggestCommand("Desktop workspace", "open:workspace"),
            ),
        )
    }
}
