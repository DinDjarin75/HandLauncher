package com.handlauncher.data

import android.content.Context
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.HeartRateRecord
import androidx.health.connect.client.records.OxygenSaturationRecord
import androidx.health.connect.client.records.SleepSessionRecord
import androidx.health.connect.client.records.StepsRecord
import androidx.health.connect.client.request.ReadRecordsRequest
import androidx.health.connect.client.time.TimeRangeFilter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.time.Duration
import java.time.Instant
import kotlin.math.roundToInt

class EnergyGridRepository(private val context: Context) {
    private val prefs = context.getSharedPreferences("boal_energy_grid", Context.MODE_PRIVATE)

    suspend fun refresh(): EnergyGridState = withContext(Dispatchers.IO) {
        if (HealthConnectClient.getSdkStatus(context) != HealthConnectClient.SDK_AVAILABLE) {
            return@withContext cached().copy(available = false, message = "Health Connect unavailable")
        }

        val client = HealthConnectClient.getOrCreate(context)
        val granted = runCatching { client.permissionController.getGrantedPermissions() }.getOrDefault(emptySet())
        val core = corePermissions()
        val hasCore = core.all { it in granted }
        val hasBackground = HealthPermission.PERMISSION_READ_HEALTH_DATA_IN_BACKGROUND in granted
        if (!hasCore) {
            return@withContext cached().copy(
                available = true,
                permissionsGranted = false,
                backgroundPermissionGranted = hasBackground,
                message = "Health access required",
            )
        }

        val end = Instant.now()
        val start = end.minus(Duration.ofHours(30))
        val filter = TimeRangeFilter.between(start, end)

        val steps = runCatching {
            client.readRecords(ReadRecordsRequest(StepsRecord::class, filter)).records
        }.getOrDefault(emptyList())
        val sleep = runCatching {
            client.readRecords(ReadRecordsRequest(SleepSessionRecord::class, filter)).records
        }.getOrDefault(emptyList())
        val heart = runCatching {
            client.readRecords(ReadRecordsRequest(HeartRateRecord::class, filter, ascendingOrder = false)).records
        }.getOrDefault(emptyList())
        val oxygen = runCatching {
            client.readRecords(ReadRecordsRequest(OxygenSaturationRecord::class, filter, ascendingOrder = false)).records
        }.getOrDefault(emptyList())

        fun sourceSnapshot(packageName: String, label: String): EnergySourceSnapshot {
            val sourceSteps = steps.filter { it.metadata.dataOrigin.packageName == packageName }.sumOf { it.count }
            val sourceSleepMinutes = sleep
                .filter { it.metadata.dataOrigin.packageName == packageName }
                .sumOf { Duration.between(it.startTime, it.endTime).toMinutes().coerceAtLeast(0L) }
            val sourceHeart = heart
                .asSequence()
                .filter { it.metadata.dataOrigin.packageName == packageName }
                .flatMap { it.samples.asSequence() }
                .maxByOrNull { it.time }
                ?.beatsPerMinute
            val sourceOxygen = oxygen
                .asSequence()
                .filter { it.metadata.dataOrigin.packageName == packageName }
                .maxByOrNull { it.time }
                ?.percentage
                ?.value

            return EnergySourceSnapshot(
                packageName = packageName,
                label = label,
                steps = sourceSteps.takeIf { it > 0L },
                sleepMinutes = sourceSleepMinutes.takeIf { it > 0L },
                heartRateBpm = sourceHeart,
                oxygenPercent = sourceOxygen,
            )
        }

        val samsung = sourceSnapshot(SAMSUNG_HEALTH_PACKAGE, "Samsung Health")
        val ring = sourceSnapshot(RINGCONN_PACKAGE, "RingConn")

        val bestSleep = listOfNotNull(samsung.sleepMinutes, ring.sleepMinutes).maxOrNull()
        val bestSteps = listOfNotNull(samsung.steps, ring.steps).maxOrNull()
        val energyIndex = when {
            bestSleep == null && bestSteps == null -> null
            else -> {
                val sleepScore = ((bestSleep ?: 0L).toDouble() / 480.0 * 100.0).coerceIn(0.0, 100.0)
                val activityScore = ((bestSteps ?: 0L).toDouble() / 10_000.0 * 100.0).coerceIn(0.0, 100.0)
                (sleepScore * 0.62 + activityScore * 0.38).roundToInt().coerceIn(0, 100)
            }
        }

        val state = EnergyGridState(
            available = true,
            permissionsGranted = true,
            backgroundPermissionGranted = hasBackground,
            energyIndex = energyIndex,
            samsung = samsung,
            ringConn = ring,
            lastUpdatedMillis = System.currentTimeMillis(),
            message = if (samsung.steps == null && samsung.sleepMinutes == null && ring.steps == null && ring.sleepMinutes == null) {
                "No Samsung Health or RingConn records shared yet"
            } else null,
        )
        save(state)
        state
    }

    fun cached(): EnergyGridState = runCatching {
        val raw = prefs.getString(KEY_STATE, null) ?: return@runCatching EnergyGridState()
        val root = JSONObject(raw)
        fun source(key: String, pkg: String, label: String): EnergySourceSnapshot {
            val obj = root.optJSONObject(key) ?: JSONObject()
            return EnergySourceSnapshot(
                packageName = pkg,
                label = label,
                steps = obj.optLongOrNull("steps"),
                sleepMinutes = obj.optLongOrNull("sleepMinutes"),
                heartRateBpm = obj.optLongOrNull("heartRateBpm"),
                oxygenPercent = obj.optDoubleOrNull("oxygenPercent"),
            )
        }
        EnergyGridState(
            available = root.optBoolean("available", false),
            permissionsGranted = root.optBoolean("permissionsGranted", false),
            backgroundPermissionGranted = root.optBoolean("backgroundPermissionGranted", false),
            energyIndex = root.optInt("energyIndex", -1).takeIf { it >= 0 },
            samsung = source("samsung", SAMSUNG_HEALTH_PACKAGE, "Samsung Health"),
            ringConn = source("ringConn", RINGCONN_PACKAGE, "RingConn"),
            lastUpdatedMillis = root.optLong("lastUpdatedMillis", 0L).takeIf { it > 0L },
            message = root.optString("message").takeIf { it.isNotBlank() },
        )
    }.getOrDefault(EnergyGridState())

    private fun save(state: EnergyGridState) {
        fun source(snapshot: EnergySourceSnapshot) = JSONObject().apply {
            snapshot.steps?.let { put("steps", it) }
            snapshot.sleepMinutes?.let { put("sleepMinutes", it) }
            snapshot.heartRateBpm?.let { put("heartRateBpm", it) }
            snapshot.oxygenPercent?.let { put("oxygenPercent", it) }
        }
        val root = JSONObject()
            .put("available", state.available)
            .put("permissionsGranted", state.permissionsGranted)
            .put("backgroundPermissionGranted", state.backgroundPermissionGranted)
            .put("energyIndex", state.energyIndex ?: -1)
            .put("samsung", source(state.samsung))
            .put("ringConn", source(state.ringConn))
            .put("lastUpdatedMillis", state.lastUpdatedMillis ?: 0L)
            .put("message", state.message.orEmpty())
        prefs.edit().putString(KEY_STATE, root.toString()).apply()
    }

    companion object {
        const val SAMSUNG_HEALTH_PACKAGE = "com.sec.android.app.shealth"
        const val RINGCONN_PACKAGE = "com.gdjztech.ringconn"
        private const val KEY_STATE = "state"

        fun corePermissions(): Set<String> = setOf(
            HealthPermission.getReadPermission(StepsRecord::class),
            HealthPermission.getReadPermission(SleepSessionRecord::class),
            HealthPermission.getReadPermission(HeartRateRecord::class),
            HealthPermission.getReadPermission(OxygenSaturationRecord::class),
        )

        fun requestedPermissions(): Set<String> = corePermissions() + HealthPermission.PERMISSION_READ_HEALTH_DATA_IN_BACKGROUND
    }
}

private fun JSONObject.optLongOrNull(name: String): Long? = if (has(name)) optLong(name) else null
private fun JSONObject.optDoubleOrNull(name: String): Double? = if (has(name)) optDouble(name) else null
