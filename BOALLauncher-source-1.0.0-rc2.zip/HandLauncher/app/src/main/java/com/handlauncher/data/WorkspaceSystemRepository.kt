package com.handlauncher.data

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Environment
import android.os.PowerManager
import android.os.StatFs
import android.os.SystemClock

class WorkspaceSystemRepository(private val context: Context) {
    fun snapshot(): WorkspaceSystemState {
        val stat = StatFs(Environment.getDataDirectory().path)
        val storageTotal = stat.totalBytes / BYTES_PER_GB
        val storageFree = stat.availableBytes / BYTES_PER_GB

        val memoryInfo = ActivityManager.MemoryInfo()
        context.getSystemService(ActivityManager::class.java)?.getMemoryInfo(memoryInfo)
        val memoryTotal = memoryInfo.totalMem / BYTES_PER_GB
        val memoryFree = memoryInfo.availMem / BYTES_PER_GB

        val batteryIntent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val batteryTemp = batteryIntent
            ?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
            ?.takeIf { it != Int.MIN_VALUE }
            ?.div(10.0)

        val thermalStatus = context.getSystemService(PowerManager::class.java)?.currentThermalStatus ?: PowerManager.THERMAL_STATUS_NONE
        val thermalLabel = when (thermalStatus) {
            PowerManager.THERMAL_STATUS_NONE -> "Normal"
            PowerManager.THERMAL_STATUS_LIGHT -> "Light"
            PowerManager.THERMAL_STATUS_MODERATE -> "Moderate"
            PowerManager.THERMAL_STATUS_SEVERE -> "Warm"
            PowerManager.THERMAL_STATUS_CRITICAL -> "Critical"
            PowerManager.THERMAL_STATUS_EMERGENCY -> "Emergency"
            PowerManager.THERMAL_STATUS_SHUTDOWN -> "Shutdown"
            else -> "Normal"
        }

        return WorkspaceSystemState(
            storageFreeGb = storageFree,
            storageTotalGb = storageTotal,
            memoryFreeGb = memoryFree,
            memoryTotalGb = memoryTotal,
            batteryTemperatureC = batteryTemp,
            thermalLabel = thermalLabel,
            uptimeHours = SystemClock.elapsedRealtime() / 3_600_000L,
        )
    }

    private companion object {
        const val BYTES_PER_GB = 1024.0 * 1024.0 * 1024.0
    }
}
