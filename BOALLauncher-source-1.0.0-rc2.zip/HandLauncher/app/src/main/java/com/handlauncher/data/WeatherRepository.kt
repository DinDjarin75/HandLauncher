package com.handlauncher.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Manual/coarse location avoids background location permission for a launcher. */
data class WeatherLocation(
    val label: String = "Luxembourg",
    val latitude: Double = 49.6116,
    val longitude: Double = 6.1319,
)

data class HourlyForecast(
    val timeLabel: String,
    val temperatureC: Double?,
    val condition: String,
    val precipitationChancePercent: Int?,
)

data class DailyForecast(
    val dayLabel: String,
    val highC: Double?,
    val lowC: Double?,
    val condition: String,
    val precipitationChancePercent: Int?,
)

data class WeatherState(
    val location: WeatherLocation = WeatherLocation(),
    val temperatureC: Double? = null,
    val condition: String = "Unavailable",
    val rainExpectedInMinutes: Int? = null,
    val available: Boolean = false,
    val dailyForecast: List<DailyForecast> = emptyList(),
    val hourlyForecast: List<HourlyForecast> = emptyList(),
    val humidityPercent: Int? = null,
    val windKmh: Double? = null,
    val airQualityIndex: Int? = null,
    val lastUpdatedMillis: Long? = null,
)

class WeatherRepository(context: Context) {
    private val prefs = context.getSharedPreferences("hand_weather", Context.MODE_PRIVATE)

    fun location(): WeatherLocation = WeatherLocation(
        label = prefs.getString(KEY_LABEL, "Luxembourg") ?: "Luxembourg",
        latitude = java.lang.Double.longBitsToDouble(prefs.getLong(KEY_LAT, java.lang.Double.doubleToRawLongBits(49.6116))),
        longitude = java.lang.Double.longBitsToDouble(prefs.getLong(KEY_LON, java.lang.Double.doubleToRawLongBits(6.1319))),
    )

    fun saveLocation(location: WeatherLocation) {
        prefs.edit()
            .putString(KEY_LABEL, location.label.trim().ifBlank { "Weather" })
            .putLong(KEY_LAT, java.lang.Double.doubleToRawLongBits(location.latitude.coerceIn(-90.0, 90.0)))
            .putLong(KEY_LON, java.lang.Double.doubleToRawLongBits(location.longitude.coerceIn(-180.0, 180.0)))
            .apply()
    }

    suspend fun refresh(): WeatherState = withContext(Dispatchers.IO) {
        val location = location()
        runCatching {
            val endpoint = "https://api.open-meteo.com/v1/forecast" +
                "?latitude=${location.latitude}&longitude=${location.longitude}" +
                "&current=temperature_2m,relative_humidity_2m,weather_code,wind_speed_10m" +
                "&hourly=temperature_2m,weather_code,precipitation_probability&forecast_hours=12" +
                "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max" +
                "&forecast_days=5&timezone=auto"
            val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                connectTimeout = 8_000
                readTimeout = 10_000
                requestMethod = "GET"
            }
            val raw = connection.inputStream.bufferedReader().use { it.readText() }
            val root = JSONObject(raw)
            val current = root.getJSONObject("current")
            val temp = current.optDouble("temperature_2m")
            val code = current.optInt("weather_code", -1)
            val humidity = current.optInt("relative_humidity_2m", -1).takeIf { it >= 0 }
            val windKmh = current.optDouble("wind_speed_10m").takeUnless { it.isNaN() }
            val hourly = root.optJSONObject("hourly")
            val probabilities = hourly?.optJSONArray("precipitation_probability")
            var rainMinutes: Int? = null
            if (probabilities != null) {
                for (i in 0 until probabilities.length()) {
                    if (probabilities.optInt(i, 0) >= 50) {
                        rainMinutes = i * 60
                        break
                    }
                }
            }
            val hourlyItems = buildList {
                val times = hourly?.optJSONArray("time")
                val temps = hourly?.optJSONArray("temperature_2m")
                val codes = hourly?.optJSONArray("weather_code")
                val precip = hourly?.optJSONArray("precipitation_probability")
                if (times != null) {
                    for (i in 0 until minOf(times.length(), 8)) {
                        val rawTime = times.optString(i)
                        val label = runCatching {
                            java.time.LocalDateTime.parse(rawTime).format(java.time.format.DateTimeFormatter.ofPattern("HH:mm"))
                        }.getOrDefault(rawTime.takeLast(5))
                        add(
                            HourlyForecast(
                                timeLabel = if (i == 0) "Now" else label,
                                temperatureC = temps?.optDouble(i).takeUnless { it == null || it.isNaN() },
                                condition = weatherCodeLabel(codes?.optInt(i, -1) ?: -1),
                                precipitationChancePercent = precip?.optInt(i, -1)?.takeIf { it >= 0 },
                            )
                        )
                    }
                }
            }

            val airQuality = runCatching {
                val aqEndpoint = "https://air-quality-api.open-meteo.com/v1/air-quality" +
                    "?latitude=${location.latitude}&longitude=${location.longitude}" +
                    "&current=european_aqi&timezone=auto"
                val aqConnection = (URL(aqEndpoint).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 6_000
                    readTimeout = 7_000
                    requestMethod = "GET"
                }
                val aqRaw = aqConnection.inputStream.bufferedReader().use { it.readText() }
                JSONObject(aqRaw).optJSONObject("current")?.optInt("european_aqi", -1)?.takeIf { it >= 0 }
            }.getOrNull()

            val daily = root.optJSONObject("daily")
            val days = buildList {
                val times = daily?.optJSONArray("time")
                val codes = daily?.optJSONArray("weather_code")
                val highs = daily?.optJSONArray("temperature_2m_max")
                val lows = daily?.optJSONArray("temperature_2m_min")
                val precip = daily?.optJSONArray("precipitation_probability_max")
                if (times != null) {
                    for (i in 0 until minOf(times.length(), 5)) {
                        val rawDay = times.optString(i)
                        val label = runCatching {
                            java.time.LocalDate.parse(rawDay).format(java.time.format.DateTimeFormatter.ofPattern("EEE"))
                        }.getOrDefault(rawDay)
                        add(
                            DailyForecast(
                                dayLabel = if (i == 0) "Today" else label,
                                highC = highs?.optDouble(i).takeUnless { it == null || it.isNaN() },
                                lowC = lows?.optDouble(i).takeUnless { it == null || it.isNaN() },
                                condition = weatherCodeLabel(codes?.optInt(i, -1) ?: -1),
                                precipitationChancePercent = precip?.optInt(i, -1)?.takeIf { it >= 0 },
                            )
                        )
                    }
                }
            }
            val state = WeatherState(
                location = location,
                temperatureC = temp,
                condition = weatherCodeLabel(code),
                rainExpectedInMinutes = rainMinutes,
                available = true,
                dailyForecast = days,
                hourlyForecast = hourlyItems,
                humidityPercent = humidity,
                windKmh = windKmh,
                airQualityIndex = airQuality,
                lastUpdatedMillis = System.currentTimeMillis(),
            )
            saveCache(state)
            state
        }.getOrElse { cached() ?: WeatherState(location = location, condition = "Weather unavailable") }
    }

    fun cached(): WeatherState? = runCatching {
        val raw = prefs.getString(KEY_CACHE, null) ?: return@runCatching null
        val root = JSONObject(raw)
        val cachedLocation = WeatherLocation(
            label = root.optString("label", "Luxembourg"),
            latitude = root.optDouble("latitude", 49.6116),
            longitude = root.optDouble("longitude", 6.1319),
        )
        val hourly = root.optJSONArray("hourly")?.let { array ->
            buildList {
                for (i in 0 until array.length()) {
                    val item = array.optJSONObject(i) ?: continue
                    add(HourlyForecast(
                        timeLabel = item.optString("timeLabel"),
                        temperatureC = item.optDouble("temperatureC", Double.NaN).takeUnless { it.isNaN() },
                        condition = item.optString("condition"),
                        precipitationChancePercent = item.optInt("precip", -1).takeIf { it >= 0 },
                    ))
                }
            }
        }.orEmpty()
        val daily = root.optJSONArray("daily")?.let { array ->
            buildList {
                for (i in 0 until array.length()) {
                    val item = array.optJSONObject(i) ?: continue
                    add(DailyForecast(
                        dayLabel = item.optString("dayLabel"),
                        highC = item.optDouble("highC", Double.NaN).takeUnless { it.isNaN() },
                        lowC = item.optDouble("lowC", Double.NaN).takeUnless { it.isNaN() },
                        condition = item.optString("condition"),
                        precipitationChancePercent = item.optInt("precip", -1).takeIf { it >= 0 },
                    ))
                }
            }
        }.orEmpty()
        WeatherState(
            location = cachedLocation,
            temperatureC = root.optDouble("temperatureC", Double.NaN).takeUnless { it.isNaN() },
            condition = root.optString("condition", "Unavailable"),
            rainExpectedInMinutes = root.optInt("rainExpectedInMinutes", -1).takeIf { it >= 0 },
            available = root.optBoolean("available", false),
            dailyForecast = daily,
            hourlyForecast = hourly,
            humidityPercent = root.optInt("humidityPercent", -1).takeIf { it >= 0 },
            windKmh = root.optDouble("windKmh", Double.NaN).takeUnless { it.isNaN() },
            airQualityIndex = root.optInt("airQualityIndex", -1).takeIf { it >= 0 },
            lastUpdatedMillis = root.optLong("lastUpdatedMillis", 0L).takeIf { it > 0L },
        )
    }.getOrNull()

    private fun saveCache(state: WeatherState) {
        val hourly = org.json.JSONArray().apply {
            state.hourlyForecast.forEach { item ->
                put(JSONObject()
                    .put("timeLabel", item.timeLabel)
                    .put("temperatureC", item.temperatureC ?: JSONObject.NULL)
                    .put("condition", item.condition)
                    .put("precip", item.precipitationChancePercent ?: -1))
            }
        }
        val daily = org.json.JSONArray().apply {
            state.dailyForecast.forEach { item ->
                put(JSONObject()
                    .put("dayLabel", item.dayLabel)
                    .put("highC", item.highC ?: JSONObject.NULL)
                    .put("lowC", item.lowC ?: JSONObject.NULL)
                    .put("condition", item.condition)
                    .put("precip", item.precipitationChancePercent ?: -1))
            }
        }
        val root = JSONObject()
            .put("label", state.location.label)
            .put("latitude", state.location.latitude)
            .put("longitude", state.location.longitude)
            .put("temperatureC", state.temperatureC ?: JSONObject.NULL)
            .put("condition", state.condition)
            .put("rainExpectedInMinutes", state.rainExpectedInMinutes ?: -1)
            .put("available", state.available)
            .put("humidityPercent", state.humidityPercent ?: -1)
            .put("windKmh", state.windKmh ?: JSONObject.NULL)
            .put("airQualityIndex", state.airQualityIndex ?: -1)
            .put("lastUpdatedMillis", state.lastUpdatedMillis ?: 0L)
            .put("hourly", hourly)
            .put("daily", daily)
        prefs.edit().putString(KEY_CACHE, root.toString()).apply()
    }

    private fun weatherCodeLabel(code: Int): String = when (code) {
        0 -> "Clear"
        1, 2 -> "Partly cloudy"
        3 -> "Overcast"
        45, 48 -> "Fog"
        in 51..57 -> "Drizzle"
        in 61..67 -> "Rain"
        in 71..77 -> "Snow"
        in 80..82 -> "Showers"
        in 85..86 -> "Snow showers"
        in 95..99 -> "Thunderstorm"
        else -> "Conditions unavailable"
    }

    companion object {
        private const val KEY_LABEL = "label"
        private const val KEY_LAT = "lat"
        private const val KEY_LON = "lon"
        private const val KEY_CACHE = "weather_cache"
    }
}
