package com.handlauncher.data

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class WorkspaceChatRepository(
    private val settings: OpenAiSettingsRepository,
    private val workspace: WorkspaceRepository,
) {
    fun send(prompt: String): Result<String> = runCatching {
        val apiKey = settings.readApiKey()?.takeIf { it.isNotBlank() }
            ?: error("OpenAI API key is not configured")
        val conversationId = workspace.conversationId() ?: createConversation(apiKey).also(workspace::saveConversationId)
        val body = JSONObject()
            .put("model", "gpt-5.6-sol")
            .put("conversation", conversationId)
            .put("input", prompt)
            .put("instructions", "You are ChatGPT inside BOAL Launcher. Be useful, direct, warm and concise enough for a compact mobile conversation module. Preserve continuity across this conversation.")
            .put("max_output_tokens", 800)
            .put("reasoning", JSONObject().put("effort", "low"))
        val response = post("https://api.openai.com/v1/responses", apiKey, body)
        extractOutputText(response).ifBlank { error("ChatGPT returned no text") }
    }

    private fun createConversation(apiKey: String): String {
        val body = JSONObject().put("metadata", JSONObject().put("surface", "boal_workspace"))
        val response = post("https://api.openai.com/v1/conversations", apiKey, body)
        return response.getString("id")
    }

    private fun post(endpoint: String, apiKey: String, body: JSONObject): JSONObject {
        val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15_000
            readTimeout = 45_000
            doOutput = true
            setRequestProperty("Authorization", "Bearer $apiKey")
            setRequestProperty("Content-Type", "application/json")
        }
        connection.outputStream.bufferedWriter().use { it.write(body.toString()) }
        val stream = if (connection.responseCode in 200..299) connection.inputStream else connection.errorStream
        val raw = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        if (connection.responseCode !in 200..299) {
            val message = runCatching { JSONObject(raw).optJSONObject("error")?.optString("message") }.getOrNull()
            error(message?.takeIf { it.isNotBlank() } ?: "OpenAI request failed (${connection.responseCode})")
        }
        return JSONObject(raw)
    }

    private fun extractOutputText(response: JSONObject): String {
        val output = response.optJSONArray("output") ?: return response.optString("output_text")
        val pieces = mutableListOf<String>()
        for (i in 0 until output.length()) {
            val item = output.optJSONObject(i) ?: continue
            if (item.optString("type") != "message") continue
            val content = item.optJSONArray("content") ?: continue
            for (j in 0 until content.length()) {
                val part = content.optJSONObject(j) ?: continue
                if (part.optString("type") == "output_text") pieces += part.optString("text")
            }
        }
        return pieces.joinToString("\n").trim()
    }
}
