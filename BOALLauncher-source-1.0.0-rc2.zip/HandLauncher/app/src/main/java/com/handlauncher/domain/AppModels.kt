package com.handlauncher.domain

data class AppEntry(
    val packageName: String,
    val activityName: String,
    val label: String,
    val categoryId: String,
    val tags: Set<String> = emptySet(),
    val isSystemApp: Boolean = false,
) {
    val stableId: String get() = "$packageName/$activityName"
}

data class AppCategory(
    val id: String,
    val name: String,
    val iconKey: String,
    val sortOrder: Int,
    val userCreated: Boolean = false,
    /** 0 = opaque, 90 = almost fully transparent. */
    val backgroundTransparencyPercent: Int = 38,
)

object DefaultCategories {
    val communication = AppCategory("communication", "Communication", "chat", 0)
    val social = AppCategory("social", "Social", "people", 1)
    val media = AppCategory("media", "Media", "play", 2)
    val photo = AppCategory("photo", "Photo & Camera", "camera", 3)
    val productivity = AppCategory("productivity", "Productivity", "work", 4)
    val finance = AppCategory("finance", "Finance", "wallet", 5)
    val shopping = AppCategory("shopping", "Shopping", "bag", 6)
    val travel = AppCategory("travel", "Travel", "map", 7)
    val smartHome = AppCategory("smart_home", "Smart Home", "home", 8)
    val games = AppCategory("games", "Games", "gamepad", 9)
    val utilities = AppCategory("utilities", "Utilities", "tools", 10)
    val other = AppCategory("other", "Other", "grid", 99)

    val all = listOf(
        communication, social, media, photo, productivity, finance,
        shopping, travel, smartHome, games, utilities, other
    )
}
