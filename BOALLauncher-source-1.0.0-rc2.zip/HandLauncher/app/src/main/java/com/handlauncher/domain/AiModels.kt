package com.handlauncher.domain

data class AiLayoutRequest(
    val naturalLanguagePrompt: String,
    val targetProfile: LayoutProfile,
    val availableApps: List<AppEntry>,
    val preferredWidgets: Set<NativeWidgetKind>,
    val currentLayout: LauncherLayout? = null,
)

data class AiThemeTokens(
    val dark: Boolean,
    val cornerRadiusDp: Int,
    val transparencyPercent: Int,
    val typographyMood: String,
)

data class AiLayoutProposal(
    val rationale: String,
    val layout: LauncherLayout,
    val theme: AiThemeTokens,
    val warnings: List<String> = emptyList(),
    val generatedBy: String = "Local designer",
)

data class AiProviderSettings(
    val model: String = "gemini-3.8-flash",
    val apiKeyConfigured: Boolean = false,
)

fun interface AiLayoutProvider {
    suspend fun generate(request: AiLayoutRequest): AiLayoutProposal
}
