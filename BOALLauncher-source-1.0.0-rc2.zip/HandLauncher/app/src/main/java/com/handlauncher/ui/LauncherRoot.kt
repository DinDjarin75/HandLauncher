package com.handlauncher.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.handlauncher.LauncherUiState
import com.handlauncher.LauncherViewModel
import com.handlauncher.SurfaceMode
import com.handlauncher.data.LauncherNotification
import com.handlauncher.domain.LayoutProfile
import com.handlauncher.domain.SmartObjectType
import com.handlauncher.platform.AndroidWidgetHostController
import com.handlauncher.ui.screens.*
import com.handlauncher.ui.components.LocalIconPackPackage
import kotlinx.coroutines.delay

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun LauncherRoot(
    state: LauncherUiState,
    viewModel: LauncherViewModel,
    requestHomeRole: () -> Unit,
    isHomeRoleHeld: Boolean,
    widgetHostController: AndroidWidgetHostController,
    onAddAndroidWidget: () -> Unit,
    onRemoveAndroidWidget: (Int) -> Unit,
    onRequestCalendarPermission: () -> Unit,
    onExportBackup: () -> Unit,
    onImportBackup: () -> Unit,
    onOpenGoogleFeed: () -> Unit,
    onOpenExternalUrl: (String) -> Unit,
    onOpenClock: () -> Unit,
    onOpenCalendar: () -> Unit,
    onOpenCalendarApp: () -> Unit,
    onOpenWeather: () -> Unit,
    onOpenBattery: () -> Unit,
    onOpenMedia: () -> Unit,
    onOpenMediaAccess: () -> Unit,
    onOpenNotification: (LauncherNotification) -> Unit,
    onOpenNotificationShade: () -> Unit,
    onOpenQuickSettings: () -> Unit,
    onOpenSystemGestureAccess: () -> Unit,
    onToggleMobileData: () -> Unit,
    onToggleBluetooth: () -> Unit,
    onToggleWifi: () -> Unit,
    onToggleHotspot: () -> Unit,
    onRefreshWallpaperAccent: () -> Unit,
    onSetupWorkspaceKeep: () -> Unit,
    onOpenKeep: () -> Unit,
    onCreateKeepNote: () -> Unit,
    onOpenChatGpt: () -> Unit,
    onSendPromptToChatGpt: (String) -> Unit,
    onRequestEnergyHealthAccess: () -> Unit,
    onSetupWorkspaceShowly: () -> Unit,
    onOpenWorkspacePackage: (String) -> Unit,
) {
    LaunchedEffect(state.statusMessage) {
        if (state.statusMessage != null) {
            delay(2400)
            viewModel.clearStatusMessage()
        }
    }

    val removeObject: (com.handlauncher.domain.SmartObject) -> Unit = { obj ->
        if (obj.type == SmartObjectType.ANDROID_WIDGET) {
            obj.payload["appWidgetId"]?.toIntOrNull()?.let(onRemoveAndroidWidget) ?: viewModel.removeObject(obj)
        } else viewModel.removeObject(obj)
    }

    // Wallpaper is the foundation. AI transparency now styles objects/cards only;
    // it never lays an opaque theme wash over the user's wallpaper.
    CompositionLocalProvider(LocalIconPackPackage provides state.selectedIconPackPackage) {
        Surface(Modifier.fillMaxSize(), color = androidx.compose.ui.graphics.Color.Transparent, contentColor = androidx.compose.ui.graphics.Color.White) {
            Box(Modifier.fillMaxSize()) {
            if (state.loading) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            } else if (state.profile == LayoutProfile.EXTERNAL_DISPLAY && state.surfaceMode == SurfaceMode.HOME) {
                DesktopHomePage(
                    apps = state.apps,
                    smartObjectOverrides = state.smartObjectOverrides,
                    smartStacks = state.smartStacks,
                    battery = state.battery,
                    weather = state.weather,
                    media = state.media,
                    connectivity = state.connectivity,
                    contextDecision = state.contextDecision,
                    connectedDeviceNames = state.connectedAudioNames,
                    nextEventInMinutes = state.nextCalendarEventInMinutes,
                    nextEventTitle = state.nextCalendarEvent?.title,
                    nextEventStartMillis = state.nextCalendarEvent?.beginMillis,
                    loadStackPosition = viewModel::loadSmartStackPosition,
                    onStackPositionChanged = viewModel::saveSmartStackPosition,
                    activeLayout = state.activeLayout,
                    editMode = state.editMode,
                    onLaunch = viewModel::launch,
                    onEditSmartObject = viewModel::editSmartObject,
                    onSearch = viewModel::showSearch,
                    onAiDesign = viewModel::showAiDesign,
                    onAutomations = viewModel::showAutomationEditor,
                    onSettings = viewModel::showSettings,
                    onOpenClock = onOpenClock,
                    onOpenCalendar = onOpenCalendar,
                    onOpenCalendarApp = onOpenCalendarApp,
                    onOpenWeather = onOpenWeather,
                    onOpenBattery = onOpenBattery,
                    onOpenMedia = onOpenMedia,
                    onMediaPlayPause = viewModel::mediaPlayPause,
                    onMediaPrevious = viewModel::mediaPrevious,
                    onMediaNext = viewModel::mediaNext,
                    onMediaSeek = viewModel::mediaSeekTo,
                    onAddObject = viewModel::showObjectPalette,
                    onEnterEditMode = viewModel::enterEditMode,
                    onExitEditMode = viewModel::exitEditMode,
                    onToggleLock = viewModel::toggleLayoutLock,
                    onToggleFinePositioning = viewModel::toggleFinePositioning,
                    onObjectGesture = viewModel::executeSmartObjectGesture,
                    onObjectRectChange = viewModel::updateObjectRect,
                    onRemoveObject = removeObject,
                    onEditObject = viewModel::editCanvasObject,
                    widgetHostController = widgetHostController,
                )
            } else {
                when (state.surfaceMode) {
                    SurfaceMode.HOME -> {
                        val pagerState = rememberPagerState(initialPage = 1, pageCount = { 3 })
                        HorizontalPager(state = pagerState, modifier = Modifier.fillMaxSize(), userScrollEnabled = !state.editMode) { page ->
                            when (page) {
                                0 -> FeedPage(
                                    battery = state.battery,
                                    weather = state.weather,
                                    news = state.news,
                                    contextDecision = state.contextDecision,
                                    nextEventTitle = state.nextCalendarEvent?.title,
                                    nextEventInMinutes = state.nextCalendarEventInMinutes,
                                    nextEventStartMillis = state.nextCalendarEvent?.beginMillis,
                                    calendarPermissionGranted = state.calendarPermissionGranted,
                                    onRequestCalendarPermission = onRequestCalendarPermission,
                                    onOpenHeadline = onOpenExternalUrl,
                                    onRefreshBrief = viewModel::refreshBrief,
                                    onOpenWeather = onOpenWeather,
                                    onOpenBattery = onOpenBattery,
                                    onOpenCalendar = onOpenCalendar,
                                    onRunCommand = viewModel::runLauncherCommand,
                                    onOpenGoogle = onOpenGoogleFeed,
                                    profile = state.profile,
                                )
                                1 -> PhoneHomePage(
                                    apps = state.apps,
                                    smartObjectOverrides = state.smartObjectOverrides,
                                    smartStacks = state.smartStacks,
                                    battery = state.battery,
                                    weather = state.weather,
                                    media = state.media,
                                    connectivity = state.connectivity,
                                    notifications = state.notifications,
                                    notificationAccessGranted = state.notificationAccessGranted,
                                    contextDecision = state.contextDecision,
                                    connectedDeviceNames = state.connectedAudioNames,
                                    nextEventInMinutes = state.nextCalendarEventInMinutes,
                                    nextEventTitle = state.nextCalendarEvent?.title,
                                    nextEventStartMillis = state.nextCalendarEvent?.beginMillis,
                                    loadStackPosition = viewModel::loadSmartStackPosition,
                                    onStackPositionChanged = viewModel::saveSmartStackPosition,
                                    homePageVisible = pagerState.currentPage == 1,
                                    profile = state.profile,
                                    activeLayout = state.activeLayout,
                                    editMode = state.editMode,
                                    isHomeRoleHeld = isHomeRoleHeld,
                                    requestHomeRole = requestHomeRole,
                                    onLaunch = viewModel::launch,
                                    onEditSmartObject = viewModel::editSmartObject,
                                    onSearch = viewModel::showSearch,
                                    onLibrary = viewModel::showLibrary,
                                    onOpenNotificationShade = onOpenNotificationShade,
                                    onOpenQuickSettings = onOpenQuickSettings,
                                    onAiDesign = viewModel::showAiDesign,
                                    onAutomations = viewModel::showAutomationEditor,
                                    onSettings = viewModel::showSettings,
                                    onOpenClock = onOpenClock,
                                    onOpenCalendar = onOpenCalendar,
                                    onOpenCalendarApp = onOpenCalendarApp,
                                    onOpenWeather = onOpenWeather,
                                    onOpenBattery = onOpenBattery,
                                    onOpenMedia = onOpenMedia,
                                    onMediaPlayPause = viewModel::mediaPlayPause,
                                    onMediaPrevious = viewModel::mediaPrevious,
                                    onMediaNext = viewModel::mediaNext,
                                    onMediaSeek = viewModel::mediaSeekTo,
                                    onOpenNotification = onOpenNotification,
                                    onDismissNotification = viewModel::dismissNotification,
                                    onRequestNotificationAccess = onOpenMediaAccess,
                                    onRunCommand = viewModel::runLauncherCommand,
                                    onAddObject = viewModel::showObjectPalette,
                                    onEnterEditMode = viewModel::enterEditMode,
                                    onExitEditMode = viewModel::exitEditMode,
                                    onToggleLock = viewModel::toggleLayoutLock,
                                    onToggleFinePositioning = viewModel::toggleFinePositioning,
                                    onObjectGesture = viewModel::executeSmartObjectGesture,
                                    onObjectRectChange = viewModel::updateObjectRect,
                                    onRemoveObject = removeObject,
                                    onEditObject = viewModel::editCanvasObject,
                                    widgetHostController = widgetHostController,
                                )
                                else -> ExtraHomePage(
                                    contextDecision = state.contextDecision,
                                    battery = state.battery,
                                    weather = state.weather,
                                    connectivity = state.connectivity,
                                    onToggleMobileData = onToggleMobileData,
                                    onToggleBluetooth = onToggleBluetooth,
                                    onToggleWifi = onToggleWifi,
                                    onToggleHotspot = onToggleHotspot,
                                    profile = state.profile,
                                    widgetHostController = widgetHostController,
                                    notifications = state.notifications,
                                    systemState = state.workspaceSystem,
                                    energyState = state.workspaceEnergy,
                                    carouselInitialIndex = state.workspaceCarouselIndex,
                                    showlyShowsWidgetId = state.workspaceShowlyShowsWidgetId,
                                    showlyMoviesWidgetId = state.workspaceShowlyMoviesWidgetId,
                                    onCarouselIndexChanged = viewModel::saveWorkspaceCarouselIndex,
                                    onRequestEnergyHealthAccess = onRequestEnergyHealthAccess,
                                    onSetupShowly = onSetupWorkspaceShowly,
                                    onOpenNotification = onOpenNotification,
                                    onOpenWorkspacePackage = onOpenWorkspacePackage,
                                )
                            }
                        }
                    }

                    SurfaceMode.SEARCH -> SearchScreen(
                        query = state.searchQuery,
                        results = state.searchResults,
                        onQueryChange = viewModel::updateSearch,
                        onLaunch = viewModel::launch,
                        onCommand = viewModel::runLauncherCommand,
                        onDismiss = viewModel::showHome,
                    )

                    SurfaceMode.APP_LIBRARY -> AppLibraryScreen(
                        apps = state.apps,
                        categories = state.categories,
                        selectedCategoryId = state.selectedCategoryId,
                        onSelectCategory = viewModel::selectCategory,
                        onLaunch = viewModel::launch,
                        onEditCategories = viewModel::showCategoryEditor,
                        onAssignApp = viewModel::assignAppToCategory,
                        onAddToHome = viewModel::addAppToHomeFromLibrary,
                        onAppInfo = viewModel::openAppInfo,
                        onUninstall = viewModel::uninstallApp,
                        onDismiss = viewModel::showHome,
                    )

                    SurfaceMode.CATEGORY_EDITOR -> CategoryEditorScreen(
                        apps = state.apps,
                        categories = state.categories,
                        selectedCategoryId = state.selectedCategoryId,
                        onSelectCategory = viewModel::selectCategory,
                        onRenameCategory = viewModel::renameCategory,
                        onCreateCategory = viewModel::createCategory,
                        onAssignApp = viewModel::assignAppToCategory,
                        onMoveCategory = viewModel::moveCategory,
                        onTransparencyChange = viewModel::setCategoryTransparency,
                        onDismiss = viewModel::showLibrary,
                    )

                    SurfaceMode.SMART_OBJECT_EDITOR -> {
                        val app = state.editingApp
                        val smartObject = state.editingSmartObject
                        if (app != null && smartObject != null) {
                            SmartObjectEditorScreen(
                                app = app,
                                smartObject = smartObject,
                                onTitleChange = viewModel::updateEditingObjectTitle,
                                onActionChange = viewModel::updateEditingObjectAction,
                                onSave = viewModel::saveEditingSmartObject,
                                onDismiss = viewModel::showHome,
                            )
                        } else LaunchedEffect(Unit) { viewModel.showHome() }
                    }

                    SurfaceMode.CANVAS_OBJECT_EDITOR -> {
                        val obj = state.editingSmartObject
                        if (obj != null) {
                            CanvasObjectEditorScreen(
                                smartObject = obj,
                                onTitleChange = viewModel::updateEditingObjectTitle,
                                onPayloadChange = viewModel::updateEditingObjectPayload,
                                onSave = viewModel::saveEditingCanvasObject,
                                onDismiss = viewModel::showHome,
                            )
                        } else LaunchedEffect(Unit) { viewModel.showHome() }
                    }

                    SurfaceMode.STACK_EDITOR -> {
                        val stack = state.editingStack
                        if (stack != null) {
                            StackEditorScreen(
                                stack = stack,
                                onNameChange = viewModel::updateEditingStackName,
                                onSmartRotationChange = viewModel::setStackSmartRotation,
                                onAutoLoopChange = viewModel::setStackAutoLoop,
                                onWidgetEnabledChange = viewModel::setStackWidgetEnabled,
                                onPromotionChange = viewModel::setStackPromotion,
                                onMove = viewModel::moveStackItem,
                                onSave = viewModel::saveEditingStack,
                                onDismiss = viewModel::showHome,
                            )
                        } else LaunchedEffect(Unit) { viewModel.showHome() }
                    }

                    SurfaceMode.AI_DESIGN -> AiDesignScreen(
                        prompt = state.aiPrompt,
                        proposal = state.aiProposal,
                        onPromptChange = viewModel::setAiPrompt,
                        onGenerate = viewModel::generateAiProposal,
                        onApply = viewModel::applyAiProposal,
                        onDismiss = viewModel::showHome,
                    )

                    SurfaceMode.OBJECT_PALETTE -> ObjectPaletteScreen(
                        apps = state.apps,
                        categories = state.categories,
                        onAddApp = viewModel::addAppObject,
                        onAddNativeWidget = viewModel::addNativeWidget,
                        onAddAndroidWidget = onAddAndroidWidget,
                        onAddSmartStack = { viewModel.addSmartStack() },
                        onAddCategory = viewModel::addCategoryObject,
                        onAddCommand = viewModel::addCommandObject,
                        onDismiss = viewModel::showHome,
                    )

                    SurfaceMode.AUTOMATION_EDITOR -> AutomationEditorScreen(
                        rules = state.automationRules,
                        editingRule = state.editingRule,
                        calendarPermissionGranted = state.calendarPermissionGranted,
                        connectedAudioNames = state.connectedAudioNames,
                        onCreate = viewModel::createAutomationRule,
                        onEdit = viewModel::editAutomationRule,
                        onToggle = viewModel::toggleAutomationRule,
                        onDelete = viewModel::deleteAutomationRule,
                        onRuleName = viewModel::updateEditingRuleName,
                        onRuleEnabled = viewModel::updateEditingRuleEnabled,
                        onAddCondition = viewModel::addEditingRuleCondition,
                        onUpdateCondition = viewModel::updateEditingRuleCondition,
                        onRemoveCondition = viewModel::removeEditingRuleCondition,
                        onEffect = viewModel::updateEditingRuleEffect,
                        onSaveRule = viewModel::saveEditingAutomationRule,
                        onCancelRule = viewModel::cancelAutomationRuleEdit,
                        onRequestCalendarPermission = onRequestCalendarPermission,
                        onDismiss = viewModel::showHome,
                    )

                    SurfaceMode.SETTINGS -> SettingsScreen(
                        aiSettings = state.aiSettings,
                        weather = state.weather,
                        iconPacks = state.iconPacks,
                        selectedIconPackPackage = state.selectedIconPackPackage,
                        isHomeRoleHeld = isHomeRoleHeld,
                        onRequestHomeRole = requestHomeRole,
                        onSaveAi = viewModel::saveAiSettings,
                        onClearAiKey = viewModel::clearAiApiKey,
                        onSaveWeather = viewModel::saveWeatherLocation,
                        onExport = onExportBackup,
                        onImport = onImportBackup,
                        onAutomations = viewModel::showAutomationEditor,
                        onMediaAccess = onOpenMediaAccess,
                        onSystemGestureAccess = onOpenSystemGestureAccess,
                        onSelectIconPack = viewModel::selectIconPack,
                        onRefreshWallpaperAccent = onRefreshWallpaperAccent,
                        onDismiss = viewModel::showHome,
                    )
                }
            }

                state.statusMessage?.let { message ->
                    Snackbar(modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(16.dp)) { Text(message) }
                }
            }
        }
    }
}
