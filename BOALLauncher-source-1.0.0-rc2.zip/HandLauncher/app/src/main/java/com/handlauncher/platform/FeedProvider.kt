package com.handlauncher.platform

sealed interface FeedState {
    data class Ready(val title: String) : FeedState
    data class Unavailable(val reason: String) : FeedState
}

fun interface FeedProvider {
    suspend fun state(): FeedState
}

/**
 * Google does not expose Discover as a normal third-party embedding API.
 * This boundary is intentionally kept separate so a companion bridge can be added
 * without coupling the rest of the launcher to an undocumented implementation.
 */
class DiscoverBridgeProvider : FeedProvider {
    override suspend fun state(): FeedState = FeedState.Unavailable(
        "Google Discover companion bridge not installed yet"
    )
}
