package com.handlauncher.engine

import com.handlauncher.domain.*
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDateTime

class ContextEngineTest {
    @Test
    fun lowBatteryPromotesBattery() {
        val decision = ContextEngine().evaluate(
            ContextSnapshot(
                now = LocalDateTime.of(2026, 10, 25, 12, 0),
                phoneBatteryPercent = 12,
                isCharging = false,
                layoutProfile = LayoutProfile.PHONE_PORTRAIT,
            )
        )
        assertTrue(decision.effects.contains(ContextEffect.PromoteWidget(NativeWidgetKind.BATTERY)))
    }

    @Test
    fun overnightTimeWindowWorks() {
        val rule = ContextRule(
            id = "night",
            name = "Night",
            conditions = listOf(ContextCondition.TimeBetween(22, 6)),
            effect = ContextEffect.SuggestCommand("Search", "search"),
        )
        val decision = ContextEngine().evaluate(
            ContextSnapshot(
                now = LocalDateTime.of(2026, 10, 25, 2, 0),
                phoneBatteryPercent = 80,
                isCharging = false,
                layoutProfile = LayoutProfile.PHONE_PORTRAIT,
            ),
            listOf(rule),
        )
        assertTrue("night" in decision.matchedRuleIds)
    }
}
