package com.handlauncher.engine

import com.handlauncher.domain.AppEntry
import org.junit.Assert.assertEquals
import org.junit.Test

class SearchEngineTest {
    private val apps = listOf(
        AppEntry("com.spotify.music", "Main", "Spotify", "media", setOf("music", "media")),
        AppEntry("com.google.android.apps.maps", "Maps", "Maps", "travel", setOf("travel", "navigation")),
        AppEntry("com.whatsapp", "Main", "WhatsApp", "communication", setOf("people", "communication")),
    )

    @Test
    fun prefixRanksExactAppFirst() {
        assertEquals("Spotify", SearchEngine().search(apps, "spo").first().label)
    }

    @Test
    fun tagsAreSearchable() {
        assertEquals("Maps", SearchEngine().search(apps, "navigation").first().label)
    }
}
