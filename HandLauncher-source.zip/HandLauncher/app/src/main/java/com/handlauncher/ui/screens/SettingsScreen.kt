package com.handlauncher.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.handlauncher.domain.AiProviderSettings
import com.handlauncher.data.WeatherState

@Composable
fun SettingsScreen(
    aiSettings: AiProviderSettings,
    weather: WeatherState,
    isHomeRoleHeld: Boolean,
    onRequestHomeRole: () -> Unit,
    onSaveAi: (String, String?) -> Unit,
    onClearAiKey: () -> Unit,
    onSaveWeather: (String, Double, Double) -> Unit,
    onExport: () -> Unit,
    onImport: () -> Unit,
    onAutomations: () -> Unit,
    onDismiss: () -> Unit,
) {
    BackHandler(onBack = onDismiss)
    var model by remember(aiSettings.model) { mutableStateOf(aiSettings.model) }
    var apiKey by remember { mutableStateOf("") }
    var weatherLabel by remember(weather.location.label) { mutableStateOf(weather.location.label) }
    var weatherLat by remember(weather.location.latitude) { mutableStateOf(weather.location.latitude.toString()) }
    var weatherLon by remember(weather.location.longitude) { mutableStateOf(weather.location.longitude.toString()) }
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Hand settings") },
                navigationIcon = { IconButton(onClick = onDismiss) { Icon(Icons.Rounded.ArrowBack, "Back") } },
            )
        }
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Launcher", style = MaterialTheme.typography.titleMedium)
                    Text(if (isHomeRoleHeld) "Hand is your default Home app" else "Hand is not yet your default Home app")
                    if (!isHomeRoleHeld) Button(onClick = onRequestHomeRole) { Text("Set Hand as Home") }
                    OutlinedButton(onClick = onAutomations) { Icon(Icons.Rounded.Bolt, null); Spacer(Modifier.width(8.dp)); Text("Context automations") }
                }
            }

            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("AI designer", style = MaterialTheme.typography.titleMedium)
                    Text(
                        if (aiSettings.apiKeyConfigured) "Gemini is configured. Your key is encrypted with Android Keystore and excluded from backups."
                        else "Without a Gemini key, Hand uses its local design engine.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    OutlinedTextField(model, { model = it }, label = { Text("Gemini model") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(
                        value = apiKey,
                        onValueChange = { apiKey = it },
                        label = { Text(if (aiSettings.apiKeyConfigured) "Replace API key (optional)" else "Gemini API key (optional)") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { onSaveAi(model, apiKey.takeIf(String::isNotBlank)); apiKey = "" }) { Text("Save") }
                        if (aiSettings.apiKeyConfigured) OutlinedButton(onClick = onClearAiKey) { Text("Remove key") }
                    }
                }
            }

            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Weather", style = MaterialTheme.typography.titleMedium)
                    Text("Hand uses a manually chosen coarse location, so the launcher does not need continuous location permission.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    OutlinedTextField(weatherLabel, { weatherLabel = it }, label = { Text("Location label") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(weatherLat, { weatherLat = it }, label = { Text("Latitude") }, singleLine = true, modifier = Modifier.weight(1f))
                        OutlinedTextField(weatherLon, { weatherLon = it }, label = { Text("Longitude") }, singleLine = true, modifier = Modifier.weight(1f))
                    }
                    Text("${weather.temperatureC?.let { "${kotlin.math.round(it).toInt()}°" } ?: "—°"} · ${weather.condition}", style = MaterialTheme.typography.bodySmall)
                    OutlinedButton(onClick = {
                        val lat = weatherLat.toDoubleOrNull(); val lon = weatherLon.toDoubleOrNull()
                        if (lat != null && lon != null) onSaveWeather(weatherLabel, lat, lon)
                    }) { Text("Save weather location") }
                }
            }

            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Backup & restore", style = MaterialTheme.typography.titleMedium)
                    Text("Exports layouts, categories, automations, Smart Objects and themes. AI credentials are never exported.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = onExport) { Icon(Icons.Rounded.Upload, null); Spacer(Modifier.width(6.dp)); Text("Export") }
                        OutlinedButton(onClick = onImport) { Icon(Icons.Rounded.Download, null); Spacer(Modifier.width(6.dp)); Text("Restore") }
                    }
                }
            }

            Spacer(Modifier.height(18.dp))
            Text("Hand Launcher · private alpha", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.align(Alignment.CenterHorizontally))
        }
    }
}
